# OS/Two - OS/2-Compatible Operating System

**Version:** 0.3 Alpha
**Status:** Early Development
**License:** MIT (to be determined)

---

## What is OS/Two?

**OS/Two** is an open-source operating system designed to be compatible with IBM's OS/2 APIs and executable formats. It's a modern reimplementation that aims to run OS/2 applications while using a clean, modern kernel architecture.

The name "OS/Two" is a playful homage to OS/2, pronounced the same way but with a fresh identity.

---

## Current Status (v0.3 Alpha)

### ✅ Implemented Features

**Core Kernel:**
- 32-bit x86 protected mode
- GDT (Global Descriptor Table) with Ring 0/3 separation
- IDT (Interrupt Descriptor Table) with exception handling
- Physical Memory Manager (PMM) - bitmap-based page allocator
- Virtual Memory Manager (VMM) - two-level paging
- Timer (PIT) running at 100 Hz
- Keyboard and mouse drivers (PS/2)

**Process Management:**
- Multi-process support
- Round-robin scheduler with time slicing
- Process states (READY, RUNNING, BLOCKED, TERMINATED)
- Per-process page directories
- User mode (Ring 3) execution

**DOS API (Implemented):**
- `DosWrite(handle, buffer, length)` - Write to file descriptor
- `DosExit(exitcode)` - Terminate process
- `DosGetPID()` - Get current process ID
- `DosPutChar(c)` - Write single character to stdout
- `DosPutString(str)` - Write null-terminated string

**System Calls:**
- INT 0x80 syscall interface
- Inline syscall wrappers in `dosapi.h`
- Proper Ring 3 → Ring 0 transitions

**File System:**
- RamFS - in-memory filesystem
- Basic file operations (create, read, write, delete)

**Shell:**
- Interactive command-line interface
- Commands: `help`, `clear`, `mem`, `vmm`, `ps`, `ls`, `cat`, `write`, `rm`, `reboot`

### 🚧 In Progress

- IOPL=0 security enforcement
- Process termination cleanup
- Extended DOS API functions

### 📋 Planned Features

See [OSTWO_ROADMAP.md](OSTWO_ROADMAP.md) for the complete development plan including:
- Threading support
- LX executable loader
- DOS compatibility box
- File system (FAT/HPFS)
- Presentation Manager (GUI)
- Named pipes and IPC
- REXX scripting

---

## Quick Start

### Prerequisites

**Required:**
- `gcc` with 32-bit support (`-m32` flag)
- `nasm` (Netwide Assembler)
- `ld` (GNU linker)
- `make`
- `qemu-system-i386` (for testing)

**Optional:**
- `grub-mkrescue` or `grub2-mkrescue` (for ISO creation)

**On Fedora/RHEL:**
```bash
sudo dnf install gcc nasm make qemu-system-x86 grub2-tools
```

**On Debian/Ubuntu:**
```bash
sudo apt install gcc nasm make qemu-system-x86 grub2-common xorriso
sudo apt install gcc-multilib  # For 32-bit support
```

### Building

```bash
make                  # Build kernel.bin
make clean            # Clean all build artifacts
make info             # Show build configuration
```

### Running

```bash
make run              # Run in QEMU with GUI
make run-nographic    # Run in QEMU (serial only)
make iso              # Create bootable ISO (ostwo.iso)
```

### Testing

Once booted, try these commands:
```
help        - Show available commands
mem         - Display memory statistics
vmm         - Show virtual memory mappings
ps          - List processes
ls          - List files in RamFS
cat <file>  - Display file contents
testproc    - Test multi-process scheduling
testsyscall - Test DOS API syscalls
```

---

## Architecture

### System Architecture

```
User Mode (Ring 3)
    ↓
 DOS API (dosapi.h)
    ↓
 INT 0x80 Syscall
    ↓
Kernel Mode (Ring 0)
    ↓
 Kernel Services
    ├── Process Manager
    ├── Memory Manager (VMM/PMM)
    ├── Scheduler
    ├── File System (RamFS)
    └── Device Drivers
```

### Memory Layout

```
0x00000000 - 0x003FFFFF : Kernel (identity-mapped, 4MB)
0x00400000 - 0xBFFFEFFF : User space
0xBFFFF000 - 0xBFFFFFFF : User stack (per process)
0xC0000000 - 0xFFFFFFFF : Reserved for future use
```

### Key Files

- `kernel.c` - Main kernel entry point
- `process.c` / `process.h` - Process management
- `scheduler.c` / `scheduler.h` - Round-robin scheduler
- `vmm.c` / `vmm.h` - Virtual memory manager
- `pmm.c` / `pmm.h` - Physical memory manager
- `syscall.c` - System call handler (INT 0x80)
- `dosapi.h` - DOS API inline functions
- `test_proc.c` - Test processes

---

## OS/2 Compatibility Goals

### Target Compatibility

**Binary Compatibility:**
- Load and execute LX (Linear eXecutable) format files
- Support OS/2 DLLs (DOSCALLS.DLL, VIOCALLS.DLL, etc.)
- Import table resolution

**API Compatibility:**
- DOS API (DosXXX functions)
- VIO API (VioXXX functions - text mode)
- KBD API (KbdXXX functions - keyboard)
- MOU API (MouXXX functions - mouse)
- Presentation Manager (PMWIN.DLL - GUI)

**Feature Compatibility:**
- Multi-threading
- Named pipes
- Semaphores (mutex, event, muxwait)
- Queues
- REXX scripting
- CONFIG.SYS parsing

### Non-Goals

- SOM/DSOM compatibility (too complex)
- Multiple architecture support (x86 only for now)
- Workplace Shell (basic version only)
- OS/2 kernel internals (we use modern design)

---

## Development

### Project Structure

```
simpleos/
├── boot.asm          - Multiboot bootloader
├── kernel.c          - Main kernel
├── gdt.c / idt.c     - Descriptor tables
├── pmm.c / vmm.c     - Memory management
├── process.c         - Process manager
├── scheduler.c       - Scheduler
├── syscall.c         - Syscall handler
├── dosapi.h          - DOS API functions
├── vga.c             - VGA text mode driver
├── keyboard.c        - Keyboard driver
├── ramfs.c           - RAM filesystem
├── linker.ld         - Linker script
├── Makefile          - Build system
└── docs/
    ├── OSTWO_ROADMAP.md           - Development roadmap
    └── SYSCALL_SUCCESS_REPORT.md  - Syscall implementation report
```

### Coding Standards

- **Language:** C99 and x86 assembly (NASM syntax)
- **Style:** K&R style, 4-space indentation
- **Naming:**
  - OS/2 API: `DosXXX()`, `VioXXX()`, etc.
  - Internal: `lowercase_with_underscores()`
- **Comments:** Document all public APIs

### Contributing

Contributions welcome! Please:
1. Follow the coding standards
2. Test on QEMU before submitting
3. Document new APIs
4. Update roadmap if adding major features

---

## Roadmap Highlights

### Phase 1: Foundation (Current) ✅
- Basic DOS API
- Process management
- System calls

### Phase 2: Threading (Next)
- Multi-threading support
- DosCreateThread, etc.
- Thread scheduler

### Phase 3: File System
- VFS layer
- FAT16/FAT32 support
- Full file API

### Phase 4: LX Loader
- Parse LX executables
- Load OS/2 programs
- DLL support

### Phase 5: DOS Box
- DOS compatibility
- INT 21h handler
- Run DOS programs

### Phase 6-10: Advanced
- IPC, GUI, drivers, REXX, polish

**See [OSTWO_ROADMAP.md](OSTWO_ROADMAP.md) for complete timeline.**

---

## Documentation

- **[OSTWO_ROADMAP.md](OSTWO_ROADMAP.md)** - Complete development roadmap
- **[SYSCALL_SUCCESS_REPORT.md](SYSCALL_SUCCESS_REPORT.md)** - Syscall implementation details
- **[CLAUDE.md](CLAUDE.md)** - Development notes and architecture

### External Resources

- **OS/2 API Reference:** https://archive.org/details/os2apiref
- **LX Format Specification:** http://www.edm2.com/index.php/LX
- **OS/2 Museum:** http://www.os2museum.com/
- **EDM/2:** http://www.edm2.com/ (OS/2 developer resources)

---

## Why OS/Two?

### Why build an OS/2 clone in 2025?

1. **Nostalgia:** OS/2 was technically superior to Windows 95/98
2. **Learning:** Building an OS teaches low-level programming
3. **Preservation:** Keep OS/2 software accessible
4. **Challenge:** It's a fascinating engineering problem
5. **Legacy:** Some industries still use OS/2 (ATMs, point-of-sale)

### Why not just use ArcaOS?

**ArcaOS** (commercial OS/2 continuation) is great for running real OS/2 on modern hardware. **OS/Two** is different:

- **Open source** - Full source code availability
- **Educational** - Designed for learning
- **Modern** - Clean implementation using modern techniques
- **Experimental** - Can try new ideas without compatibility constraints

---

## FAQ

**Q: Can it run OS/2 Warp applications?**
A: Not yet. LX loader is planned for Phase 4 (~10 months). Currently runs custom test programs.

**Q: Will it have a GUI?**
A: Yes! Presentation Manager clone is planned for Phase 8 (~31 months). Currently text mode only.

**Q: Can it run DOS programs?**
A: Not yet. DOS compatibility box planned for Phase 5 (~14 months).

**Q: What's the performance like?**
A: It's early. Focus is on correctness, not optimization. Performance tuning comes later.

**Q: Can I help?**
A: Yes! Contact the maintainers. We need developers, testers, and documentation writers.

**Q: What license will you use?**
A: Likely MIT or BSD (permissive). Final decision pending.

---

## Credits

**OS/Two** is inspired by:
- **IBM OS/2** - The original operating system
- **Minix** - Educational OS design
- **xv6** - Clean teaching OS
- **Linux** - Modern kernel techniques

**Developed with assistance from:**
- Claude (Anthropic) - AI programming assistant
- The open-source community

---

## License

**To be determined** (likely MIT or BSD)

Copyright (c) 2025 OS/Two Project

---

## Contact

- **Repository:** (GitHub link TBD)
- **Website:** (ostwo.org or os-two.org - TBD)
- **Discord:** (TBD)
- **Email:** (TBD)

---

**OS/Two - Where Classic Meets Modern!**

*The open-source OS/2-compatible operating system for the 21st century.*
