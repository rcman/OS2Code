// File: vga_gfx.c
// VGA Graphics Mode Driver Implementation

#include "vga_gfx.h"
#include "vbe.h"

// External I/O functions
extern void outb(uint16_t port, uint8_t value);
extern uint8_t inb(uint16_t port);
extern void printf(const char* format, ...);
extern void* pmm_alloc_page(void);
extern void pmm_free_page(uint32_t addr);

// Current mode information
static vga_mode_info_t current_mode;
static int vbe_mode_active = 0;

// Double buffering
static uint8_t* back_buffer = NULL;
static int double_buffer_enabled = 0;

// Simple absolute value
static int abs(int x) {
    return x < 0 ? -x : x;
}

// Simple min/max
static int min(int a, int b) {
    return a < b ? a : b;
}

static int max(int a, int b) {
    return a > b ? a : b;
}

// Initialize VGA graphics subsystem
void vga_gfx_init(void) {
    // Start in text mode
    current_mode.width = 80;
    current_mode.height = 25;
    current_mode.bpp = 4;  // 16 colors
    current_mode.mode = VGA_MODE_TEXT_80x25;
    current_mode.framebuffer = (uint8_t*)VGA_TEXT_MEMORY;
    current_mode.pitch = 160;  // 80 chars * 2 bytes per char

    printf("[VGA-GFX] Graphics subsystem initialized\n");
}

// Set VGA video mode
int vga_set_mode(uint8_t mode) {
    // Check if VBE framebuffer is available from bootloader
    vbe_mode_info_t* vbe_info = vbe_get_mode_info();

    if (vbe_info && vbe_info->enabled && mode == VGA_MODE_320x200x256) {
        // Use VBE framebuffer instead of Mode 13h
        current_mode.width = vbe_info->width;
        current_mode.height = vbe_info->height;
        current_mode.bpp = vbe_info->bpp;
        current_mode.mode = mode;
        current_mode.framebuffer = (uint8_t*)vbe_info->framebuffer;
        current_mode.pitch = vbe_info->pitch;
        vbe_mode_active = 1;

        printf("[VGA-GFX] Using VBE mode: %dx%dx%d, FB=0x%x\n",
               vbe_info->width, vbe_info->height, vbe_info->bpp, vbe_info->framebuffer);
        return 0;
    }

    // Fall back to legacy Mode 13h
    vbe_mode_active = 0;

    if (mode == VGA_MODE_320x200x256) {
        // Mode 13h: 320x200 256-color graphics mode

        // Write mode to VGA registers
        outb(VGA_MISC_WRITE, 0x63);

        // Sequencer registers
        outb(VGA_SEQ_INDEX, 0x00); outb(VGA_SEQ_DATA, 0x03);
        outb(VGA_SEQ_INDEX, 0x01); outb(VGA_SEQ_DATA, 0x01);
        outb(VGA_SEQ_INDEX, 0x02); outb(VGA_SEQ_DATA, 0x0F);
        outb(VGA_SEQ_INDEX, 0x03); outb(VGA_SEQ_DATA, 0x00);
        outb(VGA_SEQ_INDEX, 0x04); outb(VGA_SEQ_DATA, 0x0E);

        // Unlock CRTC registers
        outb(VGA_CRTC_INDEX, 0x03); outb(VGA_CRTC_DATA, inb(VGA_CRTC_DATA) | 0x80);
        outb(VGA_CRTC_INDEX, 0x11); outb(VGA_CRTC_DATA, inb(VGA_CRTC_DATA) & ~0x80);

        // CRTC registers for 320x200
        uint8_t crtc_regs[] = {
            0x5F, 0x4F, 0x50, 0x82, 0x54, 0x80, 0xBF, 0x1F,
            0x00, 0x41, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x9C, 0x0E, 0x8F, 0x28, 0x40, 0x96, 0xB9, 0xA3, 0xFF
        };
        for (int i = 0; i < 25; i++) {
            outb(VGA_CRTC_INDEX, i);
            outb(VGA_CRTC_DATA, crtc_regs[i]);
        }

        // Graphics controller registers
        outb(VGA_GC_INDEX, 0x00); outb(VGA_GC_DATA, 0x00);
        outb(VGA_GC_INDEX, 0x01); outb(VGA_GC_DATA, 0x00);
        outb(VGA_GC_INDEX, 0x02); outb(VGA_GC_DATA, 0x00);
        outb(VGA_GC_INDEX, 0x03); outb(VGA_GC_DATA, 0x00);
        outb(VGA_GC_INDEX, 0x04); outb(VGA_GC_DATA, 0x00);
        outb(VGA_GC_INDEX, 0x05); outb(VGA_GC_DATA, 0x40);
        outb(VGA_GC_INDEX, 0x06); outb(VGA_GC_DATA, 0x05);
        outb(VGA_GC_INDEX, 0x07); outb(VGA_GC_DATA, 0x0F);
        outb(VGA_GC_INDEX, 0x08); outb(VGA_GC_DATA, 0xFF);

        // Attribute controller registers
        for (int i = 0; i < 16; i++) {
            inb(VGA_INPUT_STATUS);  // Reset flip-flop
            outb(VGA_ATTR_INDEX, i);
            outb(VGA_ATTR_DATA_WRITE, i);
        }
        inb(VGA_INPUT_STATUS);
        outb(VGA_ATTR_INDEX, 0x10); outb(VGA_ATTR_DATA_WRITE, 0x41);
        inb(VGA_INPUT_STATUS);
        outb(VGA_ATTR_INDEX, 0x11); outb(VGA_ATTR_DATA_WRITE, 0x00);
        inb(VGA_INPUT_STATUS);
        outb(VGA_ATTR_INDEX, 0x12); outb(VGA_ATTR_DATA_WRITE, 0x0F);
        inb(VGA_INPUT_STATUS);
        outb(VGA_ATTR_INDEX, 0x13); outb(VGA_ATTR_DATA_WRITE, 0x00);
        inb(VGA_INPUT_STATUS);
        outb(VGA_ATTR_INDEX, 0x14); outb(VGA_ATTR_DATA_WRITE, 0x00);
        inb(VGA_INPUT_STATUS);
        outb(VGA_ATTR_INDEX, 0x20);  // Enable video

        // Update mode info
        current_mode.width = 320;
        current_mode.height = 200;
        current_mode.bpp = 8;  // 256 colors
        current_mode.mode = mode;
        current_mode.framebuffer = (uint8_t*)VGA_GFX_MEMORY;
        current_mode.pitch = 320;

        // Set default palette
        vga_set_default_palette();

        printf("[VGA-GFX] Set mode 13h (320x200x256)\n");
        return 0;
    }

    return -1;  // Unsupported mode
}

// Get current mode information
vga_mode_info_t* vga_get_mode_info(void) {
    return &current_mode;
}

// Convert 8-bit palette color to 32-bit RGB
static uint32_t palette_to_rgb(uint8_t color) {
    // Standard VGA 16-color palette
    static const uint32_t vga_palette[16] = {
        0x000000,  // 0: Black
        0x0000AA,  // 1: Blue
        0x00AA00,  // 2: Green
        0x00AAAA,  // 3: Cyan
        0xAA0000,  // 4: Red
        0xAA00AA,  // 5: Magenta
        0xAA5500,  // 6: Brown
        0xAAAAAA,  // 7: Light Gray
        0x555555,  // 8: Dark Gray
        0x5555FF,  // 9: Light Blue
        0x55FF55,  // 10: Light Green
        0x55FFFF,  // 11: Light Cyan
        0xFF5555,  // 12: Light Red
        0xFF55FF,  // 13: Light Magenta
        0xFFFF55,  // 14: Yellow
        0xFFFFFF   // 15: White
    };

    // Use lookup table for standard 16 colors
    if (color < 16) {
        return vga_palette[color];
    }

    // For colors 16-255, use a simple RGB mapping
    // Colors 16-231: 6x6x6 color cube
    if (color >= 16 && color <= 231) {
        uint8_t idx = color - 16;
        uint8_t r = (idx / 36) * 51;
        uint8_t g = ((idx / 6) % 6) * 51;
        uint8_t b = (idx % 6) * 51;
        return (r << 16) | (g << 8) | b;
    }

    // Colors 232-255: grayscale
    uint8_t gray = (color - 232) * 10 + 8;
    return (gray << 16) | (gray << 8) | gray;
}

// Clear screen with color
void vga_clear_screen(uint8_t color) {
    uint8_t* fb = double_buffer_enabled ? back_buffer : current_mode.framebuffer;
    uint32_t pixels = current_mode.width * current_mode.height;

    if (current_mode.bpp == 32) {
        // 32-bit color mode
        uint32_t* fb32 = (uint32_t*)fb;
        uint32_t rgb_color = palette_to_rgb(color);
        for (uint32_t i = 0; i < pixels; i++) {
            fb32[i] = rgb_color;
        }
    } else {
        // 8-bit color mode
        for (uint32_t i = 0; i < pixels; i++) {
            fb[i] = color;
        }
    }
}

// Plot a pixel
void vga_plot_pixel(int x, int y, uint8_t color) {
    if (x < 0 || x >= (int)current_mode.width || y < 0 || y >= (int)current_mode.height) {
        return;  // Out of bounds
    }

    uint8_t* fb = double_buffer_enabled ? back_buffer : current_mode.framebuffer;

    if (current_mode.bpp == 32) {
        // 32-bit color mode
        uint32_t* fb32 = (uint32_t*)fb;
        uint32_t offset = y * (current_mode.pitch / 4) + x;
        fb32[offset] = palette_to_rgb(color);
    } else {
        // 8-bit color mode
        fb[y * current_mode.pitch + x] = color;
    }
}

// Get pixel color
uint8_t vga_get_pixel(int x, int y) {
    if (x < 0 || x >= (int)current_mode.width || y < 0 || y >= (int)current_mode.height) {
        return 0;  // Out of bounds
    }

    uint8_t* fb = double_buffer_enabled ? back_buffer : current_mode.framebuffer;
    return fb[y * current_mode.pitch + x];
}

// Draw a line (Bresenham's algorithm)
void vga_draw_line(int x1, int y1, int x2, int y2, uint8_t color) {
    int dx = abs(x2 - x1);
    int dy = abs(y2 - y1);
    int sx = x1 < x2 ? 1 : -1;
    int sy = y1 < y2 ? 1 : -1;
    int err = dx - dy;

    while (1) {
        vga_plot_pixel(x1, y1, color);

        if (x1 == x2 && y1 == y2) break;

        int e2 = 2 * err;
        if (e2 > -dy) {
            err -= dy;
            x1 += sx;
        }
        if (e2 < dx) {
            err += dx;
            y1 += sy;
        }
    }
}

// Draw a rectangle (outline)
void vga_draw_rect(int x, int y, int width, int height, uint8_t color) {
    // Top and bottom edges
    for (int i = 0; i < width; i++) {
        vga_plot_pixel(x + i, y, color);
        vga_plot_pixel(x + i, y + height - 1, color);
    }

    // Left and right edges
    for (int i = 0; i < height; i++) {
        vga_plot_pixel(x, y + i, color);
        vga_plot_pixel(x + width - 1, y + i, color);
    }
}

// Draw a filled rectangle
void vga_fill_rect(int x, int y, int width, int height, uint8_t color) {
    for (int j = 0; j < height; j++) {
        for (int i = 0; i < width; i++) {
            vga_plot_pixel(x + i, y + j, color);
        }
    }
}

// Draw a circle (Midpoint circle algorithm)
void vga_draw_circle(int cx, int cy, int radius, uint8_t color) {
    int x = radius;
    int y = 0;
    int err = 0;

    while (x >= y) {
        vga_plot_pixel(cx + x, cy + y, color);
        vga_plot_pixel(cx + y, cy + x, color);
        vga_plot_pixel(cx - y, cy + x, color);
        vga_plot_pixel(cx - x, cy + y, color);
        vga_plot_pixel(cx - x, cy - y, color);
        vga_plot_pixel(cx - y, cy - x, color);
        vga_plot_pixel(cx + y, cy - x, color);
        vga_plot_pixel(cx + x, cy - y, color);

        if (err <= 0) {
            y += 1;
            err += 2 * y + 1;
        }

        if (err > 0) {
            x -= 1;
            err -= 2 * x + 1;
        }
    }
}

// Draw a filled circle
void vga_fill_circle(int cx, int cy, int radius, uint8_t color) {
    for (int y = -radius; y <= radius; y++) {
        for (int x = -radius; x <= radius; x++) {
            if (x * x + y * y <= radius * radius) {
                vga_plot_pixel(cx + x, cy + y, color);
            }
        }
    }
}

// Complete 8x8 font (ASCII 32-126)
static const uint8_t font_8x8[128][8] = {
    [0]   = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}, // NUL
    [32]  = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}, // Space
    [33]  = {0x18, 0x3C, 0x3C, 0x18, 0x18, 0x00, 0x18, 0x00}, // !
    [34]  = {0x36, 0x36, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}, // "
    [35]  = {0x36, 0x36, 0x7F, 0x36, 0x7F, 0x36, 0x36, 0x00}, // #
    [36]  = {0x0C, 0x3E, 0x03, 0x1E, 0x30, 0x1F, 0x0C, 0x00}, // $
    [37]  = {0x00, 0x63, 0x33, 0x18, 0x0C, 0x66, 0x63, 0x00}, // %
    [38]  = {0x1C, 0x36, 0x1C, 0x6E, 0x3B, 0x33, 0x6E, 0x00}, // &
    [39]  = {0x06, 0x06, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00}, // '
    [40]  = {0x18, 0x0C, 0x06, 0x06, 0x06, 0x0C, 0x18, 0x00}, // (
    [41]  = {0x06, 0x0C, 0x18, 0x18, 0x18, 0x0C, 0x06, 0x00}, // )
    [42]  = {0x00, 0x66, 0x3C, 0xFF, 0x3C, 0x66, 0x00, 0x00}, // *
    [43]  = {0x00, 0x0C, 0x0C, 0x3F, 0x0C, 0x0C, 0x00, 0x00}, // +
    [44]  = {0x00, 0x00, 0x00, 0x00, 0x00, 0x0C, 0x0C, 0x06}, // ,
    [45]  = {0x00, 0x00, 0x00, 0x3F, 0x00, 0x00, 0x00, 0x00}, // -
    [46]  = {0x00, 0x00, 0x00, 0x00, 0x00, 0x0C, 0x0C, 0x00}, // .
    [47]  = {0x60, 0x30, 0x18, 0x0C, 0x06, 0x03, 0x01, 0x00}, // /
    [48]  = {0x3E, 0x63, 0x73, 0x7B, 0x6F, 0x67, 0x3E, 0x00}, // 0
    [49]  = {0x0C, 0x0E, 0x0C, 0x0C, 0x0C, 0x0C, 0x3F, 0x00}, // 1
    [50]  = {0x1E, 0x33, 0x30, 0x1C, 0x06, 0x33, 0x3F, 0x00}, // 2
    [51]  = {0x1E, 0x33, 0x30, 0x1C, 0x30, 0x33, 0x1E, 0x00}, // 3
    [52]  = {0x38, 0x3C, 0x36, 0x33, 0x7F, 0x30, 0x78, 0x00}, // 4
    [53]  = {0x3F, 0x03, 0x1F, 0x30, 0x30, 0x33, 0x1E, 0x00}, // 5
    [54]  = {0x1C, 0x06, 0x03, 0x1F, 0x33, 0x33, 0x1E, 0x00}, // 6
    [55]  = {0x3F, 0x33, 0x30, 0x18, 0x0C, 0x0C, 0x0C, 0x00}, // 7
    [56]  = {0x1E, 0x33, 0x33, 0x1E, 0x33, 0x33, 0x1E, 0x00}, // 8
    [57]  = {0x1E, 0x33, 0x33, 0x3E, 0x30, 0x18, 0x0E, 0x00}, // 9
    [58]  = {0x00, 0x0C, 0x0C, 0x00, 0x00, 0x0C, 0x0C, 0x00}, // :
    [59]  = {0x00, 0x0C, 0x0C, 0x00, 0x00, 0x0C, 0x0C, 0x06}, // ;
    [60]  = {0x18, 0x0C, 0x06, 0x03, 0x06, 0x0C, 0x18, 0x00}, // <
    [61]  = {0x00, 0x00, 0x3F, 0x00, 0x00, 0x3F, 0x00, 0x00}, // =
    [62]  = {0x06, 0x0C, 0x18, 0x30, 0x18, 0x0C, 0x06, 0x00}, // >
    [63]  = {0x1E, 0x33, 0x30, 0x18, 0x0C, 0x00, 0x0C, 0x00}, // ?
    [64]  = {0x3E, 0x63, 0x7B, 0x7B, 0x7B, 0x03, 0x1E, 0x00}, // @
    [65]  = {0x0C, 0x1E, 0x33, 0x33, 0x3F, 0x33, 0x33, 0x00}, // A
    [66]  = {0x3F, 0x66, 0x66, 0x3E, 0x66, 0x66, 0x3F, 0x00}, // B
    [67]  = {0x3C, 0x66, 0x03, 0x03, 0x03, 0x66, 0x3C, 0x00}, // C
    [68]  = {0x1F, 0x36, 0x66, 0x66, 0x66, 0x36, 0x1F, 0x00}, // D
    [69]  = {0x7F, 0x46, 0x16, 0x1E, 0x16, 0x46, 0x7F, 0x00}, // E
    [70]  = {0x7F, 0x46, 0x16, 0x1E, 0x16, 0x06, 0x0F, 0x00}, // F
    [71]  = {0x3C, 0x66, 0x03, 0x03, 0x73, 0x66, 0x7C, 0x00}, // G
    [72]  = {0x33, 0x33, 0x33, 0x3F, 0x33, 0x33, 0x33, 0x00}, // H
    [73]  = {0x1E, 0x0C, 0x0C, 0x0C, 0x0C, 0x0C, 0x1E, 0x00}, // I
    [74]  = {0x78, 0x30, 0x30, 0x30, 0x33, 0x33, 0x1E, 0x00}, // J
    [75]  = {0x67, 0x66, 0x36, 0x1E, 0x36, 0x66, 0x67, 0x00}, // K
    [76]  = {0x0F, 0x06, 0x06, 0x06, 0x46, 0x66, 0x7F, 0x00}, // L
    [77]  = {0x63, 0x77, 0x7F, 0x7F, 0x6B, 0x63, 0x63, 0x00}, // M
    [78]  = {0x63, 0x67, 0x6F, 0x7B, 0x73, 0x63, 0x63, 0x00}, // N
    [79]  = {0x1C, 0x36, 0x63, 0x63, 0x63, 0x36, 0x1C, 0x00}, // O
    [80]  = {0x3F, 0x66, 0x66, 0x3E, 0x06, 0x06, 0x0F, 0x00}, // P
    [81]  = {0x1E, 0x33, 0x33, 0x33, 0x3B, 0x1E, 0x38, 0x00}, // Q
    [82]  = {0x3F, 0x66, 0x66, 0x3E, 0x36, 0x66, 0x67, 0x00}, // R
    [83]  = {0x1E, 0x33, 0x07, 0x0E, 0x38, 0x33, 0x1E, 0x00}, // S
    [84]  = {0x3F, 0x2D, 0x0C, 0x0C, 0x0C, 0x0C, 0x1E, 0x00}, // T
    [85]  = {0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x3F, 0x00}, // U
    [86]  = {0x33, 0x33, 0x33, 0x33, 0x33, 0x1E, 0x0C, 0x00}, // V
    [87]  = {0x63, 0x63, 0x63, 0x6B, 0x7F, 0x77, 0x63, 0x00}, // W
    [88]  = {0x63, 0x63, 0x36, 0x1C, 0x1C, 0x36, 0x63, 0x00}, // X
    [89]  = {0x33, 0x33, 0x33, 0x1E, 0x0C, 0x0C, 0x1E, 0x00}, // Y
    [90]  = {0x7F, 0x63, 0x31, 0x18, 0x4C, 0x66, 0x7F, 0x00}, // Z
    [91]  = {0x1E, 0x06, 0x06, 0x06, 0x06, 0x06, 0x1E, 0x00}, // [
    [92]  = {0x03, 0x06, 0x0C, 0x18, 0x30, 0x60, 0x40, 0x00}, // backslash
    [93]  = {0x1E, 0x18, 0x18, 0x18, 0x18, 0x18, 0x1E, 0x00}, // ]
    [94]  = {0x08, 0x1C, 0x36, 0x63, 0x00, 0x00, 0x00, 0x00}, // ^
    [95]  = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xFF}, // _
    [96]  = {0x0C, 0x0C, 0x18, 0x00, 0x00, 0x00, 0x00, 0x00}, // `
    [97]  = {0x00, 0x00, 0x1E, 0x30, 0x3E, 0x33, 0x6E, 0x00}, // a
    [98]  = {0x07, 0x06, 0x06, 0x3E, 0x66, 0x66, 0x3B, 0x00}, // b
    [99]  = {0x00, 0x00, 0x1E, 0x33, 0x03, 0x33, 0x1E, 0x00}, // c
    [100] = {0x38, 0x30, 0x30, 0x3e, 0x33, 0x33, 0x6E, 0x00}, // d
    [101] = {0x00, 0x00, 0x1E, 0x33, 0x3f, 0x03, 0x1E, 0x00}, // e
    [102] = {0x1C, 0x36, 0x06, 0x0f, 0x06, 0x06, 0x0F, 0x00}, // f
    [103] = {0x00, 0x00, 0x6E, 0x33, 0x33, 0x3E, 0x30, 0x1F}, // g
    [104] = {0x07, 0x06, 0x36, 0x6E, 0x66, 0x66, 0x67, 0x00}, // h
    [105] = {0x0C, 0x00, 0x0E, 0x0C, 0x0C, 0x0C, 0x1E, 0x00}, // i
    [106] = {0x30, 0x00, 0x30, 0x30, 0x30, 0x33, 0x33, 0x1E}, // j
    [107] = {0x07, 0x06, 0x66, 0x36, 0x1E, 0x36, 0x67, 0x00}, // k
    [108] = {0x0E, 0x0C, 0x0C, 0x0C, 0x0C, 0x0C, 0x1E, 0x00}, // l
    [109] = {0x00, 0x00, 0x33, 0x7F, 0x7F, 0x6B, 0x63, 0x00}, // m
    [110] = {0x00, 0x00, 0x1F, 0x33, 0x33, 0x33, 0x33, 0x00}, // n
    [111] = {0x00, 0x00, 0x1E, 0x33, 0x33, 0x33, 0x1E, 0x00}, // o
    [112] = {0x00, 0x00, 0x3B, 0x66, 0x66, 0x3E, 0x06, 0x0F}, // p
    [113] = {0x00, 0x00, 0x6E, 0x33, 0x33, 0x3E, 0x30, 0x78}, // q
    [114] = {0x00, 0x00, 0x3B, 0x6E, 0x66, 0x06, 0x0F, 0x00}, // r
    [115] = {0x00, 0x00, 0x3E, 0x03, 0x1E, 0x30, 0x1F, 0x00}, // s
    [116] = {0x08, 0x0C, 0x3E, 0x0C, 0x0C, 0x2C, 0x18, 0x00}, // t
    [117] = {0x00, 0x00, 0x33, 0x33, 0x33, 0x33, 0x6E, 0x00}, // u
    [118] = {0x00, 0x00, 0x33, 0x33, 0x33, 0x1E, 0x0C, 0x00}, // v
    [119] = {0x00, 0x00, 0x63, 0x6B, 0x7F, 0x7F, 0x36, 0x00}, // w
    [120] = {0x00, 0x00, 0x63, 0x36, 0x1C, 0x36, 0x63, 0x00}, // x
    [121] = {0x00, 0x00, 0x33, 0x33, 0x33, 0x3E, 0x30, 0x1F}, // y
    [122] = {0x00, 0x00, 0x3F, 0x19, 0x0C, 0x26, 0x3F, 0x00}, // z
    [123] = {0x38, 0x0C, 0x0C, 0x07, 0x0C, 0x0C, 0x38, 0x00}, // {
    [124] = {0x18, 0x18, 0x18, 0x00, 0x18, 0x18, 0x18, 0x00}, // |
    [125] = {0x07, 0x0C, 0x0C, 0x38, 0x0C, 0x0C, 0x07, 0x00}, // }
    [126] = {0x6E, 0x3B, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}, // ~
};

// Draw text character
void vga_draw_char(int x, int y, char c, uint8_t color) {
    if (c < 0 || c >= 128) return;

    for (int row = 0; row < 8; row++) {
        uint8_t byte = font_8x8[(int)c][row];
        for (int col = 0; col < 8; col++) {
            if (byte & (1 << col)) {
                vga_plot_pixel(x + col, y + row, color);
            }
        }
    }
}

// Draw text string
void vga_draw_string(int x, int y, const char* str, uint8_t color) {
    int cx = x;
    while (*str) {
        vga_draw_char(cx, y, *str, color);
        cx += 8;
        str++;
    }
}

// Double buffering
void vga_enable_double_buffer(void) {
    if (!back_buffer) {
        // Allocate back buffer (64KB for 320x200)
        back_buffer = (uint8_t*)pmm_alloc_page();
        if (back_buffer) {
            // Allocate more pages if needed
            for (int i = 1; i < 16; i++) {  // 16 pages = 64KB
                pmm_alloc_page();
            }
        }
    }

    if (back_buffer) {
        double_buffer_enabled = 1;
        printf("[VGA-GFX] Double buffering enabled\n");
    }
}

void vga_disable_double_buffer(void) {
    double_buffer_enabled = 0;
}

void vga_swap_buffers(void) {
    if (!double_buffer_enabled || !back_buffer) return;

    // Copy back buffer to front buffer
    uint8_t* front = current_mode.framebuffer;
    uint32_t size = current_mode.width * current_mode.height;

    for (uint32_t i = 0; i < size; i++) {
        front[i] = back_buffer[i];
    }
}

// Palette operations
void vga_set_palette(uint8_t index, uint8_t r, uint8_t g, uint8_t b) {
    outb(VGA_DAC_WRITE_INDEX, index);
    outb(VGA_DAC_DATA, r >> 2);  // VGA uses 6-bit color
    outb(VGA_DAC_DATA, g >> 2);
    outb(VGA_DAC_DATA, b >> 2);
}

void vga_get_palette(uint8_t index, uint8_t* r, uint8_t* g, uint8_t* b) {
    outb(VGA_DAC_READ_INDEX, index);
    *r = inb(VGA_DAC_DATA) << 2;
    *g = inb(VGA_DAC_DATA) << 2;
    *b = inb(VGA_DAC_DATA) << 2;
}

void vga_set_default_palette(void) {
    // Set default 256-color palette
    // First 16 colors: standard VGA colors
    vga_set_palette(0, 0, 0, 0);           // Black
    vga_set_palette(1, 0, 0, 170);         // Blue
    vga_set_palette(2, 0, 170, 0);         // Green
    vga_set_palette(3, 0, 170, 170);       // Cyan
    vga_set_palette(4, 170, 0, 0);         // Red
    vga_set_palette(5, 170, 0, 170);       // Magenta
    vga_set_palette(6, 170, 85, 0);        // Brown
    vga_set_palette(7, 170, 170, 170);     // Light Gray
    vga_set_palette(8, 85, 85, 85);        // Dark Gray
    vga_set_palette(9, 85, 85, 255);       // Light Blue
    vga_set_palette(10, 85, 255, 85);      // Light Green
    vga_set_palette(11, 85, 255, 255);     // Light Cyan
    vga_set_palette(12, 255, 85, 85);      // Light Red
    vga_set_palette(13, 255, 85, 255);     // Light Magenta
    vga_set_palette(14, 255, 255, 85);     // Yellow
    vga_set_palette(15, 255, 255, 255);    // White

    // Grayscale ramp (16-31)
    for (int i = 0; i < 16; i++) {
        uint8_t val = i * 17;
        vga_set_palette(16 + i, val, val, val);
    }

    // Color gradient (32-255)
    for (int i = 32; i < 256; i++) {
        uint8_t r = ((i - 32) % 8) * 36;
        uint8_t g = (((i - 32) / 8) % 8) * 36;
        uint8_t b = (((i - 32) / 64) % 4) * 85;
        vga_set_palette(i, r, g, b);
    }
}

// Draw bitmap
void vga_draw_bitmap(int x, int y, int width, int height, const uint8_t* bitmap) {
    for (int j = 0; j < height; j++) {
        for (int i = 0; i < width; i++) {
            uint8_t color = bitmap[j * width + i];
            vga_plot_pixel(x + i, y + j, color);
        }
    }
}
