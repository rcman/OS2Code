# OS/Two - OS/2-Compatible Operating System
## Development Roadmap

**Project Vision:** Create a modern, open-source operating system compatible with OS/2 APIs and executables.

**Name:** OS/Two (pronounced "OS Two" - a clever homage to OS/2)

**Current Version:** 0.3 (formerly SimpleOS v0.3)

---

## Phase 1: Foundation & Rebranding ✅ COMPLETE

### 1.1 Branding ✅ COMPLETE
- [x] System call interface (DosWrite, DosExit, DosGetPID)
- [x] Rename "SimpleOS" → "OS/Two" in all files
- [x] Update boot banner
- [ ] Create new logo/branding (optional)
- [x] Update Makefile and build system

### 1.2 Core Security ✅ COMPLETE
- [x] Set IOPL=0 for proper privilege separation
- [x] Test syscall security enforcement
- [x] Implement GPF handler for invalid I/O

### 1.3 Complete Basic DOS API ✅ COMPLETE
- [x] DosWrite (fd, buffer, length)
- [x] DosExit (exitcode)
- [x] DosGetPID ()
- [x] DosExecPgm - Execute program from file (BONUS!)
- [x] DosRead (fd, buffer, length) - Stub for Phase 2
- [x] DosSleep (milliseconds) - Busy-wait implementation
- [x] DosBeep (frequency, duration)
- [x] DosGetDateTime (structure)
- [x] DosSetDateTime (structure)

**Target: 2-3 weeks**

---

## Phase 2: Process & Memory Management (OS/2 Style) ✅ COMPLETE

### 2.1 Advanced Process API ✅
- [x] **DosExecPgm** - Execute program from file (BONUS from Phase 1!)
- [ ] **DosWaitChild** - Wait for child process (deferred)
- [x] **DosKillProcess** - Terminate process by PID
- [x] **DosGetPPID** - Get parent process ID
- [ ] **DosSuspendThread** / **DosResumeThread** - Thread control (deferred)
- [x] **DosSetPriority** - Change process/thread priority

### 2.2 Threading Support ✅
OS/2 is multi-threaded. Implemented:
- [x] Thread structure (separate from process)
- [x] **DosCreateThread** - Create new thread
- [ ] **DosWaitThread** - Wait for thread completion (deferred)
- [x] Per-thread stacks (16KB per thread)
- [ ] Thread-local storage (TLS) (deferred)
- [x] Thread infrastructure (scheduler integration pending)

### 2.3 Memory Management API ✅
- [x] **DosAllocMem** - Allocate memory block
- [x] **DosFreeMem** - Free memory block
- [ ] **DosSetMem** - Change memory attributes (deferred)
- [ ] **DosSubAllocMem** / **DosSubFreeMem** - Suballocation (deferred)
- [ ] **DosGiveSharedMem** / **DosGetSharedMem** - Shared memory (deferred)
- [ ] **DosQueryMem** - Query memory attributes (deferred)

### 2.4 Process Synchronization ✅ BONUS!
- [x] **DosCreateMutexSem** - Create mutex semaphore
- [x] **DosCreateEventSem** - Create event semaphore
- [x] **DosSemRequest** - Acquire/wait on semaphore
- [x] **DosSemClear** - Release/clear semaphore
- [x] **DosSemSet** - Signal event semaphore
- [x] **DosCloseSem** - Close semaphore

**Status: COMPLETE ✅**
**Completion Date: December 2025**
**Documentation: See PHASE2_COMPLETE.md**

---

## Phase 3: File System (HPFS-Inspired)

### 3.1 Virtual File System (VFS)
- [ ] Abstract filesystem interface
- [ ] Mount point support
- [ ] Path parsing (/drive/path/file)
- [ ] Current directory per process

### 3.2 OS/2 File API
- [ ] **DosOpen** - Open file (create/truncate/append modes)
- [ ] **DosClose** - Close file handle
- [ ] **DosRead** / **DosWrite** - File I/O
- [ ] **DosSetFilePtr** - Seek in file
- [ ] **DosQueryFileInfo** / **DosSetFileInfo** - File metadata
- [ ] **DosDelete** - Delete file
- [ ] **DosMkDir** / **DosRmDir** - Directory operations
- [ ] **DosFindFirst** / **DosFindNext** / **DosFindClose** - Directory enumeration

### 3.3 Filesystem Implementation
- [ ] Upgrade RamFS to support long filenames
- [ ] Add directory support to RamFS
- [ ] Implement FAT16/FAT32 driver (DOS compatibility)
- [ ] Optional: HPFS-inspired filesystem (long names, extended attributes)

**Target: 2-3 months**

---

## Phase 4: LX Executable Loader (OS/2 Native Format)

### 4.1 LX Format Parser
OS/2 uses LX (Linear eXecutable) format. Need:
- [ ] Parse LX header
- [ ] Load object table (code/data segments)
- [ ] Parse fixup records (relocations)
- [ ] Import table resolution
- [ ] Export table registration

### 4.2 Dynamic Linking
- [ ] DLL loading subsystem
- [ ] Import binding at load time
- [ ] Lazy binding support
- [ ] DLL reference counting

### 4.3 Standard DLLs
Create OS/Two native DLLs:
- [ ] **DOSCALLS.DLL** - DOS API functions
- [ ] **VIOCALLS.DLL** - Video I/O (text mode)
- [ ] **KBDCALLS.DLL** - Keyboard I/O
- [ ] **MOUCALLS.DLL** - Mouse I/O

**Target: 2-4 months**

---

## Phase 5: DOS Compatibility Box

### 5.1 DOS Emulation Layer
- [ ] Virtual 8086 mode support (or emulation)
- [ ] DOS API INT 21h handler
- [ ] DOS memory layout (conventional, extended, expanded)
- [ ] DOS PSP (Program Segment Prefix)
- [ ] DOS environment variables

### 5.2 DOS Executable Loader
- [ ] MZ (DOS .EXE) format loader
- [ ] COM file loader
- [ ] DOS memory allocation
- [ ] DOS file handles

### 5.3 DOS API Implementation
Implement common INT 21h functions:
- [ ] AH=01h - Character input
- [ ] AH=02h - Character output
- [ ] AH=09h - String output
- [ ] AH=3Dh - Open file
- [ ] AH=3Eh - Close file
- [ ] AH=3Fh - Read file
- [ ] AH=40h - Write file
- [ ] AH=4Ch - Exit program

**Target: 3-4 months**

---

## Phase 6: Synchronization & IPC

### 6.1 OS/2 Synchronization Primitives
- [ ] **DosCreateMutexSem** / **DosCloseMutexSem**
- [ ] **DosRequestMutexSem** / **DosReleaseMutexSem**
- [ ] **DosCreateEventSem** / **DosCloseEventSem**
- [ ] **DosPostEventSem** / **DosWaitEventSem** / **DosResetEventSem**
- [ ] **DosCreateMuxWaitSem** - Wait on multiple semaphores

### 6.2 Named Pipes
- [ ] **DosCreateNPipe** - Create named pipe
- [ ] **DosConnectNPipe** - Wait for client connection
- [ ] **DosDisconnectNPipe** - Disconnect client
- [ ] **DosTransactNPipe** - Bidirectional message transaction

### 6.3 Queues
- [ ] **DosCreateQueue** / **DosCloseQueue**
- [ ] **DosWriteQueue** / **DosReadQueue**
- [ ] **DosPurgeQueue** / **DosQueryQueue**

**Target: 1-2 months**

---

## Phase 7: Device Drivers

### 7.1 OS/2 Device Driver Interface
- [ ] Character device drivers
- [ ] Block device drivers
- [ ] Driver registration/unregistration
- [ ] IOCTL interface

### 7.2 Standard Drivers
- [ ] CON (console)
- [ ] PRN (printer - stub)
- [ ] NUL (null device)
- [ ] CLOCK$ (system clock)
- [ ] SCREEN$ (video)
- [ ] KBD$ (keyboard)
- [ ] MOUSE$ (mouse)

### 7.3 Block Device Support
- [ ] Hard disk driver (ATA/IDE)
- [ ] Floppy disk driver
- [ ] CD-ROM driver (optional)

**Target: 2-3 months**

---

## Phase 8: Presentation Manager (PM) Clone

### 8.1 Graphics Foundation
- [ ] VGA/VESA graphics modes
- [ ] Framebuffer abstraction
- [ ] Basic 2D drawing primitives
- [ ] Bitmap support

### 8.2 Window Management
- [ ] Window structure (HWND)
- [ ] Window messages and message queue
- [ ] **WinCreateWindow** / **WinDestroyWindow**
- [ ] **WinShowWindow** / **WinHideWindow**
- [ ] Z-order management

### 8.3 User Input
- [ ] Mouse cursor
- [ ] Keyboard focus
- [ ] Message dispatch (WM_MOUSEMOVE, WM_CHAR, etc.)

### 8.4 Controls
- [ ] Buttons
- [ ] Text entry fields
- [ ] List boxes
- [ ] Scroll bars
- [ ] Menus

### 8.5 GPI (Graphics Programming Interface)
- [ ] Presentation spaces
- [ ] **GpiSetColor** / **GpiSetBackColor**
- [ ] **GpiMove** / **GpiLine** / **GpiBox**
- [ ] **GpiCharString** - Text output
- [ ] Fonts (basic bitmap fonts)

**Target: 6-12 months (massive undertaking)**

---

## Phase 9: Advanced Features

### 9.1 REXX Scripting
- [ ] REXX interpreter
- [ ] REXX API bindings
- [ ] Standard REXX libraries

### 9.2 Configuration Files
- [ ] CONFIG.SYS parser
- [ ] DEVICE= driver loading
- [ ] SET statements (environment)
- [ ] LIBPATH, PATH support

### 9.3 Workplace Shell (WPS) Basics
- [ ] Object-oriented desktop
- [ ] Folder objects
- [ ] Program objects
- [ ] Drag & drop

### 9.4 Networking
- [ ] TCP/IP stack
- [ ] Sockets API
- [ ] NetBIOS support (optional)

**Target: 1+ years**

---

## Phase 10: Polish & Compatibility

### 10.1 Application Compatibility
Test with real OS/2 applications:
- [ ] Command-line utilities
- [ ] Text-mode applications
- [ ] Simple GUI applications
- [ ] Document compatibility issues

### 10.2 Performance Optimization
- [ ] Profiling and benchmarking
- [ ] Optimize critical paths
- [ ] Memory management tuning
- [ ] Scheduler improvements

### 10.3 Documentation
- [ ] API reference documentation
- [ ] Programming guide
- [ ] User manual
- [ ] Migration guide (from OS/2)

**Target: Ongoing**

---

## Technical Architecture

### OS/Two System Architecture

```
┌─────────────────────────────────────────────────────┐
│                  Applications                        │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐          │
│  │ OS/2 APP │  │ DOS APP  │  │ PM APP   │          │
│  │  (LX)    │  │  (MZ)    │  │  (GUI)   │          │
│  └────┬─────┘  └────┬─────┘  └────┬─────┘          │
└───────┼─────────────┼─────────────┼─────────────────┘
        │             │             │
┌───────┼─────────────┼─────────────┼─────────────────┐
│       ▼             ▼             ▼                  │
│  ┌────────────┐ ┌──────────┐ ┌──────────┐          │
│  │ DOSCALLS   │ │ DOS INT  │ │ PMWIN    │          │
│  │   .DLL     │ │   21h    │ │  .DLL    │          │
│  └──────┬─────┘ └────┬─────┘ └────┬─────┘          │
│         │            │            │                  │
│         └────────────┼────────────┘                  │
│                      ▼                               │
│            ┌──────────────────┐                      │
│            │  System Calls    │                      │
│            │   (INT 0x80)     │                      │
│            └────────┬─────────┘                      │
└─────────────────────┼───────────────────────────────┘
                      ▼
┌─────────────────────────────────────────────────────┐
│                  OS/Two Kernel                       │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐          │
│  │ Process  │  │  Memory  │  │   VFS    │          │
│  │ Manager  │  │  Manager │  │          │          │
│  └──────────┘  └──────────┘  └──────────┘          │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐          │
│  │  Thread  │  │   IPC    │  │ Drivers  │          │
│  │Scheduler │  │ Semaphores│  │          │          │
│  └──────────┘  └──────────┘  └──────────┘          │
└─────────────────────────────────────────────────────┘
                      ▼
┌─────────────────────────────────────────────────────┐
│                   Hardware                           │
│     CPU (x86)  │  Memory  │  Disk  │  VGA           │
└─────────────────────────────────────────────────────┘
```

### Key Design Principles

1. **Binary Compatibility**: Load and run OS/2 LX executables
2. **API Compatibility**: Implement OS/2 API functions accurately
3. **Modern Architecture**: Use modern kernel design (not copy OS/2 internals)
4. **Performance**: Optimize for modern hardware
5. **Open Source**: Full source code availability

---

## Comparison: OS/2 vs OS/Two

| Feature                  | OS/2 Warp 4     | OS/Two (Goal)    |
|--------------------------|-----------------|------------------|
| **Executable Format**    | LX              | LX ✅            |
| **DOS Support**          | Yes             | Yes ✅           |
| **32-bit API**           | Yes             | Yes ✅           |
| **Multi-threading**      | Yes             | Yes ✅           |
| **Presentation Manager** | Yes             | Simplified ✅    |
| **REXX**                 | Yes             | Yes ✅           |
| **Workplace Shell**      | Yes             | Basic ✅         |
| **SOM/DSOM**             | Yes             | No ❌            |
| **Installable FS**       | Yes             | Limited ✅       |
| **Architecture**         | x86, PPC        | x86 only         |
| **Source Code**          | Closed          | Open Source ✅   |

---

## Development Priorities

### Must Have (Core Compatibility)
1. ✅ DOS API (DosXXX functions)
2. LX executable loader
3. Threading support
4. File system (FAT + VFS)
5. DOS compatibility box

### Should Have (Enhanced Features)
1. Presentation Manager basics
2. Device drivers
3. Named pipes & IPC
4. REXX scripting

### Nice to Have (Advanced)
1. Full Workplace Shell
2. SOM/DSOM compatibility
3. Networking stack
4. Multiple architecture support

---

## Resources Needed

### Documentation
- **OS/2 API Reference**: https://archive.org/details/os2apiref
- **LX Format Spec**: http://www.edm2.com/index.php/LX_-_Linear_eXecutable_Module_Format_Description
- **OS/2 Programming Guides**: EDM/2 and Hobbes OS/2 Archive

### Reference Systems
- OS/2 Warp 4 (for testing/comparison)
- ArcaOS (modern OS/2 distribution)
- eComStation (commercial OS/2)

### Development Tools
- OS/2 Toolkit
- Watcom C/C++ (OS/2 version)
- LxLite (LX analyzer)

---

## Success Metrics

### Milestone 1: Boot and Run
- [ ] Boot banner says "OS/Two"
- [ ] Run simple LX executable (hello world)
- [ ] List files with "DIR" command

### Milestone 2: DOS Compatibility
- [ ] Run DOS .COM files
- [ ] Run DOS .EXE files
- [ ] DOS utilities work (COMMAND.COM, etc.)

### Milestone 3: Multi-tasking
- [ ] Multiple processes running concurrently
- [ ] Thread creation/synchronization
- [ ] Semaphores working

### Milestone 4: File Operations
- [ ] Read/write files on FAT filesystem
- [ ] Directory operations
- [ ] File attributes and timestamps

### Milestone 5: GUI
- [ ] Display windows
- [ ] Mouse and keyboard input
- [ ] Simple PM application runs

### Milestone 6: Real Application
- [ ] Run a real OS/2 application (e.g., text editor, game)
- [ ] Application fully functional
- [ ] No crashes or major bugs

---

## Community & Ecosystem

### Potential Community
- OS/2 enthusiasts and retro computing fans
- Developers interested in OS development
- Organizations still using OS/2 legacy software

### License
- Recommend: MIT or BSD (permissive open source)
- Allows commercial use and derivatives
- Credit original OS/2 inspiration

### Website/Repository
- GitHub repository: github.com/username/ostw
- Website: ostwo.org or os-two.org
- Documentation wiki
- Forums/Discord for developers

---

## Timeline Estimate

| Phase | Duration | Cumulative |
|-------|----------|------------|
| Phase 1: Foundation | 3 weeks | 3 weeks |
| Phase 2: Process/Memory | 2 months | 3 months |
| Phase 3: File System | 3 months | 6 months |
| Phase 4: LX Loader | 4 months | 10 months |
| Phase 5: DOS Box | 4 months | 14 months |
| Phase 6: IPC | 2 months | 16 months |
| Phase 7: Drivers | 3 months | 19 months |
| Phase 8: PM GUI | 12 months | 31 months |
| Phase 9: Advanced | 12 months | 43 months |
| Phase 10: Polish | Ongoing | - |

**Estimated time to basic OS/2 compatibility: ~14 months**
**Estimated time to GUI (PM): ~31 months (~2.5 years)**

With a small team (2-3 developers), timeline could be reduced significantly.

---

## Immediate Action Items

1. **Rebrand to OS/Two**
   - Update all source files
   - New boot banner
   - Update documentation

2. **Complete Phase 1**
   - Finish basic DOS API
   - Security hardening (IOPL=0)
   - Test suite for syscalls

3. **Start Phase 2**
   - Research threading models
   - Design thread structure
   - Implement DosCreateThread

4. **Documentation**
   - Create API specification document
   - Write developer guide
   - Set up GitHub repository

---

**Welcome to OS/Two - Where Classic Meets Modern!**

*The open-source OS/2-compatible operating system for the 21st century.*
