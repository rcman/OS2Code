// File: exec.c
// Process execution and return handling

#include "process.h"
#include "vmm.h"
#include "types.h"

extern void printf(const char* format, ...);
extern void process_set_current(process_t* proc);
extern void vmm_switch_page_directory(uint32_t pd);
extern uint32_t vmm_get_current_directory(void);

// Saved kernel return point
static uint32_t saved_kernel_esp = 0;
static uint32_t saved_kernel_ebp = 0;
static uint32_t saved_kernel_eip = 0;
static uint32_t kernel_pd = 0;

// Called by EXIT syscall to return to kernel
void exit_to_kernel(void) {
    printf("[Exec] Returning to kernel...\n");

    // Switch back to kernel page directory
    vmm_switch_page_directory(kernel_pd);

    // Clear current process
    process_set_current(NULL);

    // Restore kernel stack and jump to saved return address
    // This bypasses the syscall handler's IRET which would try to return to user mode
    __asm__ volatile(
        "mov %0, %%esp\n"
        "mov %1, %%ebp\n"
        "jmp *%2\n"
        : : "r"(saved_kernel_esp), "r"(saved_kernel_ebp), "r"(saved_kernel_eip)
        : "memory"
    );

    // Should never reach here
    while(1) { __asm__ volatile("hlt"); }
}

// Assembly function to switch to process
extern void switch_to_process(process_t* proc);

// Run a process and wait for it to exit
void run_process_and_wait(process_t* proc) {
    if (!proc) return;

    // Save kernel state
    kernel_pd = vmm_get_current_directory();

    // Label for return point - exit_to_kernel will jump here
    void* return_point_label = &&return_point;
    saved_kernel_eip = (uint32_t)return_point_label;

    // Save kernel stack pointers
    __asm__ volatile(
        "mov %%esp, %0\n"
        "mov %%ebp, %1\n"
        : "=r"(saved_kernel_esp), "=r"(saved_kernel_ebp)
    );

    // Set as current process
    process_set_current(proc);
    proc->state = PROCESS_STATE_RUNNING;

    // Switch to process page directory
    vmm_switch_page_directory(proc->page_directory);

    printf("[Exec] Starting process '%s' (PID %d)\n", proc->name, proc->pid);

    // Jump to the process - will not return until EXIT syscall
    switch_to_process(proc);

    // This is where exit_to_kernel will jump back to
return_point:
    // If we get here, the process exited successfully
    printf("[Exec] Process completed normally\n");
}
