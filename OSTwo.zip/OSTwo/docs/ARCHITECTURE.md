# OSTwo Architecture

This document describes the high-level architecture of OSTwo, a modern C++ reimplementation of OS/2.

## Overview

OSTwo uses a **microkernel architecture** where the kernel provides only essential services, and most OS/2 functionality is implemented by userspace servers. This design provides:

- Better security through isolation
- Improved stability (crashed servers don't crash the kernel)
- Easier maintenance and debugging
- Modern OS development practices

## System Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                   User Applications                         │
│            (OS/2 executables, LX format)                    │
└────────────────────┬────────────────────────────────────────┘
                     │ OS/2 API calls (DosXXX functions)
┌────────────────────┴────────────────────────────────────────┐
│                  OS/2 API Library                           │
│         (libos2api - Modern C++ implementation)             │
└────────────────────┬────────────────────────────────────────┘
                     │ IPC Messages
┌────────────────────┴────────────────────────────────────────┐
│              Userspace Servers                              │
│  ┌─────────┐  ┌─────────┐  ┌──────────┐  ┌──────────────┐ │
│  │  Exec   │  │  OS/2   │  │   DOS    │  │  Filesystem  │ │
│  │ Server  │  │ Server  │  │  Server  │  │    Server    │ │
│  └─────────┘  └─────────┘  └──────────┘  └──────────────┘ │
└────────────────────┬────────────────────────────────────────┘
                     │ System Calls
┌────────────────────┴────────────────────────────────────────┐
│                    OSTwo Kernel                             │
│  ┌──────────────────────────────────────────────────────┐  │
│  │  Memory Mgmt  │  Process Mgmt  │  IPC  │  Interrupts │  │
│  └──────────────────────────────────────────────────────┘  │
└────────────────────┬────────────────────────────────────────┘
                     │
                 Hardware
```

## Kernel Components

### 1. Memory Management

**Physical Memory Manager** (`kernel/memory.cpp`)
- Manages physical RAM using a bitmap allocator
- Tracks free and used pages (4KB pages)
- Provides page allocation/deallocation

**Virtual Memory Manager** (`kernel/memory.cpp`)
- Manages virtual address spaces for processes
- Maps virtual to physical addresses using page tables
- Creates and switches between address spaces
- Handles page faults (TODO)

**Kernel Heap** (`kernel/memory.cpp`)
- Provides malloc/free for kernel code
- Uses a first-fit allocator with block merging
- No standard library dependencies

### 2. Process and Thread Management

**Process Manager** (`kernel/process.cpp`)
- Creates and terminates processes
- Manages Process Control Blocks (PCBs)
- Each process has its own address space
- Supports multiple threads per process

**Thread Manager** (`kernel/process.cpp`)
- Creates and terminates threads
- Thread Control Blocks (TCBs) store CPU context
- Priority-based scheduling (5 priority levels)
- Round-robin within each priority level

**Scheduler** (`kernel/process.cpp`)
- Preemptive multitasking
- Priority queues for ready threads
- Context switching saves/restores CPU registers
- System calls: yield(), sleep(), getpid(), gettid()

### 3. Inter-Process Communication (IPC)

**IPC Manager** (`kernel/ipc.cpp`)
- Message-based communication between processes/servers
- Endpoints: Server, Client, and Channel types
- Message queue per endpoint
- Shared memory support for large data transfers

**IPC Primitives:**
- `send()` - Asynchronous message send
- `receive()` - Receive message from queue
- `call()` - Synchronous RPC-style call
- `reply()` - Reply to a call

### 4. Interrupt Handling

**Interrupt Manager** (`kernel/interrupt.hpp`)
- IDT (Interrupt Descriptor Table) setup
- Hardware interrupt routing
- Exception handlers
- System call interface (int 0x80)

## Userspace Components

### Servers

**Exec Server** (`servers/exec/`)
- Handles process execution (DosExecPgm)
- Loads executables using LX loader
- Process termination and management
- Communicates via IPC with OS/2 API library

**OS/2 Server** (TODO: `servers/os2/`)
- Implements OS/2-specific features
- Presentation Manager (PM) support (future)
- Workplace Shell functionality (future)

**DOS Server** (TODO: `servers/dos/`)
- DOS compatibility layer
- DOS API translation
- VDM (Virtual DOS Machine) support

**Filesystem Server** (TODO)
- FAT32 and JFS filesystem support
- File I/O operations
- Directory management

### OS/2 API Library

**libos2api** (`libraries/os2api/`)
- Modern C++ implementation of OS/2 APIs
- Maintains binary compatibility with classic OS/2
- Translates DosXXX calls to IPC messages
- Links with user applications

**Key modules:**
- `doscalls.cpp` - Core DosXXX functions
- Process/thread management
- Memory management
- File I/O
- Semaphores and synchronization
- Named pipes
- Shared memory

### Loaders

**LX Loader** (`loaders/lx/`)
- Loads OS/2 LX (Linear Executable) format
- Supports executables and DLLs
- Handles:
  - Object/segment loading
  - Fixup processing (relocations)
  - Import resolution
  - Export table management
- Compatible with OS/2 Warp 4 binaries

## Boot Process

1. **BIOS/UEFI** loads multiboot-compliant bootloader
2. **Bootloader** (`boot/boot.asm`)
   - Sets up initial stack
   - Passes multiboot info to kernel
   - Jumps to `kernel_main()`
3. **Kernel Initialization**
   - VGA console setup
   - Physical memory manager init
   - Virtual memory manager init
   - Kernel heap init
   - Process manager init
   - IPC manager init
4. **Server Startup**
   - Exec server launched
   - OS/2 server launched
   - Filesystem server launched
5. **System Ready**
   - Kernel enters idle loop
   - User applications can be launched

## Memory Layout

### Kernel Space (0x00000000 - 0x7FFFFFFF)

```
0x00000000 - 0x000FFFFF   : Real mode region (reserved)
0x00100000 - 0x001FFFFF   : Kernel code and data
0x00200000 - 0x005FFFFF   : Kernel heap (4MB)
0x00600000 - 0x0FFFFFFF   : Kernel modules and drivers
0x10000000 - 0x7FFFFFFF   : Kernel reserved
```

### User Space (0x80000000 - 0xFFFFFFFF)

```
0x00010000 - 0x003FFFFF   : LX executable code/data
0x00400000 - 0x7FFFFFFF   : User heap and memory allocations
0x80000000 - 0xBFFFFFFF   : Shared memory regions
0xC0000000 - 0xFFFFFFFF   : User stack space
```

## Synchronization

- **Mutexes**: Provided by DosCreateMutexSem API
- **Event Semaphores**: DosCreateEventSem API
- **Kernel-level**: InterruptGuard for interrupt-safe critical sections

## OS/2 Compatibility

OSTwo aims for **OS/2 Warp 4 (Merlin)** API compatibility:

- Binary compatibility with OS/2 LX executables
- DOS compatibility layer (no Windows support)
- System Object Model (SOM) in C++
- Workplace Shell (future)
- Presentation Manager (future)

## Design Principles

1. **Modern C++**: C++17 standard, RAII, type safety
2. **No exceptions in kernel**: -fno-exceptions for kernel/drivers
3. **Minimal kernel**: Keep kernel small, move functionality to userspace
4. **Message-based IPC**: Servers communicate via messages, not shared memory
5. **Security**: Process isolation, capability-based security (future)

## Future Enhancements

- [ ] SMP (multi-processor) support
- [ ] Advanced scheduling (deadline scheduling, real-time)
- [ ] Memory protection and guard pages
- [ ] Demand paging and swap support
- [ ] Device driver framework
- [ ] Network stack
- [ ] Graphics subsystem
- [ ] Presentation Manager
- [ ] Workplace Shell

## Development Status

**Current**: Alpha 0.0.1
- Core kernel subsystems implemented
- Basic IPC working
- OS/2 API library skeleton
- LX loader framework
- Exec server foundation

**Next Steps**:
1. Complete interrupt handling
2. Implement filesystem server
3. Finish LX loader fixup processing
4. Add device drivers
5. Port basic OS/2 utilities
