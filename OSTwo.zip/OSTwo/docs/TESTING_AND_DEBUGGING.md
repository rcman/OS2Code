# OSTwo Testing and Debugging Guide

## Overview

This document provides guidance on testing and debugging the OSTwo kernel.

## Test Suite

### Running Tests

```bash
# Build and run all tests
cd build
cmake ..
cmake --build .
ctest

# Run specific test labels
ctest -L integration    # Integration tests only
ctest -L boot           # Boot tests only

# Verbose output
ctest -V

# Run tests in parallel
ctest -j4
```

### Available Tests

#### Boot Verification Test (`BootVerification`)
- **Purpose**: Verifies the kernel builds correctly and has expected structure
- **Checks**:
  - CPU initialization occurs
  - Multiboot header section is present
  - kernel_main symbol exists
  - Kernel size is reasonable (1KB - 10MB)
- **Duration**: ~3-4 seconds
- **Script**: `tests/verify_boot.sh`

#### Kernel Boot Test (`KernelBootTest`)
- **Purpose**: Interactive boot test in QEMU with visual output
- **Duration**: ~15 seconds (includes timeout)
- **Script**: `test-boot.sh`
- **Usage**: For manual verification of boot sequence and console output

### Unit Tests (Future)

Unit tests for kernel components (memory, process, IPC managers) are implemented in:
- `tests/test_memory.cpp`
- `tests/test_process.cpp`
- `tests/test_ipc.cpp`

These require a separate build configuration due to the kernel's use of `-ffreestanding -nostdlib -fno-exceptions`. They will be enabled in a future update using a mock/stub approach or separate test harness.

## Debugging

### Boot Debugging

The kernel bootloader (`boot_header.asm`) writes diagnostic characters to the VGA buffer at specific stages:

| Character | Stage | Address |
|-----------|-------|---------|
| `B` | Entered boot code | 0xB8000 |
| `C` | Long mode supported | 0xB8002 |
| `P` | Page tables set up | 0xB8004 |
| `E` | Paging enabled | 0xB8006 |
| `L` | Entered long mode | 0xB8004 (overwrites P) |
| `N` | No long mode (error) | 0xB8002 (red) |

To view these during boot:
1. Run with QEMU display enabled
2. Boot will show these characters in top-left corner
3. If boot hangs, the last character shows how far boot progressed

### QEMU Debugging Options

```bash
# Boot with serial output
qemu-system-x86_64 -cdrom ostwo.iso -m 512M -serial stdio

# Boot with CPU state logging
qemu-system-x86_64 -cdrom ostwo.iso -m 512M -d cpu_reset -D cpu.log

# Boot with GDB server (for source-level debugging)
qemu-system-x86_64 -cdrom ostwo.iso -m 512M -s -S
# In another terminal:
# gdb build/kernel/ostwo_kernel.elf
# (gdb) target remote localhost:1234
# (gdb) break kernel_main
# (gdb) continue

# Boot with interrupt logging
qemu-system-x86_64 -cdrom ostwo.iso -m 512M -d int

# Boot with all debugging
qemu-system-x86_64 -cdrom ostwo.iso -m 512M -d cpu,int,guest_errors -D full_debug.log
```

### Examining the Kernel Binary

```bash
# Show all sections
readelf -S build/kernel/ostwo_kernel.elf

# Show symbols
nm build/kernel/ostwo_kernel.elf

# Disassemble specific function
objdump -d build/kernel/ostwo_kernel.elf -M intel | grep -A 50 "kernel_main"

# Show multiboot header
hexdump -C build/kernel/ostwo_kernel.elf | head -100

# Verify multiboot2 magic number
readelf -x .multiboot_header build/kernel/ostwo_kernel.elf
```

### Common Issues and Solutions

#### 1. Kernel doesn't boot (black screen)
**Symptoms**: QEMU shows black screen, no characters appear

**Possible causes**:
- GRUB can't find kernel
- Multiboot header is malformed
- Boot code has syntax error

**Debug steps**:
1. Check GRUB config: `cat iso/boot/grub/grub.cfg`
2. Verify kernel exists: `ls -la iso/boot/ostwo_kernel.elf`
3. Check multiboot header: `readelf -x .multiboot_header build/kernel/ostwo_kernel.elf`
4. View QEMU log: `qemu-system-x86_64 -cdrom ostwo.iso -d guest_errors`

#### 2. Boot hangs at specific character
**Symptoms**: Boot shows 'B' or 'BC' or 'BCP' but hangs

**Meaning**:
- Hangs at 'B': Issue with CPU ID or long mode detection
- Hangs at 'BC': Issue with page table setup
- Hangs at 'BCP': Issue with enabling paging or switching to long mode
- Hangs after 'L': Issue in kernel_main C++ code

**Debug steps**:
1. Check CPU support: QEMU should support long mode by default
2. Review `boot_header.asm` around the hang point
3. Use QEMU debugging: `-d cpu_reset,int`
4. Check for assembly syntax errors

#### 3. Kernel boots but crashes immediately
**Symptoms**: Boot sequence completes but triple fault or reset occurs

**Possible causes**:
- Stack overflow
- Invalid memory access
- Division by zero
- Unhandled exception

**Debug steps**:
1. Use GDB: Break at `kernel_main` and step through
2. Check for null pointer dereferences
3. Verify memory manager initialization
4. Review interrupt/exception handling

#### 4. Build errors with tests
**Symptoms**: Test compilation fails with STL errors

**Cause**: Tests inherit kernel's `-ffreestanding -nostdlib` flags

**Solution**: Unit tests are currently disabled. Integration tests (boot verification) work correctly.

## Known Issues

### Critical

**Multiboot Magic Mismatch** (`kernel/main.cpp:75`)
- Boot header uses Multiboot2 (magic: 0xE85250D6)
- kernel_main checks for Multiboot1 (magic: 0x2BADB002)
- **Impact**: Kernel will always fail multiboot verification
- **Fix**: Change check to `0x36D76289` (Multiboot2 magic value passed to kernel)

### TODO Items

The following components are partially implemented:

**kernel/memory.cpp**:
- Virtual memory `map()` - line 143
- Virtual memory `unmap()` - line 151
- `getPhysical()` - line 193

**kernel/process.cpp**:
- Context switching (register save/restore) - line 302
- `sys_fork()` - line 329
- `sys_exec()` - line 334

**kernel/interrupt.cpp**:
- IDT setup - lines 28-30, 60-73
- PIC initialization - lines 71-73
- IRQ masking/unmasking - lines 45-53

## Performance Profiling

### Measuring Boot Time

```bash
# Time the full boot sequence
time timeout 2 qemu-system-x86_64 -cdrom ostwo.iso -m 512M -display none
```

### Memory Usage

The kernel reports memory statistics at boot. To capture:
```bash
# Boot with serial output and capture logs
qemu-system-x86_64 -cdrom ostwo.iso -serial file:serial.log -m 512M
# Check serial.log for memory statistics
```

## Contributing Tests

When adding new tests:

1. For integration tests: Add shell scripts to `tests/` directory
2. Register in `tests/CMakeLists.txt`:
   ```cmake
   add_test(NAME MyTest COMMAND ${CMAKE_CURRENT_SOURCE_DIR}/my_test.sh)
   set_tests_properties(MyTest PROPERTIES TIMEOUT 30)
   ```
3. Make scripts executable: `chmod +x tests/my_test.sh`
4. Test with: `ctest -R MyTest -V`

## Continuous Integration

To set up CI testing:

```bash
# Full build and test pipeline
mkdir -p build
cd build
cmake ..
cmake --build .
ctest --output-on-failure

# Exit code 0 = success, non-zero = failure
echo $?
```

## References

- [Multiboot2 Specification](https://www.gnu.org/software/grub/manual/multiboot2/multiboot.html)
- [OSDev Wiki](https://wiki.osdev.org/)
- [QEMU Documentation](https://www.qemu.org/docs/master/)
- [GDB Debugging](https://sourceware.org/gdb/documentation/)
