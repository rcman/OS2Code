# OSTwo Quick Start Guide

## Problem: "Error loading uncompressed kernel without PVH ELF Note"

This error occurs with QEMU 7.0+ because direct ELF kernel loading requires a PVH ELF note. OSTwo uses Multiboot2, which requires a bootable ISO instead.

## Solution: Create a Bootable ISO

### Step 1: Install Required Tools

**Fedora (your current system):**
```bash
sudo dnf install grub2-tools-extra xorriso mtools
```

**Ubuntu/Debian:**
```bash
sudo apt install grub-pc-bin xorriso mtools
```

**Arch Linux:**
```bash
sudo pacman -S grub xorriso mtools
```

### Step 2: Build the Kernel (if not already built)

```bash
cd /home/franco/OSTwo
mkdir -p build && cd build
cmake ..
cmake --build .
cd ..
```

### Step 3: Create Bootable ISO

**Option A: Using the helper script (recommended)**
```bash
./create-bootable-iso.sh
```

**Option B: Manual creation**
```bash
# Create directory structure
mkdir -p iso/boot/grub
cp build/kernel/ostwo_kernel.elf iso/boot/

# Create GRUB config
cat > iso/boot/grub/grub.cfg << 'EOF'
set timeout=3
set default=0

menuentry "OSTwo Kernel v0.0.1" {
    multiboot2 /boot/ostwo_kernel.elf
    boot
}
EOF

# Create ISO (use grub2-mkrescue on Fedora, grub-mkrescue on Ubuntu)
grub2-mkrescue -o ostwo.iso iso/
```

### Step 4: Run in QEMU

```bash
qemu-system-x86_64 -cdrom ostwo.iso -m 512M -serial stdio
```

### Expected Output

```
OSTwo Kernel v0.0.1
===================

[1/6] Multiboot verification... OK
[2/6] Physical memory manager... OK
[3/6] Virtual memory manager... OK
[4/6] Kernel heap... OK
[5/6] Interrupt handling... OK
[6/6] Process manager... OK
[+] IPC manager... OK

Kernel initialization complete!

Total memory: (statistics)

Starting userspace servers...
Kernel idle. System ready.
```

## Alternative: Test Without ISO (For Development)

If you cannot install xorriso/GRUB tools, you can test individual components:

### Option 1: Unit Tests
```bash
cd build
ctest -V
```

### Option 2: Examine the Binary
```bash
# Check multiboot header is present
readelf -S build/kernel/ostwo_kernel.elf | grep multiboot

# Verify entry point
readelf -h build/kernel/ostwo_kernel.elf | grep Entry

# Disassemble first instructions
objdump -d build/kernel/ostwo_kernel.elf | head -50
```

### Option 3: Use Older QEMU (if available)
```bash
# QEMU < 7.0 supported direct ELF loading
qemu-system-x86_64 -kernel build/kernel/ostwo_kernel.elf -m 512M -serial stdio
```

## Debugging

### QEMU Won't Start
```bash
# Add debugging flags
qemu-system-x86_64 -cdrom ostwo.iso -m 512M -serial stdio -d int,cpu_reset -D qemu.log
```

### Kernel Triple Faults
```bash
# Use GDB
qemu-system-x86_64 -cdrom ostwo.iso -m 512M -s -S &
gdb build/kernel/ostwo_kernel.elf
(gdb) target remote :1234
(gdb) break kernel_main
(gdb) continue
```

### Check Multiboot Header
```bash
# Extract multiboot header
dd if=build/kernel/ostwo_kernel.elf of=/tmp/header.bin bs=1 count=100 skip=$((0x1000))
hexdump -C /tmp/header.bin | head -10
# Should see: d6 50 52 e8 (Multiboot2 magic)
```

## Next Steps

Once the kernel boots successfully:
1. Explore the source code in `kernel/`, `include/`, and `libraries/`
2. Read the architecture documentation: `docs/ARCHITECTURE.md`
3. Check the development guide: `CLAUDE.md`
4. Try modifying the kernel and rebuilding

## Troubleshooting

**Q: grub-mkrescue not found**
A: Install GRUB tools (see Step 1)

**Q: xorriso not found**
A: Install xorriso package (see Step 1)

**Q: Permission denied when running create-bootable-iso.sh**
A: `chmod +x create-bootable-iso.sh`

**Q: Kernel hangs at boot**
A: Check serial output with `-serial stdio` and logs with `-d int`

**Q: Want to test without QEMU**
A: You can examine the binary structure and run unit tests (see Alternative options above)

## Quick Reference

```bash
# Build
cmake --build build

# Create ISO
./create-bootable-iso.sh

# Run
qemu-system-x86_64 -cdrom ostwo.iso -m 512M -serial stdio

# Debug
qemu-system-x86_64 -cdrom ostwo.iso -m 512M -serial stdio -s -S
# In another terminal: gdb build/kernel/ostwo_kernel.elf
```

## Additional QEMU Options

```bash
# More memory
qemu-system-x86_64 -cdrom ostwo.iso -m 1G

# No graphics (faster)
qemu-system-x86_64 -cdrom ostwo.iso -m 512M -nographic

# Save screenshots
qemu-system-x86_64 -cdrom ostwo.iso -m 512M -vga std

# Multiple CPUs (when SMP is implemented)
qemu-system-x86_64 -cdrom ostwo.iso -m 512M -smp 4
```
