#include "test_framework.hpp"
#include "kernel/types.hpp"
#include "kernel/memory.hpp"

using namespace OSTwo::Testing;
using namespace OSTwo::Kernel;
using namespace OSTwo::Kernel::Memory;

// Mock memory region for testing
constexpr PhysAddr TEST_MEM_START = 0x100000;  // 1MB
constexpr PhysAddr TEST_MEM_SIZE  = 16 * 1024 * 1024;  // 16MB
constexpr PhysAddr TEST_MEM_END   = TEST_MEM_START + TEST_MEM_SIZE;

// Tests for Physical Memory Manager

TEST(PhysicalMemoryManager_Initialize) {
    auto& pmm = PhysicalMemoryManager::instance();
    pmm.initialize(TEST_MEM_START, TEST_MEM_END);

    size_t totalPages = pmm.getTotalPages();
    size_t freePages = pmm.getFreePages();

    // Should have allocated some pages for the bitmap itself
    ASSERT_TRUE(totalPages > 0);
    ASSERT_TRUE(freePages > 0);
    ASSERT_TRUE(freePages < totalPages);  // Bitmap uses some pages
}

TEST(PhysicalMemoryManager_AllocatePage) {
    auto& pmm = PhysicalMemoryManager::instance();
    pmm.initialize(TEST_MEM_START, TEST_MEM_END);

    size_t freeBefore = pmm.getFreePages();
    PhysAddr page = pmm.allocatePage();

    ASSERT_NE(0, page);
    ASSERT_TRUE(page >= TEST_MEM_START);
    ASSERT_TRUE(page < TEST_MEM_END);
    ASSERT_EQ(freeBefore - 1, pmm.getFreePages());
}

TEST(PhysicalMemoryManager_FreePage) {
    auto& pmm = PhysicalMemoryManager::instance();
    pmm.initialize(TEST_MEM_START, TEST_MEM_END);

    PhysAddr page = pmm.allocatePage();
    ASSERT_NE(0, page);

    size_t freeBefore = pmm.getFreePages();
    pmm.freePage(page);

    ASSERT_EQ(freeBefore + 1, pmm.getFreePages());
}

TEST(PhysicalMemoryManager_AllocatePages_Contiguous) {
    auto& pmm = PhysicalMemoryManager::instance();
    pmm.initialize(TEST_MEM_START, TEST_MEM_END);

    size_t count = 4;
    PhysAddr pages = pmm.allocatePages(count);

    ASSERT_NE(0, pages);

    // Verify pages are contiguous (aligned to PAGE_SIZE)
    for (size_t i = 0; i < count; i++) {
        PhysAddr expected = pages + (i * PAGE_SIZE);
        ASSERT_TRUE((expected % PAGE_SIZE) == 0);
    }
}

TEST(PhysicalMemoryManager_FreePages) {
    auto& pmm = PhysicalMemoryManager::instance();
    pmm.initialize(TEST_MEM_START, TEST_MEM_END);

    size_t count = 4;
    PhysAddr pages = pmm.allocatePages(count);
    ASSERT_NE(0, pages);

    size_t freeBefore = pmm.getFreePages();
    pmm.freePages(pages, count);

    ASSERT_EQ(freeBefore + count, pmm.getFreePages());
}

TEST(PhysicalMemoryManager_AllocateAll_OutOfMemory) {
    auto& pmm = PhysicalMemoryManager::instance();
    pmm.initialize(TEST_MEM_START, TEST_MEM_END);

    // Try to allocate until we run out
    size_t allocated = 0;
    std::vector<PhysAddr> pages;

    while (pmm.getFreePages() > 0 && allocated < 100) {  // Limit to prevent hanging
        PhysAddr page = pmm.allocatePage();
        if (page == 0) break;
        pages.push_back(page);
        allocated++;
    }

    // Should have allocated something
    ASSERT_TRUE(allocated > 0);

    // One more allocation should fail
    PhysAddr failedPage = pmm.allocatePage();

    // Free all pages
    for (PhysAddr p : pages) {
        pmm.freePage(p);
    }
}

// Tests for Kernel Heap

TEST(KernelHeap_Initialize) {
    auto& heap = KernelHeap::instance();
    VirtAddr heapStart = 0x200000;  // 2MB
    size_t heapSize = 4 * 1024 * 1024;  // 4MB

    heap.initialize(heapStart, heapSize);

    ASSERT_EQ(heapSize, heap.getTotalSize());
    ASSERT_TRUE(heap.getUsedSize() < heapSize);
}

TEST(KernelHeap_Allocate) {
    auto& heap = KernelHeap::instance();
    VirtAddr heapStart = 0x200000;
    size_t heapSize = 4 * 1024 * 1024;
    heap.initialize(heapStart, heapSize);

    size_t usedBefore = heap.getUsedSize();
    void* ptr = heap.allocate(128);

    ASSERT_NOT_NULL(ptr);
    ASSERT_TRUE(heap.getUsedSize() > usedBefore);
}

TEST(KernelHeap_Free) {
    auto& heap = KernelHeap::instance();
    VirtAddr heapStart = 0x200000;
    size_t heapSize = 4 * 1024 * 1024;
    heap.initialize(heapStart, heapSize);

    void* ptr = heap.allocate(128);
    ASSERT_NOT_NULL(ptr);

    size_t usedBefore = heap.getUsedSize();
    heap.free(ptr);

    ASSERT_TRUE(heap.getUsedSize() < usedBefore);
}

TEST(KernelHeap_Reallocate_Grow) {
    auto& heap = KernelHeap::instance();
    VirtAddr heapStart = 0x200000;
    size_t heapSize = 4 * 1024 * 1024;
    heap.initialize(heapStart, heapSize);

    void* ptr = heap.allocate(64);
    ASSERT_NOT_NULL(ptr);

    // Store some data
    uint8_t* data = static_cast<uint8_t*>(ptr);
    for (int i = 0; i < 64; i++) {
        data[i] = static_cast<uint8_t>(i);
    }

    void* newPtr = heap.reallocate(ptr, 256);
    ASSERT_NOT_NULL(newPtr);

    // Verify data was copied
    uint8_t* newData = static_cast<uint8_t*>(newPtr);
    for (int i = 0; i < 64; i++) {
        ASSERT_EQ(i, newData[i]);
    }

    heap.free(newPtr);
}

TEST(KernelHeap_MultipleAllocations) {
    auto& heap = KernelHeap::instance();
    VirtAddr heapStart = 0x200000;
    size_t heapSize = 4 * 1024 * 1024;
    heap.initialize(heapStart, heapSize);

    std::vector<void*> ptrs;

    // Allocate multiple blocks
    for (int i = 0; i < 10; i++) {
        void* ptr = heap.allocate(128 + i * 16);
        ASSERT_NOT_NULL(ptr);
        ptrs.push_back(ptr);
    }

    // Free them
    for (void* ptr : ptrs) {
        heap.free(ptr);
    }

    // Should be able to allocate again
    void* ptr = heap.allocate(1024);
    ASSERT_NOT_NULL(ptr);
    heap.free(ptr);
}

// Utility function tests

TEST(BytesToPages_Conversion) {
    ASSERT_EQ(1, bytesToPages(1));
    ASSERT_EQ(1, bytesToPages(PAGE_SIZE));
    ASSERT_EQ(2, bytesToPages(PAGE_SIZE + 1));
    ASSERT_EQ(4, bytesToPages(PAGE_SIZE * 4));
}

TEST(PageAlign_Alignment) {
    ASSERT_EQ(0, pageAlign(0));
    ASSERT_EQ(PAGE_SIZE, pageAlign(1));
    ASSERT_EQ(PAGE_SIZE, pageAlign(PAGE_SIZE));
    ASSERT_EQ(PAGE_SIZE * 2, pageAlign(PAGE_SIZE + 1));
}

TEST_MAIN()
