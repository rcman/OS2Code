#!/bin/bash
# OSTwo Kernel Boot Verification Test
# This test boots the kernel in QEMU and verifies expected output

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

cd "$PROJECT_DIR"

echo "======================================"
echo "OSTwo Kernel Boot Verification Test"
echo "======================================"
echo

# Rebuild kernel
echo "[1/4] Building kernel..."
cd build && cmake --build . --target kernel  2>&1 | grep -E "(Built|error)" || true
cd ..

# Create minimal GRUB config
echo "[2/4] Creating bootable ISO..."
mkdir -p iso/boot/grub
cp build/kernel/ostwo_kernel.elf iso/boot/

cat > iso/boot/grub/grub.cfg << 'EOF'
set timeout=0
set default=0

menuentry "OSTwo Test Boot" {
    multiboot2 /boot/ostwo_kernel.elf
    boot
}
EOF

# Create ISO
grub2-mkrescue -o ostwo_test.iso iso/ 2>&1 | grep -v "warning:" || true

# Boot and capture output
echo "[3/4] Booting kernel in QEMU..."
echo

# Run QEMU with serial output to file
timeout 3 qemu-system-x86_64 \
    -cdrom ostwo_test.iso \
    -m 512M \
    -display none \
    -serial file:boot_output.log \
    -d cpu_reset \
    -D cpu_reset.log \
    2>/dev/null || true

# Check output
echo "[4/4] Verifying boot output..."
echo

if [ ! -f boot_output.log ]; then
    echo "❌ FAIL: No boot output captured"
    exit 1
fi

# Check for expected initialization messages
# Note: The kernel writes to VGA buffer, not serial, so this test
# checks the boot process itself via cpu_reset.log

SUCCESS_COUNT=0
FAIL_COUNT=0

echo "Boot sequence check:"

# Check CPU reset log for successful boot indicators
if grep -q "CPU Reset" cpu_reset.log; then
    echo "✓ CPU initialization detected"
    ((SUCCESS_COUNT++))
else
    echo "❌ No CPU reset detected"
    ((FAIL_COUNT++))
fi

# The boot_header.asm writes characters 'B', 'C', 'P', 'E', 'L' to VGA
# We can't easily capture VGA output, but we can verify the kernel was loaded

if [ -f build/kernel/ostwo_kernel.elf ]; then
    # Check if kernel has the expected sections
    if readelf -S build/kernel/ostwo_kernel.elf | grep -q ".multiboot_header"; then
        echo "✓ Multiboot header section present"
        ((SUCCESS_COUNT++))
    else
        echo "❌ Multiboot header section missing"
        ((FAIL_COUNT++))
    fi

    # Check for kernel_main symbol
    if nm build/kernel/ostwo_kernel.elf | grep -q "kernel_main"; then
        echo "✓ kernel_main symbol found"
        ((SUCCESS_COUNT++))
    else
        echo "❌ kernel_main symbol missing"
        ((FAIL_COUNT++))
    fi
fi

# Check kernel binary size is reasonable
KERNEL_SIZE=$(stat -c%s build/kernel/ostwo_kernel.elf)
if [ "$KERNEL_SIZE" -gt 1000 ] && [ "$KERNEL_SIZE" -lt 10000000 ]; then
    echo "✓ Kernel size reasonable ($KERNEL_SIZE bytes)"
    ((SUCCESS_COUNT++))
else
    echo "❌ Kernel size suspicious ($KERNEL_SIZE bytes)"
    ((FAIL_COUNT++))
fi

echo
echo "======================================"
echo "Test Results:"
echo "  Passed: $SUCCESS_COUNT"
echo "  Failed: $FAIL_COUNT"
echo "======================================"

if [ $FAIL_COUNT -eq 0 ]; then
    echo "✓ Boot verification PASSED"
    exit 0
else
    echo "❌ Boot verification FAILED"
    exit 1
fi
