#ifndef OSTWO_TEST_FRAMEWORK_HPP
#define OSTWO_TEST_FRAMEWORK_HPP

#include <functional>
#include <vector>
#include <string>
#include <sstream>
#include <stdexcept>

namespace OSTwo {
namespace Testing {

// Exception thrown when assertion fails
class AssertionFailure : public std::runtime_error {
public:
    explicit AssertionFailure(const std::string& msg) : std::runtime_error(msg) {}
};

// Test function type
using TestFunc = std::function<void()>;

// Test registry
class TestRegistry {
public:
    static TestRegistry& instance();

    void registerTest(const char* name, TestFunc func);
    int runAll();

private:
    struct Test {
        const char* name;
        TestFunc func;
    };

    std::vector<Test> tests_;
};

// Test registration helper
class TestRegistrar {
public:
    TestRegistrar(const char* name, TestFunc func) {
        TestRegistry::instance().registerTest(name, func);
    }
};

// Assertions
#define ASSERT_TRUE(condition) \
    do { \
        if (!(condition)) { \
            std::ostringstream oss; \
            oss << __FILE__ << ":" << __LINE__ << ": Assertion failed: " #condition; \
            throw AssertionFailure(oss.str()); \
        } \
    } while (0)

#define ASSERT_FALSE(condition) ASSERT_TRUE(!(condition))

#define ASSERT_EQ(expected, actual) \
    do { \
        auto exp_val = (expected); \
        auto act_val = (actual); \
        if (exp_val != act_val) { \
            std::ostringstream oss; \
            oss << __FILE__ << ":" << __LINE__ << ": Expected " << exp_val \
                << " but got " << act_val; \
            throw AssertionFailure(oss.str()); \
        } \
    } while (0)

#define ASSERT_NE(not_expected, actual) \
    do { \
        auto ne_val = (not_expected); \
        auto act_val = (actual); \
        if (ne_val == act_val) { \
            std::ostringstream oss; \
            oss << __FILE__ << ":" << __LINE__ << ": Expected value not equal to " \
                << ne_val << " but got " << act_val; \
            throw AssertionFailure(oss.str()); \
        } \
    } while (0)

#define ASSERT_NULL(ptr) ASSERT_TRUE((ptr) == nullptr)
#define ASSERT_NOT_NULL(ptr) ASSERT_TRUE((ptr) != nullptr)

// Test declaration macro
#define TEST(test_name) \
    static void test_##test_name(); \
    static TestRegistrar registrar_##test_name(#test_name, test_##test_name); \
    static void test_##test_name()

// Main function for test executables
#define TEST_MAIN() \
    int main() { \
        return OSTwo::Testing::TestRegistry::instance().runAll(); \
    }

} // namespace Testing
} // namespace OSTwo

#endif // OSTWO_TEST_FRAMEWORK_HPP
