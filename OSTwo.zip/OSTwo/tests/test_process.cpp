#include "test_framework.hpp"
#include "kernel/types.hpp"
#include "kernel/process.hpp"
#include "kernel/memory.hpp"

using namespace OSTwo::Testing;
using namespace OSTwo::Kernel;
using namespace OSTwo::Kernel::Process;

// Setup helper
void setupMemoryForProcessTests() {
    static bool initialized = false;
    if (!initialized) {
        PhysAddr memStart = 0x100000;  // 1MB
        PhysAddr memEnd = 0x100000 + (32 * 1024 * 1024);  // 33MB
        Memory::PhysicalMemoryManager::instance().initialize(memStart, memEnd);

        VirtAddr heapStart = 0x200000;
        size_t heapSize = 8 * 1024 * 1024;  // 8MB
        Memory::KernelHeap::instance().initialize(heapStart, heapSize);

        initialized = true;
    }
}

// ProcessManager Tests

TEST(ProcessManager_Initialize) {
    setupMemoryForProcessTests();

    auto& pm = ProcessManager::instance();
    pm.initialize();

    ASSERT_EQ(1, pm.getProcessCount());  // Kernel idle process
}

TEST(ProcessManager_CreateProcess) {
    setupMemoryForProcessTests();

    auto& pm = ProcessManager::instance();
    pm.initialize();

    ProcessId pid = pm.createProcess("test_process", 0, 8192);

    ASSERT_NE(0, pid);
    ASSERT_TRUE(pm.getProcessCount() > 1);
}

TEST(ProcessManager_GetProcess) {
    setupMemoryForProcessTests();

    auto& pm = ProcessManager::instance();
    pm.initialize();

    ProcessId pid = pm.createProcess("test_process", 0, 8192);
    ASSERT_NE(0, pid);

    ProcessControlBlock* pcb = pm.getProcess(pid);
    ASSERT_NOT_NULL(pcb);
    ASSERT_EQ(pid, pcb->getId());
}

TEST(ProcessManager_CreateThread) {
    setupMemoryForProcessTests();

    auto& pm = ProcessManager::instance();
    pm.initialize();

    ProcessId pid = pm.createProcess("test_process", 0, 8192);
    ASSERT_NE(0, pid);

    // Create additional thread (process already has initial thread)
    ThreadId tid = pm.createThread(pid, 0x400000, 8192, Priority::Normal);

    ASSERT_NE(0, tid);
}

TEST(ProcessManager_GetThread) {
    setupMemoryForProcessTests();

    auto& pm = ProcessManager::instance();
    pm.initialize();

    ProcessId pid = pm.createProcess("test_process", 0x400000, 8192);
    ASSERT_NE(0, pid);

    ProcessControlBlock* pcb = pm.getProcess(pid);
    ASSERT_NOT_NULL(pcb);

    // Get the initial thread
    ASSERT_TRUE(pcb->getThreadCount() > 0);
}

TEST(ProcessManager_TerminateThread) {
    setupMemoryForProcessTests();

    auto& pm = ProcessManager::instance();
    pm.initialize();

    ProcessId pid = pm.createProcess("test_process", 0x400000, 8192);
    ASSERT_NE(0, pid);

    ThreadId tid = pm.createThread(pid, 0x400000, 8192, Priority::Normal);
    ASSERT_NE(0, tid);

    Thread* thread = pm.getThread(tid);
    ASSERT_NOT_NULL(thread);

    size_t threadCountBefore = pm.getTotalThreadCount();
    Status status = pm.terminateThread(tid);

    ASSERT_EQ(Status::Success, status);
    ASSERT_EQ(threadCountBefore - 1, pm.getTotalThreadCount());

    // Thread should be gone
    thread = pm.getThread(tid);
    ASSERT_NULL(thread);
}

TEST(ProcessManager_TerminateProcess) {
    setupMemoryForProcessTests();

    auto& pm = ProcessManager::instance();
    pm.initialize();

    ProcessId pid = pm.createProcess("test_process", 0x400000, 8192);
    ASSERT_NE(0, pid);

    size_t processCountBefore = pm.getProcessCount();
    Status status = pm.terminateProcess(pid, 0);

    ASSERT_EQ(Status::Success, status);
    ASSERT_EQ(processCountBefore - 1, pm.getProcessCount());

    // Process should be gone
    ProcessControlBlock* pcb = pm.getProcess(pid);
    ASSERT_NULL(pcb);
}

TEST(ProcessManager_MultipleProcesses) {
    setupMemoryForProcessTests();

    auto& pm = ProcessManager::instance();
    pm.initialize();

    std::vector<ProcessId> pids;

    for (int i = 0; i < 5; i++) {
        ProcessId pid = pm.createProcess("test_process", 0, 8192);
        ASSERT_NE(0, pid);
        pids.push_back(pid);
    }

    // Verify all processes exist
    for (ProcessId pid : pids) {
        ProcessControlBlock* pcb = pm.getProcess(pid);
        ASSERT_NOT_NULL(pcb);
    }

    // Terminate all
    for (ProcessId pid : pids) {
        pm.terminateProcess(pid, 0);
    }
}

TEST(ProcessManager_ThreadPriorities) {
    setupMemoryForProcessTests();

    auto& pm = ProcessManager::instance();
    pm.initialize();

    ProcessId pid = pm.createProcess("test_process", 0, 8192);
    ASSERT_NE(0, pid);

    // Create threads with different priorities
    ThreadId tid1 = pm.createThread(pid, 0x400000, 8192, Priority::Idle);
    ThreadId tid2 = pm.createThread(pid, 0x400000, 8192, Priority::Low);
    ThreadId tid3 = pm.createThread(pid, 0x400000, 8192, Priority::Normal);
    ThreadId tid4 = pm.createThread(pid, 0x400000, 8192, Priority::High);
    ThreadId tid5 = pm.createThread(pid, 0x400000, 8192, Priority::Critical);

    ASSERT_NE(0, tid1);
    ASSERT_NE(0, tid2);
    ASSERT_NE(0, tid3);
    ASSERT_NE(0, tid4);
    ASSERT_NE(0, tid5);

    // Verify priorities
    Thread* t1 = pm.getThread(tid1);
    Thread* t2 = pm.getThread(tid2);
    Thread* t3 = pm.getThread(tid3);
    Thread* t4 = pm.getThread(tid4);
    Thread* t5 = pm.getThread(tid5);

    ASSERT_EQ(Priority::Idle, t1->getPriority());
    ASSERT_EQ(Priority::Low, t2->getPriority());
    ASSERT_EQ(Priority::Normal, t3->getPriority());
    ASSERT_EQ(Priority::High, t4->getPriority());
    ASSERT_EQ(Priority::Critical, t5->getPriority());

    pm.terminateProcess(pid, 0);
}

TEST(ProcessControlBlock_Properties) {
    setupMemoryForProcessTests();

    auto& pm = ProcessManager::instance();
    pm.initialize();

    ProcessId pid = pm.createProcess("my_process", 0, 8192);
    ASSERT_NE(0, pid);

    ProcessControlBlock* pcb = pm.getProcess(pid);
    ASSERT_NOT_NULL(pcb);

    ASSERT_EQ(pid, pcb->getId());
    // Name should match (check first few characters)
    ASSERT_EQ('m', pcb->getName()[0]);
    ASSERT_EQ('y', pcb->getName()[1]);

    pm.terminateProcess(pid, 0);
}

// System call tests

TEST(SystemCall_GetPid) {
    setupMemoryForProcessTests();

    auto& pm = ProcessManager::instance();
    pm.initialize();

    // Before creating a process, getpid should return 0
    ProcessId pid = sys_getpid();
    // Note: This will return 0 because there's no current thread set
    // In a real system, this would be set by the scheduler
}

TEST(SystemCall_GetTid) {
    setupMemoryForProcessTests();

    auto& pm = ProcessManager::instance();
    pm.initialize();

    ThreadId tid = sys_gettid();
    // Note: This will return 0 because there's no current thread set
}

TEST_MAIN()
