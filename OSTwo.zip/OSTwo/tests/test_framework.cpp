#include "test_framework.hpp"
#include <iostream>

namespace OSTwo {
namespace Testing {

TestRegistry& TestRegistry::instance() {
    static TestRegistry registry;
    return registry;
}

void TestRegistry::registerTest(const char* name, TestFunc func) {
    Test test;
    test.name = name;
    test.func = func;
    tests_.push_back(test);
}

int TestRegistry::runAll() {
    int passed = 0;
    int failed = 0;

    std::cout << "\n========================================\n";
    std::cout << "Running " << tests_.size() << " tests\n";
    std::cout << "========================================\n\n";

    for (const auto& test : tests_) {
        std::cout << "[ RUN   ] " << test.name << std::endl;

        try {
            test.func();
            std::cout << "[  OK   ] " << test.name << std::endl;
            passed++;
        } catch (const AssertionFailure& e) {
            std::cout << "[ FAIL  ] " << test.name << std::endl;
            std::cout << "          " << e.what() << std::endl;
            failed++;
        } catch (const std::exception& e) {
            std::cout << "[ ERROR ] " << test.name << std::endl;
            std::cout << "          Unexpected exception: " << e.what() << std::endl;
            failed++;
        }
    }

    std::cout << "\n========================================\n";
    std::cout << "Test Results:\n";
    std::cout << "  Passed: " << passed << "\n";
    std::cout << "  Failed: " << failed << "\n";
    std::cout << "========================================\n";

    return failed == 0 ? 0 : 1;
}

} // namespace Testing
} // namespace OSTwo
