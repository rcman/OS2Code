#include "test_framework.hpp"
#include "kernel/types.hpp"
#include "kernel/ipc.hpp"
#include "kernel/process.hpp"
#include "kernel/memory.hpp"
#include <cstring>

using namespace OSTwo::Testing;
using namespace OSTwo::Kernel;
using namespace OSTwo::Kernel::IPC;

// Setup helper
void setupMemoryForIPCTests() {
    static bool initialized = false;
    if (!initialized) {
        PhysAddr memStart = 0x100000;  // 1MB
        PhysAddr memEnd = 0x100000 + (32 * 1024 * 1024);  // 33MB
        Memory::PhysicalMemoryManager::instance().initialize(memStart, memEnd);

        VirtAddr heapStart = 0x200000;
        size_t heapSize = 8 * 1024 * 1024;  // 8MB
        Memory::KernelHeap::instance().initialize(heapStart, heapSize);

        initialized = true;
    }
}

// IPCManager Tests

TEST(IPCManager_Initialize) {
    setupMemoryForIPCTests();

    auto& ipc = IPCManager::instance();
    ipc.initialize();

    ASSERT_EQ(0, ipc.getEndpointCount());
}

TEST(IPCManager_CreateEndpoint_Client) {
    setupMemoryForIPCTests();

    auto& ipc = IPCManager::instance();
    ipc.initialize();

    EndpointId endpoint = ipc.createEndpoint(EndpointType::Client);

    ASSERT_NE(0, endpoint);
    ASSERT_EQ(1, ipc.getEndpointCount());
}

TEST(IPCManager_CreateEndpoint_Server) {
    setupMemoryForIPCTests();

    auto& ipc = IPCManager::instance();
    ipc.initialize();

    EndpointId endpoint = ipc.createEndpoint(EndpointType::Server);

    ASSERT_NE(0, endpoint);
    ASSERT_EQ(1, ipc.getEndpointCount());
}

TEST(IPCManager_DestroyEndpoint) {
    setupMemoryForIPCTests();

    auto& ipc = IPCManager::instance();
    ipc.initialize();

    EndpointId endpoint = ipc.createEndpoint(EndpointType::Client);
    ASSERT_NE(0, endpoint);

    size_t countBefore = ipc.getEndpointCount();
    Status status = ipc.destroyEndpoint(endpoint);

    ASSERT_EQ(Status::Success, status);
    ASSERT_EQ(countBefore - 1, ipc.getEndpointCount());
}

TEST(IPCManager_ConnectEndpoints) {
    setupMemoryForIPCTests();

    auto& ipc = IPCManager::instance();
    ipc.initialize();

    EndpointId client = ipc.createEndpoint(EndpointType::Client);
    EndpointId server = ipc.createEndpoint(EndpointType::Server);

    ASSERT_NE(0, client);
    ASSERT_NE(0, server);

    Status status = ipc.connectEndpoint(client, server);
    ASSERT_EQ(Status::Success, status);
}

TEST(IPCManager_ConnectEndpoints_InvalidType) {
    setupMemoryForIPCTests();

    auto& ipc = IPCManager::instance();
    ipc.initialize();

    // Try to connect two clients (should fail)
    EndpointId client1 = ipc.createEndpoint(EndpointType::Client);
    EndpointId client2 = ipc.createEndpoint(EndpointType::Client);

    Status status = ipc.connectEndpoint(client1, client2);
    ASSERT_EQ(Status::InvalidParameter, status);
}

TEST(IPCManager_SendReceive_Basic) {
    setupMemoryForIPCTests();

    auto& ipc = IPCManager::instance();
    ipc.initialize();

    EndpointId client = ipc.createEndpoint(EndpointType::Client);
    EndpointId server = ipc.createEndpoint(EndpointType::Server);

    ipc.connectEndpoint(client, server);

    // Send message
    const char* message = "Hello, Server!";
    Status sendStatus = ipc.send(client, message, strlen(message) + 1);
    ASSERT_EQ(Status::Success, sendStatus);

    // Receive message
    char buffer[128];
    size_t receivedSize = 0;
    Status recvStatus = ipc.receive(server, buffer, sizeof(buffer), &receivedSize);

    ASSERT_EQ(Status::Success, recvStatus);
    ASSERT_EQ(strlen(message) + 1, receivedSize);
    ASSERT_EQ(0, strcmp(message, buffer));
}

TEST(IPCManager_SendReceive_MultipleMessages) {
    setupMemoryForIPCTests();

    auto& ipc = IPCManager::instance();
    ipc.initialize();

    EndpointId client = ipc.createEndpoint(EndpointType::Client);
    EndpointId server = ipc.createEndpoint(EndpointType::Server);

    ipc.connectEndpoint(client, server);

    // Send multiple messages
    for (int i = 0; i < 5; i++) {
        char msg[32];
        snprintf(msg, sizeof(msg), "Message %d", i);
        Status status = ipc.send(client, msg, strlen(msg) + 1);
        ASSERT_EQ(Status::Success, status);
    }

    // Receive and verify
    for (int i = 0; i < 5; i++) {
        char buffer[128];
        size_t receivedSize = 0;
        Status status = ipc.receive(server, buffer, sizeof(buffer), &receivedSize);

        ASSERT_EQ(Status::Success, status);

        char expected[32];
        snprintf(expected, sizeof(expected), "Message %d", i);
        ASSERT_EQ(0, strcmp(expected, buffer));
    }
}

TEST(IPCManager_SendReceive_EmptyQueue) {
    setupMemoryForIPCTests();

    auto& ipc = IPCManager::instance();
    ipc.initialize();

    EndpointId endpoint = ipc.createEndpoint(EndpointType::Server);

    // Try to receive with empty queue
    char buffer[128];
    size_t receivedSize = 0;
    Status status = ipc.receive(endpoint, buffer, sizeof(buffer), &receivedSize);

    ASSERT_EQ(Status::Error, status);  // No messages available
}

TEST(IPCManager_Send_MessageTooLarge) {
    setupMemoryForIPCTests();

    auto& ipc = IPCManager::instance();
    ipc.initialize();

    EndpointId client = ipc.createEndpoint(EndpointType::Client);
    EndpointId server = ipc.createEndpoint(EndpointType::Server);

    ipc.connectEndpoint(client, server);

    // Try to send message larger than MAX_MESSAGE_SIZE
    char largeBuffer[MAX_MESSAGE_SIZE + 100];
    Status status = ipc.send(client, largeBuffer, sizeof(largeBuffer));

    ASSERT_EQ(Status::InvalidParameter, status);
}

TEST(IPCManager_CreateSharedMemory) {
    setupMemoryForIPCTests();

    auto& ipc = IPCManager::instance();
    ipc.initialize();

    size_t size = 4096;  // 1 page
    VirtAddr addr = ipc.createSharedMemory(size);

    ASSERT_NE(0, addr);
    ASSERT_EQ(1, ipc.getSharedRegionCount());
}

TEST(IPCManager_DestroySharedMemory) {
    setupMemoryForIPCTests();

    auto& ipc = IPCManager::instance();
    ipc.initialize();

    size_t size = 4096;
    VirtAddr addr = ipc.createSharedMemory(size);
    ASSERT_NE(0, addr);

    size_t countBefore = ipc.getSharedRegionCount();
    Status status = ipc.destroySharedMemory(addr);

    ASSERT_EQ(Status::Success, status);
    ASSERT_EQ(countBefore - 1, ipc.getSharedRegionCount());
}

TEST(IPCManager_UnmapSharedMemory_RefCounting) {
    setupMemoryForIPCTests();

    auto& ipc = IPCManager::instance();
    ipc.initialize();

    size_t size = 4096;
    VirtAddr addr = ipc.createSharedMemory(size);
    ASSERT_NE(0, addr);

    // Unmap (should decrease ref count)
    Status status = ipc.unmapSharedMemory(addr);
    ASSERT_EQ(Status::Success, status);

    // Region should be destroyed (ref count reached 0)
    ASSERT_EQ(0, ipc.getSharedRegionCount());
}

TEST(IPCManager_MultipleEndpoints) {
    setupMemoryForIPCTests();

    auto& ipc = IPCManager::instance();
    ipc.initialize();

    std::vector<EndpointId> endpoints;

    // Create multiple endpoints
    for (int i = 0; i < 10; i++) {
        EndpointType type = (i % 2 == 0) ? EndpointType::Client : EndpointType::Server;
        EndpointId ep = ipc.createEndpoint(type);
        ASSERT_NE(0, ep);
        endpoints.push_back(ep);
    }

    ASSERT_EQ(10, ipc.getEndpointCount());

    // Destroy all
    for (EndpointId ep : endpoints) {
        ipc.destroyEndpoint(ep);
    }

    ASSERT_EQ(0, ipc.getEndpointCount());
}

// System call tests

TEST(SystemCall_EndpointCreate) {
    setupMemoryForIPCTests();

    auto& ipc = IPCManager::instance();
    ipc.initialize();

    EndpointId ep = sys_endpoint_create(EndpointType::Server);
    ASSERT_NE(0, ep);
}

TEST(SystemCall_EndpointDestroy) {
    setupMemoryForIPCTests();

    auto& ipc = IPCManager::instance();
    ipc.initialize();

    EndpointId ep = sys_endpoint_create(EndpointType::Server);
    ASSERT_NE(0, ep);

    Status status = sys_endpoint_destroy(ep);
    ASSERT_EQ(Status::Success, status);
}

TEST(SystemCall_EndpointConnect) {
    setupMemoryForIPCTests();

    auto& ipc = IPCManager::instance();
    ipc.initialize();

    EndpointId client = sys_endpoint_create(EndpointType::Client);
    EndpointId server = sys_endpoint_create(EndpointType::Server);

    Status status = sys_endpoint_connect(client, server);
    ASSERT_EQ(Status::Success, status);
}

TEST(SystemCall_SendReceive) {
    setupMemoryForIPCTests();

    auto& ipc = IPCManager::instance();
    ipc.initialize();

    EndpointId client = sys_endpoint_create(EndpointType::Client);
    EndpointId server = sys_endpoint_create(EndpointType::Server);
    sys_endpoint_connect(client, server);

    const char* message = "Test message";
    Status sendStatus = sys_send(client, message, strlen(message) + 1);
    ASSERT_EQ(Status::Success, sendStatus);

    char buffer[128];
    size_t receivedSize = 0;
    Status recvStatus = sys_receive(server, buffer, sizeof(buffer), &receivedSize);

    ASSERT_EQ(Status::Success, recvStatus);
    ASSERT_EQ(0, strcmp(message, buffer));
}

TEST_MAIN()
