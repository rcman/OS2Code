#!/bin/bash
echo "Booting OSTwo kernel..."
echo "Watch for debug markers on screen:"
echo "  32 = Started in 32-bit mode"
echo "  PG PA LM EN GD = Mode transition steps"
echo "  JM = About to jump to 64-bit code"
echo "  64 = Successfully in 64-bit mode!"
echo ""
echo "Press Ctrl-C or close window to quit"
echo ""
qemu-system-x86_64 \
    -cdrom ostwo_test.iso \
    -m 512M \
    -name "OSTwo v0.0.1"
