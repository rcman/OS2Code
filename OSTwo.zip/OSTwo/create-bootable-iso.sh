#!/bin/bash
# OSTwo - Create Bootable ISO Script
# This script creates a bootable ISO image for testing OSTwo in QEMU or on real hardware

set -e

echo "=== OSTwo Bootable ISO Creator ==="
echo

# Check for required tools
echo "[1/5] Checking dependencies..."

if ! command -v grub-mkrescue &> /dev/null && ! command -v grub2-mkrescue &> /dev/null; then
    echo "ERROR: grub-mkrescue or grub2-mkrescue not found"
    echo "Install with:"
    echo "  Ubuntu/Debian: sudo apt install grub-pc-bin xorriso"
    echo "  Fedora: sudo dnf install grub2-tools-extra xorriso"
    echo "  Arch: sudo pacman -S grub xorriso"
    exit 1
fi

GRUB_MKRESCUE=$(command -v grub2-mkrescue || command -v grub-mkrescue)

if ! command -v xorriso &> /dev/null; then
    echo "ERROR: xorriso not found (required by grub-mkrescue)"
    echo "Install with:"
    echo "  Ubuntu/Debian: sudo apt install xorriso"
    echo "  Fedora: sudo dnf install xorriso"
    echo "  Arch: sudo pacman -S xorriso"
    exit 1
fi

echo "✓ All dependencies found"
echo

# Check if kernel exists
echo "[2/5] Checking for kernel binary..."
if [ ! -f "build/kernel/ostwo_kernel.elf" ]; then
    echo "ERROR: Kernel not found at build/kernel/ostwo_kernel.elf"
    echo "Build the kernel first with:"
    echo "  mkdir build && cd build"
    echo "  cmake .. && cmake --build ."
    exit 1
fi
echo "✓ Kernel found"
echo

# Create ISO directory structure
echo "[3/5] Creating ISO directory structure..."
rm -rf iso
mkdir -p iso/boot/grub
cp build/kernel/ostwo_kernel.elf iso/boot/
echo "✓ Directory structure created"
echo

# Create GRUB configuration
echo "[4/5] Creating GRUB configuration..."
cat > iso/boot/grub/grub.cfg << 'EOF'
set timeout=3
set default=0

menuentry "OSTwo Kernel v0.0.1" {
    multiboot2 /boot/ostwo_kernel.elf
    boot
}

menuentry "OSTwo Kernel v0.0.1 (verbose)" {
    multiboot2 /boot/ostwo_kernel.elf --verbose
    boot
}

menuentry "OSTwo Kernel v0.0.1 (debug)" {
    multiboot2 /boot/ostwo_kernel.elf --debug
    boot
}
EOF
echo "✓ GRUB config created"
echo

# Create ISO
echo "[5/5] Creating bootable ISO..."
$GRUB_MKRESCUE -o ostwo.iso iso/
echo "✓ ISO created: ostwo.iso"
echo

# Show file info
ISO_SIZE=$(du -h ostwo.iso | cut -f1)
echo "=== Build Complete ==="
echo "ISO file: ostwo.iso ($ISO_SIZE)"
echo
echo "To test in QEMU:"
echo "  qemu-system-x86_64 -cdrom ostwo.iso -m 512M -serial stdio"
echo
echo "To boot on real hardware (DANGEROUS!):"
echo "  sudo dd if=ostwo.iso of=/dev/sdX bs=4M status=progress"
echo "  (Replace /dev/sdX with your USB device)"
echo
