# OSTwo - Modern C++ OS/2 Implementation

A modern, microkernel-based reimplementation of OS/2 written in C++17, inspired by the OSFree project.

[![License](https://img.shields.io/badge/license-TBD-blue.svg)](LICENSE)
[![Build Status](https://img.shields.io/badge/build-passing-brightgreen.svg)]()
[![Version](https://img.shields.io/badge/version-0.0.1--alpha-orange.svg)]()

## Table of Contents

- [Overview](#overview)
- [Features](#features)
- [Architecture](#architecture)
- [System Requirements](#system-requirements)
- [Installation](#installation)
- [Building](#building)
- [Running OSTwo](#running-ostwo)
- [Development](#development)
- [Troubleshooting](#troubleshooting)
- [Documentation](#documentation)
- [Contributing](#contributing)
- [License](#license)

## Overview

OSTwo is an open-source operating system project that creates a modern implementation of OS/2 using C++17 and contemporary OS development practices. Unlike the original OS/2 or the OSFree project, OSTwo:

- ✨ **Pure C++17** - Modern, type-safe implementation
- 🚫 **No Windows Support** - Focused on OS/2 and DOS compatibility
- 🔬 **Microkernel Design** - Minimal kernel, functionality in userspace servers
- 🏗️ **Modern Tooling** - CMake build system, cross-platform development
- 📚 **Well Documented** - Comprehensive architecture and API documentation

## Features

### Current (v0.0.1 Alpha)

✅ **Kernel Subsystems**
- Physical memory manager with bitmap allocator
- Virtual memory manager with paging support
- Kernel heap allocator
- Process and thread management
- Priority-based preemptive scheduler (5 priority levels)
- IPC (Inter-Process Communication) with message passing
- Interrupt handling framework
- VGA text mode console

✅ **OS/2 API Library**
- Thread management (DosCreateThread, etc.)
- Process management (DosExecPgm, etc.)
- Memory allocation (DosAllocMem, DosFreeMem)
- Shared memory support
- Semaphore interfaces (mutexes, events)
- File I/O interfaces

✅ **Build System**
- CMake-based cross-platform builds
- Component-based compilation
- Multiboot bootloader stub

### Planned Features

🔲 Complete interrupt handling (IDT, PIC, exceptions)
🔲 LX executable loader
🔲 Filesystem support (FAT32, JFS)
🔲 Userspace servers (exec, OS/2, DOS)
🔲 Device drivers framework
🔲 Network stack
🔲 SMP support
🔲 Presentation Manager
🔲 Workplace Shell

## Architecture

OSTwo uses a **microkernel architecture** where the kernel provides only essential services:

```
┌─────────────────────────────────────┐
│      User Applications (LX)         │
└─────────────┬───────────────────────┘
              │ OS/2 API (DosXXX)
┌─────────────┴───────────────────────┐
│       OS/2 API Library              │
└─────────────┬───────────────────────┘
              │ IPC Messages
┌─────────────┴───────────────────────┐
│    Userspace Servers                │
│  [Exec] [OS/2] [DOS] [Filesystem]   │
└─────────────┬───────────────────────┘
              │ System Calls
┌─────────────┴───────────────────────┐
│         OSTwo Kernel                │
│  [Memory] [Process] [IPC] [IRQ]     │
└─────────────┬───────────────────────┘
              │
          Hardware
```

See [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) for detailed architectural documentation.

## System Requirements

### Build System Requirements

**Operating System:**
- Linux (Ubuntu 20.04+, Fedora 33+, Arch Linux)
- macOS 10.15+ (for cross-compilation)
- Windows 10/11 with WSL2

**Required Tools:**
- **CMake** 3.20 or later
- **GCC** 9.0+ or **Clang** 10.0+ with C++17 support
- **Make** or **Ninja** build system
- **Git** for source control

**Optional Tools:**
- **NASM** 2.14+ (for bootloader assembly)
- **QEMU** 4.0+ (for testing/running the OS)
- **GDB** (for kernel debugging)
- **GRUB** tools (for creating bootable images)

### Runtime Requirements (Target)

- x86-64 (AMD64) processor
- 64 MB RAM minimum (512 MB recommended)
- VGA-compatible display
- PS/2 or USB keyboard

## Installation

### Ubuntu/Debian

```bash
# Update package list
sudo apt update

# Install required packages
sudo apt install -y \
    build-essential \
    cmake \
    git \
    nasm \
    qemu-system-x86 \
    grub-pc-bin \
    xorriso \
    mtools

# Verify installation
gcc --version      # Should be 9.0+
cmake --version    # Should be 3.20+
nasm --version     # Should be 2.14+
```

### Fedora

```bash
# Install required packages
sudo dnf install -y \
    gcc \
    gcc-c++ \
    cmake \
    git \
    nasm \
    qemu-system-x86 \
    grub2-tools-extra \
    xorriso \
    mtools

# Verify installation
gcc --version
cmake --version
nasm --version
```

### Arch Linux

```bash
# Install required packages
sudo pacman -S --needed \
    base-devel \
    cmake \
    git \
    nasm \
    qemu \
    grub \
    xorriso \
    mtools

# Verify installation
gcc --version
cmake --version
nasm --version
```

### macOS

```bash
# Install Homebrew if not already installed
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Install required packages
brew install cmake nasm qemu

# Install cross-compilation toolchain
brew tap messense/homebrew-macos-cross-toolchains
brew install x86_64-unknown-linux-gnu

# Verify installation
cmake --version
nasm --version
qemu-system-x86_64 --version
```

### Windows (WSL2)

```powershell
# Install WSL2 with Ubuntu
wsl --install -d Ubuntu-22.04

# Inside WSL2, follow Ubuntu installation steps above
```

## Building

### Quick Start

```bash
# Clone the repository
git clone https://github.com/your-username/ostwo.git
cd OSTwo

# Create build directory
mkdir build && cd build

# Configure the build
cmake ..

# Build everything
cmake --build .

# Verify build
ls -lh kernel/ostwo_kernel.elf libraries/libos2api.a
```

### Build Output

After a successful build, you'll have:

```
build/
├── kernel/
│   └── ostwo_kernel.elf     # Kernel binary (37 KB)
└── libraries/
    └── libos2api.a          # OS/2 API library (13 KB)
```

### Build Options

Configure with `-D<OPTION>=ON/OFF`:

```bash
cmake .. -DBUILD_KERNEL=ON \
         -DBUILD_SERVERS=ON \
         -DBUILD_LOADERS=ON \
         -DBUILD_FILESYSTEMS=ON \
         -DBUILD_TESTS=ON
```

**Available Options:**
- `BUILD_KERNEL` - Build the kernel (default: ON)
- `BUILD_SERVERS` - Build userspace servers (default: ON)
- `BUILD_LOADERS` - Build executable loaders (default: ON)
- `BUILD_FILESYSTEMS` - Build filesystem drivers (default: ON)
- `BUILD_TESTS` - Build test suite (default: ON)

### Build Specific Targets

```bash
# Build only the kernel
cmake --build . --target kernel

# Build only the OS/2 API library
cmake --build . --target os2api

# Clean build
cmake --build . --target clean

# Verbose build
cmake --build . --verbose
```

### Cross-Compilation

OSTwo kernel requires bare-metal compilation flags. The CMake configuration handles this automatically:

```bash
# Kernel is compiled with:
# -ffreestanding -nostdlib -fno-exceptions -fno-rtti
# -mno-red-zone -mcmodel=kernel
```

## Running OSTwo

### Using QEMU (Recommended)

**Method 1: Direct Kernel Boot (Requires Multiboot bootloader)**

```bash
cd build

# Run with QEMU (requires multiboot-compatible bootloader)
qemu-system-x86_64 \
    -kernel kernel/ostwo_kernel.elf \
    -m 512M \
    -serial stdio
```

**Method 2: Create Bootable ISO (Requires GRUB)**

```bash
# Create ISO directory structure
mkdir -p iso/boot/grub

# Copy kernel
cp build/kernel/ostwo_kernel.elf iso/boot/

# Create GRUB config
cat > iso/boot/grub/grub.cfg << 'EOF'
set timeout=0
set default=0

menuentry "OSTwo" {
    multiboot2 /boot/ostwo_kernel.elf
    boot
}
EOF

# Create ISO
grub-mkrescue -o ostwo.iso iso/

# Boot with QEMU
qemu-system-x86_64 \
    -cdrom ostwo.iso \
    -m 512M \
    -serial stdio \
    -vga std
```

**QEMU Options Explained:**
- `-m 512M` - Allocate 512 MB RAM
- `-serial stdio` - Redirect serial output to terminal
- `-vga std` - Use standard VGA graphics
- `-s -S` - Enable GDB debugging (kernel halts at start)
- `-d int` - Debug interrupts
- `-no-reboot` - Exit instead of rebooting on crash

### Using Real Hardware (Advanced)

⚠️ **Warning:** Only for experienced users. Incorrect installation can damage your system.

1. Create bootable USB drive:
```bash
# Write ISO to USB (replace /dev/sdX with your USB device)
sudo dd if=ostwo.iso of=/dev/sdX bs=4M status=progress
sudo sync
```

2. Boot from USB in BIOS/Legacy mode (UEFI not yet supported)

### Expected Output

On successful boot, you should see:

```
OSTwo Kernel v0.0.1
===================

[1/6] Multiboot verification... OK
[2/6] Physical memory manager... OK
[3/6] Virtual memory manager... OK
[4/6] Kernel heap... OK
[5/6] Interrupt handling... OK
[6/6] Process manager... OK
[+] IPC manager... OK

Kernel initialization complete!

Total memory: (statistics)

Starting userspace servers...
Kernel idle. System ready.
```

## Development

### Project Structure

```
OSTwo/
├── boot/              # Bootloader (multiboot stub)
├── kernel/            # Core microkernel
│   ├── main.cpp       # Kernel entry point
│   ├── memory.cpp     # Memory management
│   ├── process.cpp    # Process/thread management
│   ├── ipc.cpp        # Inter-process communication
│   └── interrupt.cpp  # Interrupt handling
├── include/
│   ├── kernel/        # Kernel headers
│   ├── os2api/        # OS/2 API headers
│   └── boot/          # Boot headers
├── libraries/
│   └── os2api/        # OS/2 API implementation
├── servers/           # Userspace servers
│   ├── exec/          # Process execution server
│   ├── os2/           # OS/2 personality server
│   └── dos/           # DOS compatibility server
├── loaders/
│   └── lx/            # LX executable loader
├── filesys/           # Filesystem drivers
│   ├── fat32/
│   └── jfs/
├── docs/              # Documentation
│   ├── ARCHITECTURE.md
│   └── API.md
└── tests/             # Test suite
```

### Coding Standards

1. **C++ Standard:** C++17 (use modern features)
2. **Naming:**
   - Classes: `PascalCase` (e.g., `ProcessManager`)
   - Functions: `camelCase` (e.g., `allocatePage`)
   - Variables: `camelCase` with trailing underscore for members (e.g., `totalPages_`)
   - Constants: `UPPER_CASE` (e.g., `MAX_PROCESSES`)
3. **Kernel Code:**
   - No exceptions (`-fno-exceptions`)
   - No RTTI (`-fno-rtti`)
   - No standard library (use custom implementations)
   - Return `Status` enum for error handling
4. **Userspace Code:**
   - Can use exceptions
   - Return OS/2 error codes (ULONG)
5. **Headers:**
   - Use include guards: `#ifndef OSTWO_PATH_FILE_HPP`
   - Put in appropriate namespace: `OSTwo::Kernel::`

### Building Documentation

```bash
# Generate API documentation (requires Doxygen)
doxygen Doxyfile

# View documentation
firefox docs/html/index.html
```

### Running Tests

```bash
cd build

# Run all tests
ctest

# Run with verbose output
ctest -V

# Run specific test
ctest -R memory_tests

# Run in parallel
ctest -j8
```

### Debugging with GDB

```bash
# Terminal 1: Start QEMU with GDB server
qemu-system-x86_64 \
    -kernel build/kernel/ostwo_kernel.elf \
    -m 512M \
    -s -S

# Terminal 2: Connect GDB
gdb build/kernel/ostwo_kernel.elf
(gdb) target remote :1234
(gdb) break kernel_main
(gdb) continue
```

**Useful GDB commands:**
- `info registers` - Show CPU registers
- `x/10i $rip` - Disassemble at current instruction
- `backtrace` - Show call stack
- `info threads` - List all threads

## Troubleshooting

### Build Issues

**Problem:** `CMake version too old`
```bash
# Solution: Install newer CMake
pip3 install --user --upgrade cmake
```

**Problem:** `Compiler doesn't support C++17`
```bash
# Solution: Install newer GCC
sudo apt install gcc-11 g++-11
export CXX=g++-11
export CC=gcc-11
```

**Problem:** `NASM not found - bootloader will not be built`
```bash
# Solution: Install NASM
sudo apt install nasm
```

**Problem:** `undefined reference to operator new`
```bash
# Solution: Rebuild everything
rm -rf build && mkdir build && cd build && cmake .. && cmake --build .
```

### Runtime Issues

**Problem:** QEMU immediately exits
```bash
# Solution: Add -no-reboot and -d int for debugging
qemu-system-x86_64 -kernel build/kernel/ostwo_kernel.elf -m 512M -no-reboot -d int
```

**Problem:** Kernel triple faults
```bash
# Check for memory issues or invalid page tables
# Enable QEMU logging
qemu-system-x86_64 -kernel ... -d int,cpu_reset -D qemu.log
```

**Problem:** No output on screen
```bash
# Verify VGA buffer is being written to
# Check Console::initialize() is called
# Use serial output: qemu ... -serial stdio
```

### Common Errors

**Linker Error:** `cannot find entry symbol _start`
- **Cause:** Boot assembly not included
- **Fix:** Enable NASM and rebuild boot module

**Compiler Error:** `'array' in namespace 'std' does not name a template type`
- **Cause:** Missing C++ standard library headers
- **Fix:** Include `<array>` in affected files

**Runtime Error:** Kernel hangs after "Starting userspace servers"
- **Cause:** Interrupt handling not initialized or deadlock
- **Fix:** Check interrupt manager initialization

## Documentation

- **[CLAUDE.md](CLAUDE.md)** - Development guide for Claude Code instances
- **[docs/ARCHITECTURE.md](docs/ARCHITECTURE.md)** - Detailed architecture documentation
- **Inline Comments** - See source files for implementation details
- **OS/2 API Reference** - Coming soon
- **Kernel API Reference** - Coming soon

## Contributing

We welcome contributions! Here's how to get started:

1. **Fork the repository**
2. **Create a feature branch:** `git checkout -b feature/amazing-feature`
3. **Make your changes** following coding standards
4. **Test your changes:** `cmake --build . && ctest`
5. **Commit your changes:** `git commit -m 'Add amazing feature'`
6. **Push to the branch:** `git push origin feature/amazing-feature`
7. **Open a Pull Request**

### Contribution Guidelines

- Follow the coding standards (see Development section)
- Write tests for new functionality
- Update documentation
- Ensure all tests pass
- Keep commits focused and atomic
- Write clear commit messages

### Areas Needing Help

- 🐛 Bug fixes and testing
- 📝 Documentation improvements
- 🔧 Device drivers
- 🌐 Network stack
- 📦 Filesystem implementations
- 🎨 Graphics subsystem
- 🧪 Unit tests

## License

[To be determined - considering compatibility with OSFree licensing]

OSTwo is inspired by and based on architectural concepts from the OSFree project.

## Acknowledgments

- **OSFree Team** - For the original OS/2 reimplementation
- **IBM** - For creating OS/2
- **OSDev Community** - For OS development resources
- **Contributors** - Everyone who has contributed to OSTwo

## Links

- **OSFree Project:** https://www.osfree.org/
- **OSFree GitHub:** https://github.com/osfree-project/osfree
- **OS/2 Museum:** http://www.os2museum.com/
- **OSDev Wiki:** https://wiki.osdev.org/
- **Original OS/2:** https://en.wikipedia.org/wiki/OS/2

## Support

- **Issues:** Report bugs and request features on GitHub Issues
- **Discussions:** Join discussions on GitHub Discussions
- **Documentation:** Check the `docs/` directory

---

**Note:** OSTwo is in early alpha development. It is not suitable for production use. Use at your own risk.

**Status:** Active Development | **Version:** 0.0.1-alpha | **Architecture:** x86-64
