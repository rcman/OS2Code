# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

OSTwo is a modern C++ reimplementation of OS/2, inspired by the OSFree project. Key distinctions:

- **C++-based**: Written in C++17 (not C like OSFree)
- **No Windows support**: Focuses solely on OS/2 and DOS compatibility
- **Microkernel architecture**: Userspace servers implement OS/2 Control Program functionality
- **Modern development practices**: Uses CMake, modern C++ idioms, and RAII principles

**Status**: Alpha (version 0.0.1) - not feature-complete or stable

## Build System

### Build Commands

```bash
# Initial build
mkdir build && cd build
cmake ..
cmake --build .

# Build specific components
cmake --build . --target kernel
cmake --build . --target servers

# Run tests
ctest
```

### Build Options

Configure with `-D<OPTION>=ON/OFF`:
- `BUILD_KERNEL` - Build the OSTwo kernel (default: ON)
- `BUILD_SERVERS` - Build userspace servers (default: ON)
- `BUILD_LOADERS` - Build executable loaders (default: ON)
- `BUILD_FILESYSTEMS` - Build filesystem drivers (default: ON)
- `BUILD_TESTS` - Build test suite (default: ON)

### Cross-compilation

OSTwo requires cross-compilation toolchains for the target architecture. Kernel code is compiled with `-ffreestanding -nostdlib -fno-exceptions -fno-rtti`.

## Architecture

### High-Level Design

OSTwo uses a **microkernel-based architecture** where the kernel provides minimal core services, and most OS/2 functionality is implemented by userspace servers.

**Key architectural principles:**
1. Small, secure kernel with minimal responsibilities
2. Userspace servers for OS/2 API implementation
3. Clear separation between kernel and userland
4. Modern C++ with RAII, no exceptions/RTTI in kernel code
5. OS/2 API compatibility maintained at the server level

### Directory Structure

```
OSTwo/
├── kernel/          - Core microkernel
├── boot/            - Bootloader (FreeLdr-inspired, multiboot support)
├── servers/         - Userspace servers implementing OS/2 functionality
│   ├── exec/        - Process execution and management
│   ├── os2/         - OS/2 personality server
│   └── dos/         - DOS compatibility layer
├── filesys/         - Filesystem drivers
│   ├── fat32/       - FAT32 support
│   └── jfs/         - JFS (Journaled File System) support
├── include/         - Public header files
│   ├── kernel/      - Kernel API headers
│   ├── os2api/      - OS/2 API definitions (C++ versions)
│   └── som/         - System Object Model
├── libraries/       - User-level libraries
│   ├── os2api/      - OS/2 API implementation
│   └── runtime/     - C++ runtime support
├── loaders/         - Executable format loaders
│   └── lx/          - LX (Linear Executable) format loader
├── tools/           - Build and development utilities
├── tests/           - Test suite
└── docs/            - Documentation
```

### Core Components

**1. Kernel** (`kernel/`)
- Minimal microkernel providing: memory management, IPC, scheduling, interrupt handling
- No OS/2-specific logic in kernel itself
- Compiled with `-ffreestanding -nostdlib`

**2. Servers** (`servers/`)
Userspace servers that implement OS/2 Control Program interface:
- `exec` - Process/thread creation, execution, management
- `os2` - OS/2 personality (API implementation)
- `dos` - DOS compatibility layer (NO Windows support)

**3. Loaders** (`loaders/`)
- `lx/` - LX executable format loader with fixup and packing algorithm support
- Based on OSFree's loader design but rewritten in C++

**4. Filesystems** (`filesys/`)
- `fat32/` - FAT32 filesystem driver
- `jfs/` - JFS (IBM's Journaled File System) driver

**5. OS/2 API** (`include/os2api/`, `libraries/os2api/`)
- Modern C++ implementation of OS/2 APIs
- Type-safe wrappers around classic OS/2 types
- Maintains binary compatibility where needed

**6. SOM** (`include/som/`)
- System Object Model reimplemented in C++
- Uses modern C++ features (templates, inheritance) internally

### Type System

OSTwo uses modern C++ types defined in `include/kernel/types.hpp`:
- `uint8`, `uint16`, `uint32`, `uint64` - Unsigned integers
- `int8`, `int16`, `int32`, `int64` - Signed integers
- `PhysAddr`, `VirtAddr` - Address types
- `ProcessId`, `ThreadId` - Resource identifiers
- `Status` enum class - Error codes

OS/2 API compatibility types in `include/os2api/os2def.hpp`:
- `ULONG`, `USHORT`, `BYTE` - Classic OS/2 types
- `PVOID`, `HMODULE`, `TID`, `PID` - Handle types
- Maintains naming conventions for API compatibility

## Development Workflow

### Coding Standards

1. **C++17 standard**: Use modern C++ features (auto, range-for, structured bindings, etc.)
2. **No exceptions in kernel**: Kernel and driver code compiled with `-fno-exceptions -fno-rtti`
3. **RAII everywhere**: Use smart pointers, automatic cleanup, scope guards
4. **Namespaces**: All code in `OSTwo::` namespace, subnamespaces for components
5. **Type safety**: Prefer enum classes, strong typedefs, explicit types over `void*`

### Adding New Components

When adding kernel functionality:
1. Define interfaces in `include/kernel/`
2. Implement in `kernel/` subdirectory
3. Update `kernel/CMakeLists.txt`
4. Keep kernel minimal - consider if it belongs in userspace server

When adding OS/2 API functionality:
1. Define types/constants in `include/os2api/`
2. Implement in `libraries/os2api/`
3. Server-side implementation goes in `servers/os2/`
4. Maintain OS/2 calling conventions and semantics

### Memory Management

- Kernel uses custom allocators (no standard library malloc)
- Userspace can use standard C++ allocators
- Physical memory manager tracks page frames
- Virtual memory manager handles address space layout

## Testing

```bash
# Build and run all tests
cd build
cmake --build . --target test
ctest

# Run specific test suite
ctest -R kernel_tests
ctest -R api_tests

# Verbose test output
ctest -V
```

## Important Conventions

### Include Guards

Use `#ifndef OSTWO_<PATH>_<FILE>_HPP` format:
```cpp
#ifndef OSTWO_KERNEL_TYPES_HPP
#define OSTWO_KERNEL_TYPES_HPP
// ...
#endif
```

### Namespace Usage

```cpp
namespace OSTwo {
namespace Kernel {
    // Kernel code
}
namespace OS2 {
    // OS/2 API code
}
}
```

### Error Handling

- Kernel: Return `Status` enum class values
- OS/2 API: Return `ULONG` error codes (NO_ERROR, ERROR_* constants)
- Userspace: Can use exceptions

### No Windows Support

This is a hard requirement. Do not:
- Include Win16/Win32 compatibility
- Add Windows-specific types or APIs
- Port Windows-related code from OSFree

Focus on:
- OS/2 API compatibility (Warp 4/Merlin target)
- DOS compatibility layer
- Clean, modern C++ implementation

## References

- OSFree Project: https://www.osfree.org/
- OSFree GitHub: https://github.com/osfree-project/osfree
- OS/2 Warp 4 (Merlin) - target compatibility version
