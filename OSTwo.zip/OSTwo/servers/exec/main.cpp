#include "kernel/types.hpp"
#include "kernel/process.hpp"
#include "kernel/ipc.hpp"
#include "os2api/os2def.hpp"

using namespace OSTwo;
using namespace OSTwo::Kernel;

namespace OSTwo {
namespace Servers {
namespace Exec {

// Exec server - handles process execution and management
// This is a userspace server that implements OS/2 DosExecPgm functionality

enum class ExecCommand : uint32 {
    LoadProgram = 1,
    TerminateProcess = 2,
    QueryProcess = 3,
    SetPriority = 4,
};

struct ExecRequest {
    ExecCommand command;
    union {
        struct {
            char programPath[256];
            char arguments[512];
            char environment[512];
            uint32 execFlags;
        } load;

        struct {
            ProcessId pid;
            uint32 exitCode;
        } terminate;

        struct {
            ProcessId pid;
        } query;

        struct {
            ProcessId pid;
            Process::Priority priority;
        } setPriority;
    } data;
};

struct ExecResponse {
    Status status;
    union {
        struct {
            ProcessId pid;
            ThreadId mainThreadId;
        } load;

        struct {
            Process::ProcessState state;
            char name[64];
            size_t threadCount;
        } query;
    } data;
};

class ExecServer {
public:
    void run() {
        // Create IPC endpoint
        endpoint_ = IPC::sys_endpoint_create(IPC::EndpointType::Server);
        if (endpoint_ == 0) {
            return;  // Failed to create endpoint
        }

        // Main server loop
        while (true) {
            ExecRequest request;
            size_t receivedSize = 0;

            Status status = IPC::sys_receive(endpoint_, &request,
                                            sizeof(request), &receivedSize);

            if (status != Status::Success) {
                continue;
            }

            ExecResponse response;
            handleRequest(request, response);

            IPC::sys_reply(endpoint_, &response, sizeof(response));
        }
    }

private:
    IPC::EndpointId endpoint_;

    void handleRequest(const ExecRequest& request, ExecResponse& response) {
        switch (request.command) {
            case ExecCommand::LoadProgram:
                handleLoadProgram(request, response);
                break;

            case ExecCommand::TerminateProcess:
                handleTerminateProcess(request, response);
                break;

            case ExecCommand::QueryProcess:
                handleQueryProcess(request, response);
                break;

            case ExecCommand::SetPriority:
                handleSetPriority(request, response);
                break;

            default:
                response.status = Status::InvalidParameter;
                break;
        }
    }

    void handleLoadProgram(const ExecRequest& request, ExecResponse& response) {
        // TODO: Load executable using LX loader
        // For now, create a basic process

        const char* progName = request.data.load.programPath;
        VirtAddr entryPoint = 0x400000;  // Default entry point
        size_t stackSize = 65536;  // 64KB stack

        ProcessId pid = Process::ProcessManager::instance().createProcess(
            progName, entryPoint, stackSize);

        if (pid == 0) {
            response.status = Status::OutOfMemory;
            return;
        }

        // Get the main thread ID
        Process::ProcessControlBlock* pcb = Process::ProcessManager::instance().getProcess(pid);
        if (pcb && pcb->getThreadCount() > 0) {
            response.data.load.pid = pid;
            response.data.load.mainThreadId = pcb->getThread(0)->getId();
            response.status = Status::Success;
        } else {
            response.status = Status::Error;
        }
    }

    void handleTerminateProcess(const ExecRequest& request, ExecResponse& response) {
        ProcessId pid = request.data.terminate.pid;
        uint32 exitCode = request.data.terminate.exitCode;

        response.status = Process::ProcessManager::instance().terminateProcess(pid, exitCode);
    }

    void handleQueryProcess(const ExecRequest& request, ExecResponse& response) {
        ProcessId pid = request.data.query.pid;

        Process::ProcessControlBlock* pcb = Process::ProcessManager::instance().getProcess(pid);
        if (!pcb) {
            response.status = Status::NotFound;
            return;
        }

        response.data.query.state = pcb->getState();
        response.data.query.threadCount = pcb->getThreadCount();

        // Copy process name
        const char* name = pcb->getName();
        size_t i = 0;
        while (name[i] && i < 63) {
            response.data.query.name[i] = name[i];
            i++;
        }
        response.data.query.name[i] = '\0';

        response.status = Status::Success;
    }

    void handleSetPriority(const ExecRequest& request, ExecResponse& response) {
        // TODO: Set process/thread priority
        (void)request;
        response.status = Status::NotImplemented;
    }
};

} // namespace Exec
} // namespace Servers
} // namespace OSTwo

// Server entry point
extern "C" void exec_server_main() {
    OSTwo::Servers::Exec::ExecServer server;
    server.run();
}
