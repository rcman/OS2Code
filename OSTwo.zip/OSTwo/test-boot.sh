#!/bin/bash
cd /home/franco/OSTwo

echo "Testing OSTwo Kernel Boot"
echo "========================="
echo

# Update GRUB config to boot immediately
cat > iso/boot/grub/grub.cfg << 'EOF'
set timeout=0
set default=0

menuentry "OSTwo Kernel v0.0.1" {
    multiboot2 /boot/ostwo_kernel.elf
    boot
}
EOF

# Rebuild kernel and ISO
echo "[1/3] Rebuilding kernel..."
cd build && cmake --build . --target kernel 2>&1 | grep -E "(Built|Linking|error)" | tail -3
cd ..

echo "[2/3] Creating ISO..."
cp build/kernel/ostwo_kernel.elf iso/boot/
grub2-mkrescue -o ostwo.iso iso/ 2>&1 | tail -2

echo "[3/3] Booting in QEMU..."
echo
echo "Press Ctrl-A then X to exit QEMU"
echo "Or wait 15 seconds for automatic exit"
echo "===================="

# Boot with timeout
timeout 15 qemu-system-x86_64 \
    -cdrom ostwo.iso \
    -m 512M \
    -serial stdio \
    -d cpu_reset \
    -D /tmp/ostwo_boot.log \
    2>&1

echo
echo "===================="
echo "Boot test complete. Checking logs..."

if [ -f /tmp/ostwo_boot.log ]; then
    echo
    echo "CPU Reset Log (last 30 lines):"
    tail -30 /tmp/ostwo_boot.log
fi
