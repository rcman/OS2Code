#ifndef OSTWO_OS2API_OS2DEF_HPP
#define OSTWO_OS2API_OS2DEF_HPP

// OS/2 API type definitions and constants
// Modern C++ implementation of classic OS/2 types

#include <cstdint>

namespace OSTwo {
namespace OS2 {

// Basic OS/2 types
using BYTE = std::uint8_t;
using USHORT = std::uint16_t;
using ULONG = std::uint32_t;
using SHORT = std::int16_t;
using LONG = std::int32_t;

using BOOL = ULONG;
using CHAR = char;
using UCHAR = unsigned char;

using PVOID = void*;
using PPVOID = void**;

// Handle types
using HMODULE = ULONG;
using TID = ULONG;
using PID = ULONG;

// API return codes
constexpr ULONG NO_ERROR = 0;
constexpr ULONG ERROR_INVALID_PARAMETER = 87;
constexpr ULONG ERROR_NOT_ENOUGH_MEMORY = 8;
constexpr ULONG ERROR_ACCESS_DENIED = 5;

// Boolean values
constexpr BOOL TRUE = 1;
constexpr BOOL FALSE = 0;

} // namespace OS2
} // namespace OSTwo

#endif // OSTWO_OS2API_OS2DEF_HPP
