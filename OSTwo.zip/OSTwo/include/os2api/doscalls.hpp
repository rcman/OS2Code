#ifndef OSTWO_OS2API_DOSCALLS_HPP
#define OSTWO_OS2API_DOSCALLS_HPP

#include "os2api/os2def.hpp"

// Core OS/2 API functions
// Modern C++ implementation of classic OS/2 DosXXX calls

namespace OSTwo {
namespace OS2 {

// Process and Thread Management
ULONG DosCreateThread(TID* ptid, void (*pfn)(ULONG), ULONG param,
                      ULONG flags, ULONG stackSize);
ULONG DosWaitThread(TID* ptid, ULONG waitOption);
ULONG DosExit(ULONG action, ULONG result);
ULONG DosSleep(ULONG msec);

// Process Management
ULONG DosExecPgm(char* objname, LONG objnameLength, ULONG execFlags,
                 const char* args, const char* env, void* retcode,
                 const char* pgmname);
ULONG DosWaitChild(ULONG action, ULONG waitOption, void* retcode,
                   PID* pidProcess, PID pidWait);

// Memory Management
ULONG DosAllocMem(PVOID* ppv, ULONG cb, ULONG flags);
ULONG DosFreeMem(PVOID pv);
ULONG DosSetMem(PVOID pv, ULONG cb, ULONG flags);
ULONG DosQueryMem(PVOID pv, ULONG* pcb, ULONG* pflags);

// Semaphores
ULONG DosCreateMutexSem(const char* name, ULONG* phMutex, ULONG flags, BOOL state);
ULONG DosCloseMutexSem(ULONG hMutex);
ULONG DosRequestMutexSem(ULONG hMutex, ULONG timeout);
ULONG DosReleaseMutexSem(ULONG hMutex);

ULONG DosCreateEventSem(const char* name, ULONG* phEvent, ULONG flags, BOOL state);
ULONG DosCloseEventSem(ULONG hEvent);
ULONG DosPostEventSem(ULONG hEvent);
ULONG DosWaitEventSem(ULONG hEvent, ULONG timeout);
ULONG DosResetEventSem(ULONG hEvent, ULONG* postCount);

// File I/O
ULONG DosOpen(const char* fileName, ULONG* phFile, ULONG* actionTaken,
              ULONG fileSize, ULONG attribute, ULONG openFlags,
              ULONG openMode, PVOID eabp);
ULONG DosClose(ULONG hFile);
ULONG DosRead(ULONG hFile, PVOID buffer, ULONG cbRead, ULONG* pcbActual);
ULONG DosWrite(ULONG hFile, const PVOID buffer, ULONG cbWrite, ULONG* pcbActual);
ULONG DosSetFilePtr(ULONG hFile, LONG ib, ULONG method, ULONG* ibActual);

// Directory Operations
ULONG DosCreateDir(const char* dirName, PVOID eabp);
ULONG DosDeleteDir(const char* dirName);
ULONG DosSetCurrentDir(const char* dirName);
ULONG DosQueryCurrentDir(ULONG diskNum, BYTE* dirName, ULONG* pcbDirName);

// Module Management (DLL loading)
ULONG DosLoadModule(char* objname, ULONG objnameLength, const char* moduleName,
                    HMODULE* phModule);
ULONG DosFreeModule(HMODULE hModule);
ULONG DosQueryProcAddr(HMODULE hModule, ULONG ordinal, const char* procName,
                       PVOID* ppfn);

// Information Functions
ULONG DosGetInfoBlocks(void** ptib, void** ppib);
ULONG DosQuerySysInfo(ULONG iStart, ULONG iLast, PVOID buffer, ULONG cbBuffer);

// Named Pipes
ULONG DosCreateNPipe(const char* pipeName, ULONG* phPipe, ULONG openMode,
                     ULONG pipeMode, ULONG outBufSize, ULONG inBufSize,
                     ULONG timeout);
ULONG DosConnectNPipe(ULONG hPipe);
ULONG DosDisConnectNPipe(ULONG hPipe);

// Shared Memory
ULONG DosAllocSharedMem(PVOID* ppv, const char* name, ULONG size, ULONG flags);
ULONG DosGetSharedMem(PVOID pv, ULONG flags);
ULONG DosGiveSharedMem(PVOID pv, PID pid, ULONG flags);

// Error Handling
ULONG DosError(ULONG error);
ULONG DosGetMessage(char** ivTable, ULONG ivCount, char* dataArea,
                    ULONG cbDataArea, ULONG msgNumber, const char* fileName,
                    ULONG* pcbMsg);

// System Info
struct DATETIME {
    UCHAR hours;
    UCHAR minutes;
    UCHAR seconds;
    UCHAR hundredths;
    UCHAR day;
    UCHAR month;
    USHORT year;
    SHORT timezone;
    UCHAR weekday;
};

ULONG DosGetDateTime(DATETIME* pdt);
ULONG DosSetDateTime(DATETIME* pdt);

// Flags for DosAllocMem
constexpr ULONG PAG_READ = 0x00000001;
constexpr ULONG PAG_WRITE = 0x00000002;
constexpr ULONG PAG_EXECUTE = 0x00000004;
constexpr ULONG PAG_GUARD = 0x00000008;
constexpr ULONG PAG_COMMIT = 0x00000010;
constexpr ULONG PAG_DECOMMIT = 0x00000020;
constexpr ULONG OBJ_TILE = 0x00000040;
constexpr ULONG OBJ_PROTECTED = 0x00000080;
constexpr ULONG OBJ_GETTABLE = 0x00000100;
constexpr ULONG OBJ_GIVEABLE = 0x00000200;

// Thread flags
constexpr ULONG CREATE_READY = 0x00000000;
constexpr ULONG CREATE_SUSPENDED = 0x00000001;
constexpr ULONG STACK_SPARSE = 0x00000000;
constexpr ULONG STACK_COMMITTED = 0x00000002;

// Wait options
constexpr ULONG DCWW_WAIT = 0x00000000;
constexpr ULONG DCWW_NOWAIT = 0x00000001;

} // namespace OS2
} // namespace OSTwo

#endif // OSTWO_OS2API_DOSCALLS_HPP
