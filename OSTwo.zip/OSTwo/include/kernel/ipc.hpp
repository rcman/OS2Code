#ifndef OSTWO_KERNEL_IPC_HPP
#define OSTWO_KERNEL_IPC_HPP

#include "kernel/types.hpp"
#include "kernel/process.hpp"

namespace OSTwo {
namespace Kernel {
namespace IPC {

// IPC message types
enum class MessageType : uint32 {
    Call = 0,      // Synchronous call
    Reply = 1,     // Reply to call
    Send = 2,      // Asynchronous send
    Receive = 3,   // Receive message
};

// Maximum message size
constexpr size_t MAX_MESSAGE_SIZE = 4096;

// IPC message
struct Message {
    ThreadId sender;
    ThreadId receiver;
    MessageType type;
    uint32 messageId;
    size_t dataSize;
    uint8 data[MAX_MESSAGE_SIZE];
};

// IPC endpoint
using EndpointId = uint32;

// Endpoint types
enum class EndpointType : uint8 {
    Server,    // Server endpoint (many clients)
    Client,    // Client endpoint (one server)
    Channel,   // Bidirectional channel
};

// IPC Manager
class IPCManager {
public:
    static IPCManager& instance();

    void initialize();

    // Endpoint management
    EndpointId createEndpoint(EndpointType type);
    Status destroyEndpoint(EndpointId endpoint);
    Status connectEndpoint(EndpointId client, EndpointId server);

    // Message passing
    Status send(EndpointId endpoint, const void* data, size_t size);
    Status receive(EndpointId endpoint, void* buffer, size_t bufferSize, size_t* receivedSize);
    Status call(EndpointId endpoint, const void* request, size_t requestSize,
                void* reply, size_t replyBufferSize, size_t* replySize);
    Status reply(EndpointId endpoint, const void* data, size_t size);

    // Shared memory
    VirtAddr createSharedMemory(size_t size);
    Status mapSharedMemory(VirtAddr sharedAddr, ProcessId targetProcess, VirtAddr* mappedAddr);
    Status unmapSharedMemory(VirtAddr addr);
    Status destroySharedMemory(VirtAddr addr);

private:
    IPCManager() = default;

    struct Endpoint {
        EndpointId id;
        EndpointType type;
        ThreadId owner;
        EndpointId connectedTo;
        Message* messageQueue;
        size_t queueSize;
        size_t queueCapacity;
    };

    struct SharedMemoryRegion {
        VirtAddr address;
        size_t size;
        PhysAddr physicalPages;
        ProcessId creator;
        uint32 refCount;
    };

    static constexpr size_t MAX_ENDPOINTS = 1024;
    static constexpr size_t MAX_SHARED_REGIONS = 256;

    Endpoint endpoints_[MAX_ENDPOINTS];
    size_t endpointCount_;

    SharedMemoryRegion sharedRegions_[MAX_SHARED_REGIONS];
    size_t sharedRegionCount_;

    EndpointId nextEndpointId_;

    Endpoint* getEndpoint(EndpointId id);
    Status enqueueMessage(Endpoint* ep, const Message& msg);
    Status dequeueMessage(Endpoint* ep, Message* msg);
};

// System calls for IPC
extern "C" {
    EndpointId sys_endpoint_create(EndpointType type);
    Status sys_endpoint_destroy(EndpointId endpoint);
    Status sys_endpoint_connect(EndpointId client, EndpointId server);

    Status sys_send(EndpointId endpoint, const void* data, size_t size);
    Status sys_receive(EndpointId endpoint, void* buffer, size_t bufferSize, size_t* receivedSize);
    Status sys_call(EndpointId endpoint, const void* request, size_t requestSize,
                    void* reply, size_t replyBufferSize, size_t* replySize);
    Status sys_reply(EndpointId endpoint, const void* data, size_t size);
}

} // namespace IPC
} // namespace Kernel
} // namespace OSTwo

#endif // OSTWO_KERNEL_IPC_HPP
