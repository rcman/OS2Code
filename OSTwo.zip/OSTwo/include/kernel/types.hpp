#ifndef OSTWO_KERNEL_TYPES_HPP
#define OSTWO_KERNEL_TYPES_HPP

#include <cstdint>
#include <cstddef>

namespace OSTwo {
namespace Kernel {

// Basic types
using uint8 = std::uint8_t;
using uint16 = std::uint16_t;
using uint32 = std::uint32_t;
using uint64 = std::uint64_t;

using int8 = std::int8_t;
using int16 = std::int16_t;
using int32 = std::int32_t;
using int64 = std::int64_t;

using size_t = std::size_t;
using uintptr = std::uintptr_t;

// Physical and virtual addresses
using PhysAddr = uint64;
using VirtAddr = uint64;

// Process and thread identifiers
using ProcessId = uint32;
using ThreadId = uint32;

// Status codes
enum class Status : uint32 {
    Success = 0,
    Error = 1,
    InvalidParameter = 2,
    OutOfMemory = 3,
    NotImplemented = 4,
    AccessDenied = 5,
    NotFound = 6,
};

} // namespace Kernel
} // namespace OSTwo

#endif // OSTWO_KERNEL_TYPES_HPP
