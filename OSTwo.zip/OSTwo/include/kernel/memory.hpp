#ifndef OSTWO_KERNEL_MEMORY_HPP
#define OSTWO_KERNEL_MEMORY_HPP

#include "kernel/types.hpp"

namespace OSTwo {
namespace Kernel {
namespace Memory {

// Page size (4KB standard)
constexpr size_t PAGE_SIZE = 4096;
constexpr size_t PAGE_SHIFT = 12;

// Page frame attributes
enum class PageFlags : uint32 {
    None = 0,
    Present = 1 << 0,
    Writable = 1 << 1,
    User = 1 << 2,
    WriteThrough = 1 << 3,
    CacheDisable = 1 << 4,
    Accessed = 1 << 5,
    Dirty = 1 << 6,
    Huge = 1 << 7,
    Global = 1 << 8,
};

inline PageFlags operator|(PageFlags a, PageFlags b) {
    return static_cast<PageFlags>(static_cast<uint32>(a) | static_cast<uint32>(b));
}

inline PageFlags operator&(PageFlags a, PageFlags b) {
    return static_cast<PageFlags>(static_cast<uint32>(a) & static_cast<uint32>(b));
}

// Physical Memory Manager
class PhysicalMemoryManager {
public:
    static PhysicalMemoryManager& instance();

    // Initialize with memory map from bootloader
    void initialize(PhysAddr memoryStart, PhysAddr memoryEnd);

    // Allocate/free physical pages
    PhysAddr allocatePage();
    void freePage(PhysAddr addr);

    // Allocate contiguous pages
    PhysAddr allocatePages(size_t count);
    void freePages(PhysAddr addr, size_t count);

    // Get memory statistics
    size_t getTotalPages() const { return totalPages_; }
    size_t getFreePages() const { return freePages_; }
    size_t getUsedPages() const { return totalPages_ - freePages_; }

private:
    PhysicalMemoryManager() = default;

    PhysAddr bitmapStart_;
    size_t totalPages_;
    size_t freePages_;
    uint32* bitmap_;

    void setBit(size_t pageIndex);
    void clearBit(size_t pageIndex);
    bool testBit(size_t pageIndex) const;
    size_t findFreePage();
    size_t findFreePages(size_t count);
};

// Virtual Memory Manager
class VirtualMemoryManager {
public:
    static VirtualMemoryManager& instance();

    // Map virtual to physical address
    Status map(VirtAddr virt, PhysAddr phys, PageFlags flags);
    Status unmap(VirtAddr virt);

    // Allocate virtual memory region
    VirtAddr allocate(size_t size, PageFlags flags);
    void free(VirtAddr addr, size_t size);

    // Get physical address for virtual address
    PhysAddr getPhysical(VirtAddr virt) const;

    // Create new address space (for processes)
    PhysAddr createAddressSpace();
    void destroyAddressSpace(PhysAddr pageDirectory);
    void switchAddressSpace(PhysAddr pageDirectory);

private:
    VirtualMemoryManager() = default;

    PhysAddr currentPageDirectory_;
    VirtAddr kernelHeapStart_;
    VirtAddr kernelHeapEnd_;
    VirtAddr kernelHeapCurrent_;
};

// Kernel heap allocator
class KernelHeap {
public:
    static KernelHeap& instance();

    void initialize(VirtAddr start, size_t size);

    void* allocate(size_t size, size_t alignment = 16);
    void free(void* ptr);

    void* reallocate(void* ptr, size_t newSize);

    size_t getTotalSize() const { return totalSize_; }
    size_t getUsedSize() const { return usedSize_; }

private:
    KernelHeap() = default;

    struct BlockHeader {
        size_t size;
        bool free;
        BlockHeader* next;
        BlockHeader* prev;
    };

    VirtAddr heapStart_;
    size_t totalSize_;
    size_t usedSize_;
    BlockHeader* firstBlock_;

    BlockHeader* findFreeBlock(size_t size);
    void splitBlock(BlockHeader* block, size_t size);
    void mergeBlocks();
};

// Utility functions
inline PhysAddr virtToPhys(VirtAddr virt) {
    return VirtualMemoryManager::instance().getPhysical(virt);
}

inline VirtAddr pageAlign(VirtAddr addr) {
    return (addr + PAGE_SIZE - 1) & ~(PAGE_SIZE - 1);
}

inline size_t bytesToPages(size_t bytes) {
    return (bytes + PAGE_SIZE - 1) / PAGE_SIZE;
}

} // namespace Memory
} // namespace Kernel
} // namespace OSTwo

#endif // OSTWO_KERNEL_MEMORY_HPP
