#ifndef OSTWO_KERNEL_INTERRUPT_HPP
#define OSTWO_KERNEL_INTERRUPT_HPP

#include "kernel/types.hpp"

namespace OSTwo {
namespace Kernel {
namespace Interrupt {

// Interrupt vectors
constexpr uint8 DIVIDE_ERROR = 0;
constexpr uint8 DEBUG = 1;
constexpr uint8 NMI = 2;
constexpr uint8 BREAKPOINT = 3;
constexpr uint8 OVERFLOW = 4;
constexpr uint8 BOUND_RANGE = 5;
constexpr uint8 INVALID_OPCODE = 6;
constexpr uint8 DEVICE_NOT_AVAILABLE = 7;
constexpr uint8 DOUBLE_FAULT = 8;
constexpr uint8 INVALID_TSS = 10;
constexpr uint8 SEGMENT_NOT_PRESENT = 11;
constexpr uint8 STACK_FAULT = 12;
constexpr uint8 GENERAL_PROTECTION = 13;
constexpr uint8 PAGE_FAULT = 14;
constexpr uint8 FPU_ERROR = 16;
constexpr uint8 ALIGNMENT_CHECK = 17;
constexpr uint8 MACHINE_CHECK = 18;
constexpr uint8 SIMD_ERROR = 19;

// Hardware interrupts (IRQs)
constexpr uint8 IRQ_BASE = 32;
constexpr uint8 IRQ_TIMER = IRQ_BASE + 0;
constexpr uint8 IRQ_KEYBOARD = IRQ_BASE + 1;
constexpr uint8 IRQ_CASCADE = IRQ_BASE + 2;
constexpr uint8 IRQ_COM2 = IRQ_BASE + 3;
constexpr uint8 IRQ_COM1 = IRQ_BASE + 4;
constexpr uint8 IRQ_LPT2 = IRQ_BASE + 5;
constexpr uint8 IRQ_FLOPPY = IRQ_BASE + 6;
constexpr uint8 IRQ_LPT1 = IRQ_BASE + 7;
constexpr uint8 IRQ_RTC = IRQ_BASE + 8;
constexpr uint8 IRQ_MOUSE = IRQ_BASE + 12;
constexpr uint8 IRQ_FPU = IRQ_BASE + 13;
constexpr uint8 IRQ_ATA_PRIMARY = IRQ_BASE + 14;
constexpr uint8 IRQ_ATA_SECONDARY = IRQ_BASE + 15;

// System call interrupt
constexpr uint8 SYSCALL_VECTOR = 0x80;

// Interrupt stack frame
struct InterruptFrame {
    uint64 r15, r14, r13, r12, r11, r10, r9, r8;
    uint64 rbp, rdi, rsi, rdx, rcx, rbx, rax;
    uint64 interruptNumber;
    uint64 errorCode;
    uint64 rip;
    uint64 cs;
    uint64 rflags;
    uint64 rsp;
    uint64 ss;
};

// Interrupt handler function type
using InterruptHandler = void (*)(InterruptFrame* frame);

// IDT (Interrupt Descriptor Table) entry
struct IDTEntry {
    uint16 offsetLow;
    uint16 selector;
    uint8 ist;
    uint8 flags;
    uint16 offsetMiddle;
    uint32 offsetHigh;
    uint32 reserved;
} __attribute__((packed));

// IDT register
struct IDTRegister {
    uint16 limit;
    uint64 base;
} __attribute__((packed));

// Interrupt Manager
class InterruptManager {
public:
    static InterruptManager& instance();

    void initialize();

    // Register interrupt handlers
    void registerHandler(uint8 vector, InterruptHandler handler);
    void unregisterHandler(uint8 vector);

    // Enable/disable interrupts
    static void enable();
    static void disable();
    static bool areEnabled();

    // IRQ management
    void enableIRQ(uint8 irq);
    void disableIRQ(uint8 irq);
    void sendEOI(uint8 irq);

    // Dispatch interrupt to handler
    void dispatchInterrupt(uint8 vector, InterruptFrame* frame);

private:
    InterruptManager() = default;

    static constexpr size_t IDT_ENTRIES = 256;

    IDTEntry idt_[IDT_ENTRIES];
    InterruptHandler handlers_[IDT_ENTRIES];

    void setIDTEntry(uint8 vector, uint64 handler, uint8 flags);
    void loadIDT();
    void initializePIC();
};

// RAII interrupt guard
class InterruptGuard {
public:
    InterruptGuard() {
        wasEnabled_ = InterruptManager::areEnabled();
        InterruptManager::disable();
    }

    ~InterruptGuard() {
        if (wasEnabled_) {
            InterruptManager::enable();
        }
    }

    InterruptGuard(const InterruptGuard&) = delete;
    InterruptGuard& operator=(const InterruptGuard&) = delete;

private:
    bool wasEnabled_;
};

// Assembly interrupt stubs (defined in assembly)
extern "C" {
    void interrupt_stub_0();
    void interrupt_stub_1();
    // ... more stubs
    void interrupt_stub_255();

    void interrupt_handler_common(InterruptFrame* frame);
}

} // namespace Interrupt
} // namespace Kernel
} // namespace OSTwo

#endif // OSTWO_KERNEL_INTERRUPT_HPP
