#ifndef OSTWO_KERNEL_PROCESS_HPP
#define OSTWO_KERNEL_PROCESS_HPP

#include "kernel/types.hpp"
#include "kernel/memory.hpp"
#include <array>

namespace OSTwo {
namespace Kernel {
namespace Process {

// Maximum number of processes and threads
constexpr size_t MAX_PROCESSES = 256;
constexpr size_t MAX_THREADS_PER_PROCESS = 64;

// Process states
enum class ProcessState : uint8 {
    Created,
    Ready,
    Running,
    Blocked,
    Terminated,
};

// Thread states
enum class ThreadState : uint8 {
    Created,
    Ready,
    Running,
    Blocked,
    Waiting,
    Terminated,
};

// Priority levels (0 = highest)
enum class Priority : uint8 {
    Critical = 0,
    High = 1,
    Normal = 2,
    Low = 3,
    Idle = 4,
};

// CPU context saved during context switch
struct CpuContext {
    uint64 rax, rbx, rcx, rdx;
    uint64 rsi, rdi, rbp, rsp;
    uint64 r8, r9, r10, r11;
    uint64 r12, r13, r14, r15;
    uint64 rip, rflags;
    uint64 cr3;  // Page directory base
};

// Thread Control Block
class Thread {
public:
    ThreadId getId() const { return id_; }
    ProcessId getProcessId() const { return processId_; }
    ThreadState getState() const { return state_; }
    Priority getPriority() const { return priority_; }

    void setState(ThreadState state) { state_ = state; }
    void setPriority(Priority priority) { priority_ = priority; }

    CpuContext& getContext() { return context_; }
    const CpuContext& getContext() const { return context_; }

    VirtAddr getStackPointer() const { return stackPointer_; }
    size_t getStackSize() const { return stackSize_; }

private:
    friend class ProcessManager;

    ThreadId id_;
    ProcessId processId_;
    ThreadState state_;
    Priority priority_;
    CpuContext context_;
    VirtAddr stackPointer_;
    size_t stackSize_;
    uint64 cpuTimeUsed_;
    uint64 sleepUntil_;
};

// Process Control Block
class ProcessControlBlock {
public:
    ProcessId getId() const { return id_; }
    ProcessState getState() const { return state_; }
    const char* getName() const { return name_; }

    PhysAddr getPageDirectory() const { return pageDirectory_; }

    Thread* getThread(ThreadId tid);
    size_t getThreadCount() const { return threadCount_; }

private:
    friend class ProcessManager;

    ProcessId id_;
    ProcessState state_;
    char name_[64];

    PhysAddr pageDirectory_;
    VirtAddr baseAddress_;
    size_t memorySize_;

    std::array<Thread*, MAX_THREADS_PER_PROCESS> threads_;
    size_t threadCount_;

    ProcessId parentId_;
    uint64 creationTime_;
    uint32 exitCode_;
};

// Process Manager
class ProcessManager {
public:
    static ProcessManager& instance();

    void initialize();

    // Process management
    ProcessId createProcess(const char* name, VirtAddr entryPoint, size_t stackSize);
    Status terminateProcess(ProcessId pid, uint32 exitCode);
    ProcessControlBlock* getProcess(ProcessId pid);

    // Thread management
    ThreadId createThread(ProcessId pid, VirtAddr entryPoint, size_t stackSize, Priority priority);
    Status terminateThread(ThreadId tid);
    Thread* getThread(ThreadId tid);
    Thread* getCurrentThread() { return currentThread_; }

    // Scheduling
    void schedule();
    void yield();
    void sleep(uint64 milliseconds);

    // Statistics
    size_t getProcessCount() const { return processCount_; }
    size_t getTotalThreadCount() const { return totalThreadCount_; }

private:
    ProcessManager() = default;

    std::array<ProcessControlBlock*, MAX_PROCESSES> processes_;
    size_t processCount_;
    size_t totalThreadCount_;

    Thread* currentThread_;
    Thread* readyQueue_[5][MAX_PROCESSES * MAX_THREADS_PER_PROCESS];  // Per priority level
    size_t readyQueueSize_[5];

    ProcessId nextProcessId_;
    ThreadId nextThreadId_;

    void addToReadyQueue(Thread* thread);
    Thread* getNextThread();
    void contextSwitch(Thread* from, Thread* to);
};

// System calls for process/thread management
extern "C" {
    ProcessId sys_getpid();
    ThreadId sys_gettid();
    ProcessId sys_fork();
    Status sys_exec(const char* path, const char* args[], const char* env[]);
    void sys_exit(uint32 exitCode);
    void sys_yield();
    void sys_sleep(uint64 milliseconds);
}

} // namespace Process
} // namespace Kernel
} // namespace OSTwo

#endif // OSTWO_KERNEL_PROCESS_HPP
