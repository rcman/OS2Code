#ifndef OSTWO_BOOT_MULTIBOOT_HPP
#define OSTWO_BOOT_MULTIBOOT_HPP

#include <cstdint>

namespace OSTwo {
namespace Boot {

// Multiboot1 header magic
constexpr uint32_t MULTIBOOT_HEADER_MAGIC = 0x1BADB002;
constexpr uint32_t MULTIBOOT_BOOTLOADER_MAGIC = 0x2BADB002;

// Multiboot2 header magic
constexpr uint32_t MULTIBOOT2_HEADER_MAGIC = 0xE85250D6;
constexpr uint32_t MULTIBOOT2_BOOTLOADER_MAGIC = 0x36d76289;

// Multiboot header flags
constexpr uint32_t MULTIBOOT_PAGE_ALIGN = 1 << 0;
constexpr uint32_t MULTIBOOT_MEMORY_INFO = 1 << 1;
constexpr uint32_t MULTIBOOT_VIDEO_MODE = 1 << 2;

// Multiboot header structure
struct MultibootHeader {
    uint32_t magic;
    uint32_t flags;
    uint32_t checksum;
    uint32_t header_addr;
    uint32_t load_addr;
    uint32_t load_end_addr;
    uint32_t bss_end_addr;
    uint32_t entry_addr;
} __attribute__((packed));

// Memory map entry
struct MultibootMmapEntry {
    uint32_t size;
    uint64_t addr;
    uint64_t len;
    uint32_t type;
} __attribute__((packed));

// Multiboot info structure
struct MultibootInfo {
    uint32_t flags;
    uint32_t mem_lower;
    uint32_t mem_upper;
    uint32_t boot_device;
    uint32_t cmdline;
    uint32_t mods_count;
    uint32_t mods_addr;
    uint32_t syms[4];
    uint32_t mmap_length;
    uint32_t mmap_addr;
    uint32_t drives_length;
    uint32_t drives_addr;
    uint32_t config_table;
    uint32_t boot_loader_name;
    uint32_t apm_table;
    uint32_t vbe_control_info;
    uint32_t vbe_mode_info;
    uint16_t vbe_mode;
    uint16_t vbe_interface_seg;
    uint16_t vbe_interface_off;
    uint16_t vbe_interface_len;
} __attribute__((packed));

} // namespace Boot
} // namespace OSTwo

#endif // OSTWO_BOOT_MULTIBOOT_HPP
