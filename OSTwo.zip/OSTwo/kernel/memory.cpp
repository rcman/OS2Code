#include "kernel/memory.hpp"
#include "kernel/interrupt.hpp"

namespace OSTwo {
namespace Kernel {
namespace Memory {

// Physical Memory Manager Implementation
PhysicalMemoryManager& PhysicalMemoryManager::instance() {
    static PhysicalMemoryManager instance;
    return instance;
}

void PhysicalMemoryManager::initialize(PhysAddr memoryStart, PhysAddr memoryEnd) {
    totalPages_ = (memoryEnd - memoryStart) / PAGE_SIZE;
    freePages_ = totalPages_;

    // Place bitmap at the start of available memory
    bitmapStart_ = memoryStart;
    size_t bitmapSize = (totalPages_ + 31) / 32 * sizeof(uint32);
    bitmap_ = reinterpret_cast<uint32*>(bitmapStart_);

    // Initialize all pages as free (0 = free)
    for (size_t i = 0; i < (totalPages_ + 31) / 32; i++) {
        bitmap_[i] = 0;
    }

    // Mark bitmap pages as used
    size_t bitmapPages = (bitmapSize + PAGE_SIZE - 1) / PAGE_SIZE;
    for (size_t i = 0; i < bitmapPages; i++) {
        setBit(i);
        freePages_--;
    }
}

PhysAddr PhysicalMemoryManager::allocatePage() {
    Interrupt::InterruptGuard guard;

    size_t pageIndex = findFreePage();
    if (pageIndex == static_cast<size_t>(-1)) {
        return 0;  // Out of memory
    }

    setBit(pageIndex);
    freePages_--;

    return bitmapStart_ + (pageIndex * PAGE_SIZE);
}

void PhysicalMemoryManager::freePage(PhysAddr addr) {
    Interrupt::InterruptGuard guard;

    if (addr < bitmapStart_) return;

    size_t pageIndex = (addr - bitmapStart_) / PAGE_SIZE;
    if (pageIndex >= totalPages_) return;

    if (!testBit(pageIndex)) return;  // Already free

    clearBit(pageIndex);
    freePages_++;
}

PhysAddr PhysicalMemoryManager::allocatePages(size_t count) {
    Interrupt::InterruptGuard guard;

    size_t startPage = findFreePages(count);
    if (startPage == static_cast<size_t>(-1)) {
        return 0;  // Not enough contiguous memory
    }

    for (size_t i = 0; i < count; i++) {
        setBit(startPage + i);
    }
    freePages_ -= count;

    return bitmapStart_ + (startPage * PAGE_SIZE);
}

void PhysicalMemoryManager::freePages(PhysAddr addr, size_t count) {
    Interrupt::InterruptGuard guard;

    for (size_t i = 0; i < count; i++) {
        freePage(addr + (i * PAGE_SIZE));
    }
}

void PhysicalMemoryManager::setBit(size_t pageIndex) {
    size_t byteIndex = pageIndex / 32;
    size_t bitIndex = pageIndex % 32;
    bitmap_[byteIndex] |= (1 << bitIndex);
}

void PhysicalMemoryManager::clearBit(size_t pageIndex) {
    size_t byteIndex = pageIndex / 32;
    size_t bitIndex = pageIndex % 32;
    bitmap_[byteIndex] &= ~(1 << bitIndex);
}

bool PhysicalMemoryManager::testBit(size_t pageIndex) const {
    size_t byteIndex = pageIndex / 32;
    size_t bitIndex = pageIndex % 32;
    return (bitmap_[byteIndex] & (1 << bitIndex)) != 0;
}

size_t PhysicalMemoryManager::findFreePage() {
    for (size_t i = 0; i < totalPages_; i++) {
        if (!testBit(i)) {
            return i;
        }
    }
    return static_cast<size_t>(-1);
}

size_t PhysicalMemoryManager::findFreePages(size_t count) {
    size_t consecutiveFree = 0;
    size_t startPage = 0;

    for (size_t i = 0; i < totalPages_; i++) {
        if (!testBit(i)) {
            if (consecutiveFree == 0) {
                startPage = i;
            }
            consecutiveFree++;
            if (consecutiveFree == count) {
                return startPage;
            }
        } else {
            consecutiveFree = 0;
        }
    }

    return static_cast<size_t>(-1);
}

// Virtual Memory Manager Implementation
VirtualMemoryManager& VirtualMemoryManager::instance() {
    static VirtualMemoryManager instance;
    return instance;
}

Status VirtualMemoryManager::map(VirtAddr virt, PhysAddr phys, PageFlags flags) {
    // x86-64 4-level paging: PML4 -> PDPT -> PD -> PT
    // For simplicity in this alpha version, we'll use a direct mapping approach
    // In a full implementation, this would involve:
    // 1. Extract page table indices from virtual address
    // 2. Walk page table hierarchy, creating tables as needed
    // 3. Set page table entry with physical address and flags

    // Align addresses
    virt = virt & ~(PAGE_SIZE - 1);
    phys = phys & ~(PAGE_SIZE - 1);

    // For now, we use identity mapping for kernel memory
    // In a real implementation, we would:
    // - Get/create PML4 entry
    // - Get/create PDPT entry
    // - Get/create PD entry
    // - Set PT entry

    // This is a stub that assumes paging is already set up by the bootloader
    // and we're just tracking the mappings
    (void)flags;  // Will use flags in full implementation

    return Status::Success;
}

Status VirtualMemoryManager::unmap(VirtAddr virt) {
    // Unmap a page by clearing its page table entry
    // In a full implementation:
    // 1. Walk page table hierarchy
    // 2. Clear the page table entry
    // 3. Invalidate TLB for this address

    virt = virt & ~(PAGE_SIZE - 1);

    // Invalidate TLB entry
    asm volatile("invlpg (%0)" : : "r"(virt) : "memory");

    return Status::Success;
}

VirtAddr VirtualMemoryManager::allocate(size_t size, PageFlags flags) {
    size_t pages = bytesToPages(size);

    // Find free virtual address region
    VirtAddr addr = kernelHeapCurrent_;
    kernelHeapCurrent_ += pages * PAGE_SIZE;

    // Allocate and map physical pages
    for (size_t i = 0; i < pages; i++) {
        PhysAddr phys = PhysicalMemoryManager::instance().allocatePage();
        if (phys == 0) {
            // Rollback
            for (size_t j = 0; j < i; j++) {
                unmap(addr + (j * PAGE_SIZE));
            }
            return 0;
        }
        map(addr + (i * PAGE_SIZE), phys, flags);
    }

    return addr;
}

void VirtualMemoryManager::free(VirtAddr addr, size_t size) {
    size_t pages = bytesToPages(size);

    for (size_t i = 0; i < pages; i++) {
        PhysAddr phys = getPhysical(addr + (i * PAGE_SIZE));
        if (phys != 0) {
            PhysicalMemoryManager::instance().freePage(phys);
            unmap(addr + (i * PAGE_SIZE));
        }
    }
}

PhysAddr VirtualMemoryManager::getPhysical(VirtAddr virt) const {
    // Walk page tables to get physical address
    // For x86-64 with 4-level paging:
    // 1. Read CR3 to get PML4 address
    // 2. Extract indices from virtual address
    // 3. Walk PML4 -> PDPT -> PD -> PT
    // 4. Return physical address from PT entry

    // For this alpha version, we use identity mapping for kernel addresses
    // In a real implementation, we would walk the page tables

    // For now, assume identity mapping for low memory
    if (virt < 0x100000000) {  // Below 4GB
        return static_cast<PhysAddr>(virt);
    }

    return 0;  // Invalid address
}

PhysAddr VirtualMemoryManager::createAddressSpace() {
    // Allocate page for new PML4 (Page Map Level 4) table
    PhysAddr pml4 = PhysicalMemoryManager::instance().allocatePage();

    if (pml4 == 0) {
        return 0;  // Out of memory
    }

    // Zero out the PML4 table
    // In a real implementation, we would:
    // 1. Map the physical page temporarily to access it
    // 2. Zero it out
    // 3. Copy kernel mappings from current PML4
    // 4. Set up user space mappings

    // For this stub, we just return the physical address
    return pml4;
}

void VirtualMemoryManager::destroyAddressSpace(PhysAddr pageDirectory) {
    // Free address space by:
    // 1. Walking all page table levels
    // 2. Freeing all user pages (not kernel pages)
    // 3. Freeing page tables themselves
    // 4. Finally freeing the PML4

    // For this stub implementation, we just free the PML4
    // In a full implementation, we would recursively free all tables
    if (pageDirectory != 0) {
        PhysicalMemoryManager::instance().freePage(pageDirectory);
    }
}

void VirtualMemoryManager::switchAddressSpace(PhysAddr pageDirectory) {
    currentPageDirectory_ = pageDirectory;
    // TODO: Load CR3 register with new page directory
    asm volatile("mov %0, %%cr3" : : "r"(pageDirectory));
}

// Kernel Heap Implementation
KernelHeap& KernelHeap::instance() {
    static KernelHeap instance;
    return instance;
}

void KernelHeap::initialize(VirtAddr start, size_t size) {
    heapStart_ = start;
    totalSize_ = size;
    usedSize_ = sizeof(BlockHeader);

    firstBlock_ = reinterpret_cast<BlockHeader*>(heapStart_);
    firstBlock_->size = size - sizeof(BlockHeader);
    firstBlock_->free = true;
    firstBlock_->next = nullptr;
    firstBlock_->prev = nullptr;
}

void* KernelHeap::allocate(size_t size, size_t alignment) {
    Interrupt::InterruptGuard guard;

    // Align size
    size = (size + alignment - 1) & ~(alignment - 1);

    BlockHeader* block = findFreeBlock(size);
    if (!block) {
        return nullptr;  // Out of memory
    }

    // Split block if too large
    if (block->size > size + sizeof(BlockHeader) + 64) {
        splitBlock(block, size);
    }

    block->free = false;
    usedSize_ += block->size + sizeof(BlockHeader);

    return reinterpret_cast<void*>(reinterpret_cast<uintptr>(block) + sizeof(BlockHeader));
}

void KernelHeap::free(void* ptr) {
    if (!ptr) return;

    Interrupt::InterruptGuard guard;

    BlockHeader* block = reinterpret_cast<BlockHeader*>(
        reinterpret_cast<uintptr>(ptr) - sizeof(BlockHeader));

    block->free = true;
    usedSize_ -= block->size + sizeof(BlockHeader);

    mergeBlocks();
}

void* KernelHeap::reallocate(void* ptr, size_t newSize) {
    if (!ptr) {
        return allocate(newSize);
    }

    BlockHeader* block = reinterpret_cast<BlockHeader*>(
        reinterpret_cast<uintptr>(ptr) - sizeof(BlockHeader));

    if (block->size >= newSize) {
        return ptr;  // Block is large enough
    }

    // Allocate new block and copy data
    void* newPtr = allocate(newSize);
    if (!newPtr) return nullptr;

    // Copy old data
    uint8* src = static_cast<uint8*>(ptr);
    uint8* dst = static_cast<uint8*>(newPtr);
    for (size_t i = 0; i < block->size; i++) {
        dst[i] = src[i];
    }

    free(ptr);
    return newPtr;
}

KernelHeap::BlockHeader* KernelHeap::findFreeBlock(size_t size) {
    BlockHeader* current = firstBlock_;
    BlockHeader* bestFit = nullptr;

    while (current) {
        if (current->free && current->size >= size) {
            if (!bestFit || current->size < bestFit->size) {
                bestFit = current;
            }
        }
        current = current->next;
    }

    return bestFit;
}

void KernelHeap::splitBlock(BlockHeader* block, size_t size) {
    BlockHeader* newBlock = reinterpret_cast<BlockHeader*>(
        reinterpret_cast<uintptr>(block) + sizeof(BlockHeader) + size);

    newBlock->size = block->size - size - sizeof(BlockHeader);
    newBlock->free = true;
    newBlock->next = block->next;
    newBlock->prev = block;

    if (block->next) {
        block->next->prev = newBlock;
    }

    block->size = size;
    block->next = newBlock;
}

void KernelHeap::mergeBlocks() {
    BlockHeader* current = firstBlock_;

    while (current && current->next) {
        if (current->free && current->next->free) {
            current->size += sizeof(BlockHeader) + current->next->size;
            current->next = current->next->next;
            if (current->next) {
                current->next->prev = current;
            }
        } else {
            current = current->next;
        }
    }
}

} // namespace Memory
} // namespace Kernel
} // namespace OSTwo
