// Kernel runtime support - provides operators and functions needed for C++ in kernel mode

#include "kernel/types.hpp"
#include "kernel/memory.hpp"

// Provide new/delete operators for kernel
void* operator new(size_t size) {
    return OSTwo::Kernel::Memory::KernelHeap::instance().allocate(size);
}

void* operator new[](size_t size) {
    return OSTwo::Kernel::Memory::KernelHeap::instance().allocate(size);
}

void operator delete(void* ptr) noexcept {
    OSTwo::Kernel::Memory::KernelHeap::instance().free(ptr);
}

void operator delete(void* ptr, size_t) noexcept {
    OSTwo::Kernel::Memory::KernelHeap::instance().free(ptr);
}

void operator delete[](void* ptr) noexcept {
    OSTwo::Kernel::Memory::KernelHeap::instance().free(ptr);
}

void operator delete[](void* ptr, size_t) noexcept {
    OSTwo::Kernel::Memory::KernelHeap::instance().free(ptr);
}

// Provide assertion failure handler
extern "C" void __assert_fail(const char* assertion, const char* file, unsigned int line, const char* function) {
    (void)assertion;
    (void)file;
    (void)line;
    (void)function;
    // In a real kernel, this would print an error and halt
    while (true) {
        asm volatile("hlt");
    }
}

// For libstdc++ assertions
namespace std {
    void __glibcxx_assert_fail(const char* file, int line, const char* function, const char* condition) {
        (void)file;
        (void)line;
        (void)function;
        (void)condition;
        while (true) {
            asm volatile("hlt");
        }
    }
}

// Pure virtual function call handler
extern "C" void __cxa_pure_virtual() {
    // Pure virtual function called - this is a serious error
    while (true) {
        asm volatile("hlt");
    }
}

// Global constructor/destructor support - provided by linker
typedef void (*init_func_t)();
extern "C" init_func_t __init_array_start;
extern "C" init_func_t __init_array_end;
extern "C" init_func_t __fini_array_start;
extern "C" init_func_t __fini_array_end;

extern "C" void __cxa_atexit(void (*)(void*), void*, void*) {
    // We don't support atexit in kernel
}

extern "C" void __dso_handle() {
    // Dummy
}

// Call global constructors
extern "C" void call_global_constructors() {
    init_func_t* func = &__init_array_start;
    while (func < &__init_array_end) {
        (*func)();
        func++;
    }
}

// Call global destructors
extern "C" void call_global_destructors() {
    init_func_t* func = &__fini_array_start;
    while (func < &__fini_array_end) {
        (*func)();
        func++;
    }
}
