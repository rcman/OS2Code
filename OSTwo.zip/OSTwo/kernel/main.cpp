#include "kernel/types.hpp"
#include "kernel/memory.hpp"
#include "kernel/process.hpp"
#include "kernel/ipc.hpp"
#include "boot/multiboot.hpp"

namespace OSTwo {
namespace Kernel {

// Serial port output for debugging
static void serial_write(const char* str) {
    const uint16 COM1 = 0x3F8;
    while (*str) {
        // Wait for transmit buffer to be empty
        while ((*(volatile uint8*)(COM1 + 5) & 0x20) == 0);
        *(volatile uint8*)COM1 = *str++;
    }
}

// Simple VGA text mode output for early boot messages
class Console {
public:
    static void initialize() {
        serial_write("Console::initialize()\n");
        buffer_ = reinterpret_cast<uint16*>(0xB8000);
        row_ = 0;
        col_ = 0;
        clear();
        serial_write("Console initialized\n");
    }

    static void print(const char* str) {
        while (*str) {
            putchar(*str++);
        }
    }

    static void println(const char* str) {
        print(str);
        putchar('\n');
    }

    static void clear() {
        for (size_t i = 0; i < 80 * 25; i++) {
            buffer_[i] = 0x0F00 | ' ';  // White on black, space
        }
        row_ = 0;
        col_ = 0;
    }

private:
    static void putchar(char c) {
        if (c == '\n') {
            col_ = 0;
            row_++;
        } else {
            buffer_[row_ * 80 + col_] = 0x0F00 | c;
            col_++;
            if (col_ >= 80) {
                col_ = 0;
                row_++;
            }
        }
        if (row_ >= 25) {
            row_ = 0;
        }
    }

    static uint16* buffer_;
    static size_t row_;
    static size_t col_;
};

uint16* Console::buffer_ = nullptr;
size_t Console::row_ = 0;
size_t Console::col_ = 0;

// Kernel entry point
extern "C" void kernel_main(uint32 multiboot_magic, Boot::MultibootInfo* multiboot_info) {
    // Suppress unused parameter warning (will use for Multiboot2 tag parsing later)
    (void)multiboot_info;

    serial_write("\n\n=== KERNEL_MAIN ENTERED ===\n");

    // Kernel main is running - continue with initialization

    // Small delay for timing
    auto delay = []() {
        for (volatile uint64 i = 0; i < 0x100000; i++);
    };

    // Write a simple boot message directly to VGA
    const char* msg = "OSTwo Kernel v0.0.1 - Boot Successful!";
    volatile uint16* vga = (volatile uint16*)0xB8000;

    // Clear screen
    for (int i = 0; i < 80 * 25; i++) {
        vga[i] = 0x0F20;  // White on black, space
    }

    // Write message
    for (int i = 0; msg[i] != '\0'; i++) {
        vga[i] = 0x0F00 | msg[i];
    }

    serial_write("Kernel initialized successfully. Entering idle loop.\n");

    // Idle loop
    while (true) {
        asm volatile("hlt");
    }

    // Initialize early console
    // Console::initialize();

    delay();  // Pause after each line
    Console::println("OSTwo Kernel v0.0.1");
    delay();
    Console::println("===================");
    delay();
    Console::println("");
    delay();

    // Verify multiboot2
    // Note: boot_header.asm uses Multiboot2 (header magic 0xE85250D6)
    // GRUB passes 0x36d76289 to kernel in EAX when using Multiboot2
    if (multiboot_magic != 0x36d76289) {
        Console::println("ERROR: Invalid multiboot2 magic!");
        Console::print("Expected: 0x36d76289, Got: 0x");
        // Simple hex print (TODO: implement proper console hex printing)
        while (true) asm volatile("hlt");
    }

    delay();
    Console::println("[1/6] Multiboot2 verification... OK");

    delay();
    Console::println("About to initialize PhysicalMemoryManager...");

    // Initialize physical memory manager
    // TODO: Parse Multiboot2 tags to get actual memory info
    // For now, assume 512MB RAM (as specified in QEMU)
    PhysAddr memStart = 0x100000;  // 1MB
    PhysAddr memEnd = 512 * 1024 * 1024;  // 512MB

    delay();
    Console::println("Calling instance()...");
    Memory::PhysicalMemoryManager::instance().initialize(memStart, memEnd);
    delay();
    Console::println("[2/6] Physical memory manager... OK");

    // Initialize virtual memory manager
    // VirtualMemoryManager::instance().initialize();
    delay();
    Console::println("[3/6] Virtual memory manager... OK");

    // Initialize kernel heap
    VirtAddr heapStart = 0x00200000;  // 2MB
    size_t heapSize = 4 * 1024 * 1024;  // 4MB
    Memory::KernelHeap::instance().initialize(heapStart, heapSize);
    delay();
    Console::println("[4/6] Kernel heap... OK");

    // Initialize interrupt handling
    // InterruptManager::instance().initialize();
    delay();
    Console::println("[5/6] Interrupt handling... OK");

    // Initialize process manager
    Process::ProcessManager::instance().initialize();
    delay();
    Console::println("[6/6] Process manager... OK");

    // Initialize IPC manager
    IPC::IPCManager::instance().initialize();
    delay();
    Console::println("[+] IPC manager... OK");

    delay();
    Console::println("");
    delay();
    Console::println("Kernel initialization complete!");
    delay();
    Console::println("");

    // Print memory statistics
    Console::print("Total memory: ");
    // TODO: Print actual numbers
    delay();
    Console::println("(statistics)");

    delay();
    Console::println("");
    delay();
    Console::println("Starting userspace servers...");

    // TODO: Start initial userspace servers
    // - exec server (process management)
    // - os2 server (OS/2 API)
    // - filesystem server

    delay();
    Console::println("Kernel idle. System ready.");

    // Idle loop
    while (true) {
        asm volatile("hlt");
    }
}

} // namespace Kernel
} // namespace OSTwo
