#include "kernel/interrupt.hpp"

namespace OSTwo {
namespace Kernel {
namespace Interrupt {

// PIC ports
constexpr uint16 PIC1_COMMAND = 0x20;
constexpr uint16 PIC1_DATA = 0x21;
constexpr uint16 PIC2_COMMAND = 0xA0;
constexpr uint16 PIC2_DATA = 0xA1;

// PIC commands
constexpr uint8 PIC_EOI = 0x20;
constexpr uint8 ICW1_INIT = 0x10;
constexpr uint8 ICW1_ICW4 = 0x01;
constexpr uint8 ICW4_8086 = 0x01;

// Port I/O helper functions
static inline void outb(uint16 port, uint8 value) {
    asm volatile("outb %0, %1" : : "a"(value), "Nd"(port));
}

static inline uint8 inb(uint16 port) {
    uint8 value;
    asm volatile("inb %1, %0" : "=a"(value) : "Nd"(port));
    return value;
}

static inline void io_wait() {
    // Wait for I/O operation to complete (port 0x80 is unused)
    asm volatile("outb %%al, $0x80" : : "a"(0));
}

// InterruptManager implementation

void InterruptManager::enable() {
    asm volatile("sti");
}

void InterruptManager::disable() {
    asm volatile("cli");
}

bool InterruptManager::areEnabled() {
    uint64 flags;
    asm volatile("pushfq; pop %0" : "=r"(flags));
    return (flags & 0x200) != 0;  // IF flag
}

InterruptManager& InterruptManager::instance() {
    static InterruptManager instance;
    return instance;
}

void InterruptManager::initialize() {
    // Clear handlers array
    for (size_t i = 0; i < IDT_ENTRIES; i++) {
        handlers_[i] = nullptr;
    }

    // Initialize PIC first
    initializePIC();

    // Set up IDT entries for all interrupt vectors
    // Note: In a full implementation, we would set up assembly stubs for each vector
    // For now, we set up default handlers
    for (uint16 i = 0; i < IDT_ENTRIES; i++) {
        // Use a default stub address (0) for now
        // In a real implementation, each would have its own assembly stub
        setIDTEntry(i, 0, 0x8E);  // 0x8E = Present, DPL=0, Type=Interrupt Gate
    }

    // Load the IDT
    loadIDT();

    // Mask all IRQs initially (except cascade)
    for (uint8 i = 0; i < 16; i++) {
        if (i != 2) {  // Don't mask cascade IRQ
            disableIRQ(i);
        }
    }
}

void InterruptManager::registerHandler(uint8 vector, InterruptHandler handler) {
    if (vector < IDT_ENTRIES) {
        handlers_[vector] = handler;
    }
}

void InterruptManager::unregisterHandler(uint8 vector) {
    if (vector < IDT_ENTRIES) {
        handlers_[vector] = nullptr;
    }
}

void InterruptManager::enableIRQ(uint8 irq) {
    uint16 port;
    uint8 value;

    if (irq < 8) {
        port = PIC1_DATA;
    } else {
        port = PIC2_DATA;
        irq -= 8;
    }

    value = inb(port) & ~(1 << irq);
    outb(port, value);
}

void InterruptManager::disableIRQ(uint8 irq) {
    uint16 port;
    uint8 value;

    if (irq < 8) {
        port = PIC1_DATA;
    } else {
        port = PIC2_DATA;
        irq -= 8;
    }

    value = inb(port) | (1 << irq);
    outb(port, value);
}

void InterruptManager::sendEOI(uint8 irq) {
    // Send EOI to PIC2 if this is a secondary IRQ (8-15)
    if (irq >= 8) {
        outb(PIC2_COMMAND, PIC_EOI);
    }
    // Always send EOI to PIC1
    outb(PIC1_COMMAND, PIC_EOI);
}

void InterruptManager::setIDTEntry(uint8 vector, uint64 handler, uint8 flags) {
    idt_[vector].offsetLow = handler & 0xFFFF;
    idt_[vector].selector = 0x08;  // Kernel code segment
    idt_[vector].ist = 0;
    idt_[vector].flags = flags;
    idt_[vector].offsetMiddle = (handler >> 16) & 0xFFFF;
    idt_[vector].offsetHigh = (handler >> 32) & 0xFFFFFFFF;
    idt_[vector].reserved = 0;
}

void InterruptManager::loadIDT() {
    IDTRegister idtr;
    idtr.limit = sizeof(idt_) - 1;
    idtr.base = reinterpret_cast<uint64>(&idt_[0]);

    asm volatile("lidt %0" : : "m"(idtr));
}

void InterruptManager::initializePIC() {
    // Save masks
    uint8 mask1 = inb(PIC1_DATA);
    uint8 mask2 = inb(PIC2_DATA);

    // Start initialization sequence
    outb(PIC1_COMMAND, ICW1_INIT | ICW1_ICW4);
    io_wait();
    outb(PIC2_COMMAND, ICW1_INIT | ICW1_ICW4);
    io_wait();

    // Set vector offsets (remap IRQs to 32-47)
    outb(PIC1_DATA, IRQ_BASE);      // PIC1 starts at IRQ_BASE (32)
    io_wait();
    outb(PIC2_DATA, IRQ_BASE + 8);  // PIC2 starts at IRQ_BASE + 8 (40)
    io_wait();

    // Tell PIC1 there's a slave PIC at IRQ2
    outb(PIC1_DATA, 4);
    io_wait();
    // Tell PIC2 its cascade identity
    outb(PIC2_DATA, 2);
    io_wait();

    // Set 8086 mode
    outb(PIC1_DATA, ICW4_8086);
    io_wait();
    outb(PIC2_DATA, ICW4_8086);
    io_wait();

    // Restore saved masks
    outb(PIC1_DATA, mask1);
    outb(PIC2_DATA, mask2);
}

// Internal method to dispatch interrupt
void InterruptManager::dispatchInterrupt(uint8 vector, InterruptFrame* frame) {
    if (vector < IDT_ENTRIES && handlers_[vector]) {
        handlers_[vector](frame);
    }
}

// Common interrupt handler
extern "C" void interrupt_handler_common(InterruptFrame* frame) {
    if (frame->interruptNumber < 256) {
        InterruptManager::instance().dispatchInterrupt(
            static_cast<uint8>(frame->interruptNumber), frame);
    }
}

} // namespace Interrupt
} // namespace Kernel
} // namespace OSTwo
