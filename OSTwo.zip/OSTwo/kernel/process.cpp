#include "kernel/process.hpp"
#include "kernel/memory.hpp"
#include "kernel/interrupt.hpp"

namespace OSTwo {
namespace Kernel {
namespace Process {

// ProcessManager Implementation
ProcessManager& ProcessManager::instance() {
    static ProcessManager instance;
    return instance;
}

void ProcessManager::initialize() {
    processCount_ = 0;
    totalThreadCount_ = 0;
    currentThread_ = nullptr;
    nextProcessId_ = 1;
    nextThreadId_ = 1;

    for (size_t i = 0; i < MAX_PROCESSES; i++) {
        processes_[i] = nullptr;
    }

    for (size_t i = 0; i < 5; i++) {
        readyQueueSize_[i] = 0;
    }

    // Create kernel idle process (PID 0)
    createProcess("kernel_idle", 0, 8192);
}

ProcessId ProcessManager::createProcess(const char* name, VirtAddr entryPoint, size_t stackSize) {
    Interrupt::InterruptGuard guard;

    if (processCount_ >= MAX_PROCESSES) {
        return 0;  // No more process slots
    }

    auto* pcb = new ProcessControlBlock();
    if (!pcb) return 0;

    pcb->id_ = nextProcessId_++;
    pcb->state_ = ProcessState::Created;

    // Copy name
    size_t i = 0;
    while (name[i] && i < 63) {
        pcb->name_[i] = name[i];
        i++;
    }
    pcb->name_[i] = '\0';

    // Create address space
    pcb->pageDirectory_ = Memory::VirtualMemoryManager::instance().createAddressSpace();
    pcb->baseAddress_ = 0x400000;  // Standard base address
    pcb->memorySize_ = 0;
    pcb->threadCount_ = 0;
    pcb->parentId_ = currentThread_ ? currentThread_->getProcessId() : 0;
    pcb->creationTime_ = 0;  // TODO: Get system time
    pcb->exitCode_ = 0;

    // Add to process table
    processes_[processCount_++] = pcb;

    // Create initial thread
    if (entryPoint != 0) {
        createThread(pcb->id_, entryPoint, stackSize, Priority::Normal);
    }

    pcb->state_ = ProcessState::Ready;

    return pcb->id_;
}

Status ProcessManager::terminateProcess(ProcessId pid, uint32 exitCode) {
    Interrupt::InterruptGuard guard;

    ProcessControlBlock* pcb = getProcess(pid);
    if (!pcb) {
        return Status::NotFound;
    }

    // Terminate all threads
    for (size_t i = 0; i < pcb->threadCount_; i++) {
        if (pcb->threads_[i]) {
            terminateThread(pcb->threads_[i]->getId());
        }
    }

    // Clean up resources
    Memory::VirtualMemoryManager::instance().destroyAddressSpace(pcb->pageDirectory_);

    pcb->state_ = ProcessState::Terminated;
    pcb->exitCode_ = exitCode;

    // Remove from process table
    for (size_t i = 0; i < processCount_; i++) {
        if (processes_[i] == pcb) {
            processes_[i] = processes_[processCount_ - 1];
            processes_[processCount_ - 1] = nullptr;
            processCount_--;
            break;
        }
    }

    delete pcb;

    return Status::Success;
}

ProcessControlBlock* ProcessManager::getProcess(ProcessId pid) {
    for (size_t i = 0; i < processCount_; i++) {
        if (processes_[i] && processes_[i]->id_ == pid) {
            return processes_[i];
        }
    }
    return nullptr;
}

ThreadId ProcessManager::createThread(ProcessId pid, VirtAddr entryPoint,
                                      size_t stackSize, Priority priority) {
    Interrupt::InterruptGuard guard;

    ProcessControlBlock* pcb = getProcess(pid);
    if (!pcb || pcb->threadCount_ >= MAX_THREADS_PER_PROCESS) {
        return 0;
    }

    auto* thread = new Thread();
    if (!thread) return 0;

    thread->id_ = nextThreadId_++;
    thread->processId_ = pid;
    thread->state_ = ThreadState::Created;
    thread->priority_ = priority;
    thread->cpuTimeUsed_ = 0;
    thread->sleepUntil_ = 0;

    // Allocate stack
    thread->stackSize_ = stackSize;
    thread->stackPointer_ = Memory::VirtualMemoryManager::instance().allocate(
        stackSize, Memory::PageFlags::Present | Memory::PageFlags::Writable);

    if (thread->stackPointer_ == 0) {
        delete thread;
        return 0;
    }

    // Initialize CPU context
    auto& ctx = thread->context_;
    ctx = {};  // Zero initialize
    ctx.rip = entryPoint;
    ctx.rsp = thread->stackPointer_ + stackSize - 16;  // Stack grows down
    ctx.rbp = ctx.rsp;
    ctx.rflags = 0x202;  // Interrupts enabled
    ctx.cr3 = pcb->pageDirectory_;

    // Add to process thread list
    pcb->threads_[pcb->threadCount_++] = thread;
    totalThreadCount_++;

    // Add to ready queue
    thread->state_ = ThreadState::Ready;
    addToReadyQueue(thread);

    return thread->id_;
}

Status ProcessManager::terminateThread(ThreadId tid) {
    Interrupt::InterruptGuard guard;

    Thread* thread = getThread(tid);
    if (!thread) {
        return Status::NotFound;
    }

    thread->state_ = ThreadState::Terminated;

    // Free stack
    Memory::VirtualMemoryManager::instance().free(thread->stackPointer_, thread->stackSize_);

    // Remove from process thread list
    ProcessControlBlock* pcb = getProcess(thread->processId_);
    if (pcb) {
        for (size_t i = 0; i < pcb->threadCount_; i++) {
            if (pcb->threads_[i] == thread) {
                pcb->threads_[i] = pcb->threads_[pcb->threadCount_ - 1];
                pcb->threads_[pcb->threadCount_ - 1] = nullptr;
                pcb->threadCount_--;
                break;
            }
        }
    }

    totalThreadCount_--;

    // If this was the current thread, schedule a new one
    if (thread == currentThread_) {
        currentThread_ = nullptr;
        schedule();
    }

    delete thread;

    return Status::Success;
}

Thread* ProcessManager::getThread(ThreadId tid) {
    for (size_t i = 0; i < processCount_; i++) {
        if (processes_[i]) {
            for (size_t j = 0; j < processes_[i]->threadCount_; j++) {
                if (processes_[i]->threads_[j]->id_ == tid) {
                    return processes_[i]->threads_[j];
                }
            }
        }
    }
    return nullptr;
}

void ProcessManager::schedule() {
    Thread* nextThread = getNextThread();

    if (!nextThread) {
        return;  // No thread to run (idle)
    }

    if (nextThread == currentThread_) {
        return;  // Already running
    }

    Thread* prevThread = currentThread_;
    currentThread_ = nextThread;
    nextThread->state_ = ThreadState::Running;

    if (prevThread) {
        if (prevThread->state_ == ThreadState::Running) {
            prevThread->state_ = ThreadState::Ready;
            addToReadyQueue(prevThread);
        }
        contextSwitch(prevThread, nextThread);
    } else {
        // First thread switch
        contextSwitch(nullptr, nextThread);
    }
}

void ProcessManager::yield() {
    if (currentThread_) {
        currentThread_->state_ = ThreadState::Ready;
        addToReadyQueue(currentThread_);
    }
    schedule();
}

void ProcessManager::sleep(uint64 milliseconds) {
    if (!currentThread_) return;

    // TODO: Get current time + milliseconds
    currentThread_->sleepUntil_ = milliseconds;
    currentThread_->state_ = ThreadState::Waiting;
    schedule();
}

void ProcessManager::addToReadyQueue(Thread* thread) {
    size_t priority = static_cast<size_t>(thread->priority_);
    if (priority >= 5) priority = 4;

    size_t& queueSize = readyQueueSize_[priority];
    if (queueSize < MAX_PROCESSES * MAX_THREADS_PER_PROCESS) {
        readyQueue_[priority][queueSize++] = thread;
    }
}

Thread* ProcessManager::getNextThread() {
    // Find highest priority ready thread
    for (size_t priority = 0; priority < 5; priority++) {
        if (readyQueueSize_[priority] > 0) {
            Thread* thread = readyQueue_[priority][0];

            // Shift queue
            for (size_t i = 1; i < readyQueueSize_[priority]; i++) {
                readyQueue_[priority][i - 1] = readyQueue_[priority][i];
            }
            readyQueueSize_[priority]--;

            return thread;
        }
    }

    return nullptr;
}

void ProcessManager::contextSwitch(Thread* from, Thread* to) {
    if (!to) return;

    // Switch address space
    Memory::VirtualMemoryManager::instance().switchAddressSpace(to->context_.cr3);

    // TODO: Save/restore CPU context
    // This would use assembly to save/restore registers
    (void)from;
}

Thread* ProcessControlBlock::getThread(ThreadId tid) {
    for (size_t i = 0; i < threadCount_; i++) {
        if (threads_[i] && threads_[i]->getId() == tid) {
            return threads_[i];
        }
    }
    return nullptr;
}

// System calls
extern "C" {

ProcessId sys_getpid() {
    Thread* current = ProcessManager::instance().getCurrentThread();
    return current ? current->getProcessId() : 0;
}

ThreadId sys_gettid() {
    Thread* current = ProcessManager::instance().getCurrentThread();
    return current ? current->getId() : 0;
}

ProcessId sys_fork() {
    // TODO: Implement fork (copy current process)
    return 0;
}

Status sys_exec(const char* path, const char* args[], const char* env[]) {
    // TODO: Load and execute new program
    (void)path;
    (void)args;
    (void)env;
    return Status::NotImplemented;
}

void sys_exit(uint32 exitCode) {
    ProcessId pid = sys_getpid();
    ProcessManager::instance().terminateProcess(pid, exitCode);
}

void sys_yield() {
    ProcessManager::instance().yield();
}

void sys_sleep(uint64 milliseconds) {
    ProcessManager::instance().sleep(milliseconds);
}

} // extern "C"

} // namespace Process
} // namespace Kernel
} // namespace OSTwo
