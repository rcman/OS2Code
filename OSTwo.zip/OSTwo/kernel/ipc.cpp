#include "kernel/ipc.hpp"
#include "kernel/memory.hpp"
#include "kernel/interrupt.hpp"

namespace OSTwo {
namespace Kernel {
namespace IPC {

// IPCManager Implementation
IPCManager& IPCManager::instance() {
    static IPCManager instance;
    return instance;
}

void IPCManager::initialize() {
    endpointCount_ = 0;
    sharedRegionCount_ = 0;
    nextEndpointId_ = 1;

    for (size_t i = 0; i < MAX_ENDPOINTS; i++) {
        endpoints_[i].id = 0;
        endpoints_[i].messageQueue = nullptr;
    }
}

EndpointId IPCManager::createEndpoint(EndpointType type) {
    Interrupt::InterruptGuard guard;

    if (endpointCount_ >= MAX_ENDPOINTS) {
        return 0;
    }

    ThreadId owner = Process::sys_gettid();

    Endpoint& ep = endpoints_[endpointCount_++];
    ep.id = nextEndpointId_++;
    ep.type = type;
    ep.owner = owner;
    ep.connectedTo = 0;
    ep.queueCapacity = 16;
    ep.queueSize = 0;

    // Allocate message queue
    size_t queueBytes = ep.queueCapacity * sizeof(Message);
    void* queueMem = Memory::KernelHeap::instance().allocate(queueBytes);
    ep.messageQueue = static_cast<Message*>(queueMem);

    return ep.id;
}

Status IPCManager::destroyEndpoint(EndpointId endpoint) {
    Interrupt::InterruptGuard guard;

    Endpoint* ep = getEndpoint(endpoint);
    if (!ep) {
        return Status::NotFound;
    }

    // Free message queue
    if (ep->messageQueue) {
        Memory::KernelHeap::instance().free(ep->messageQueue);
    }

    // Remove from endpoint list
    for (size_t i = 0; i < endpointCount_; i++) {
        if (endpoints_[i].id == endpoint) {
            endpoints_[i] = endpoints_[endpointCount_ - 1];
            endpoints_[endpointCount_ - 1].id = 0;
            endpointCount_--;
            break;
        }
    }

    return Status::Success;
}

Status IPCManager::connectEndpoint(EndpointId client, EndpointId server) {
    Interrupt::InterruptGuard guard;

    Endpoint* clientEp = getEndpoint(client);
    Endpoint* serverEp = getEndpoint(server);

    if (!clientEp || !serverEp) {
        return Status::NotFound;
    }

    if (clientEp->type != EndpointType::Client) {
        return Status::InvalidParameter;
    }

    if (serverEp->type != EndpointType::Server) {
        return Status::InvalidParameter;
    }

    clientEp->connectedTo = server;

    return Status::Success;
}

Status IPCManager::send(EndpointId endpoint, const void* data, size_t size) {
    Interrupt::InterruptGuard guard;

    if (size > MAX_MESSAGE_SIZE) {
        return Status::InvalidParameter;
    }

    Endpoint* ep = getEndpoint(endpoint);
    if (!ep) {
        return Status::NotFound;
    }

    Endpoint* target = nullptr;
    if (ep->connectedTo != 0) {
        target = getEndpoint(ep->connectedTo);
    } else {
        target = ep;  // Send to self (for server endpoints)
    }

    if (!target) {
        return Status::NotFound;
    }

    Message msg;
    msg.sender = ep->owner;
    msg.receiver = target->owner;
    msg.type = MessageType::Send;
    msg.messageId = 0;  // TODO: Generate message ID
    msg.dataSize = size;

    // Copy data
    const uint8* src = static_cast<const uint8*>(data);
    for (size_t i = 0; i < size; i++) {
        msg.data[i] = src[i];
    }

    return enqueueMessage(target, msg);
}

Status IPCManager::receive(EndpointId endpoint, void* buffer, size_t bufferSize, size_t* receivedSize) {
    Interrupt::InterruptGuard guard;

    Endpoint* ep = getEndpoint(endpoint);
    if (!ep) {
        return Status::NotFound;
    }

    Message msg;
    Status status = dequeueMessage(ep, &msg);
    if (status != Status::Success) {
        return status;
    }

    if (msg.dataSize > bufferSize) {
        return Status::InvalidParameter;
    }

    // Copy data
    uint8* dst = static_cast<uint8*>(buffer);
    for (size_t i = 0; i < msg.dataSize; i++) {
        dst[i] = msg.data[i];
    }

    if (receivedSize) {
        *receivedSize = msg.dataSize;
    }

    return Status::Success;
}

Status IPCManager::call(EndpointId endpoint, const void* request, size_t requestSize,
                       void* reply, size_t replyBufferSize, size_t* replySize) {
    // Send request
    Status status = send(endpoint, request, requestSize);
    if (status != Status::Success) {
        return status;
    }

    // Wait for reply (blocking)
    // TODO: Block thread until reply received
    // For now, just try to receive
    return receive(endpoint, reply, replyBufferSize, replySize);
}

Status IPCManager::reply(EndpointId endpoint, const void* data, size_t size) {
    // Similar to send but marks message as reply
    Interrupt::InterruptGuard guard;

    if (size > MAX_MESSAGE_SIZE) {
        return Status::InvalidParameter;
    }

    Endpoint* ep = getEndpoint(endpoint);
    if (!ep) {
        return Status::NotFound;
    }

    // TODO: Get the endpoint to reply to from pending call
    // For now, reply through connected endpoint
    if (ep->connectedTo == 0) {
        return Status::InvalidParameter;
    }

    Endpoint* target = getEndpoint(ep->connectedTo);
    if (!target) {
        return Status::NotFound;
    }

    Message msg;
    msg.sender = ep->owner;
    msg.receiver = target->owner;
    msg.type = MessageType::Reply;
    msg.messageId = 0;
    msg.dataSize = size;

    const uint8* src = static_cast<const uint8*>(data);
    for (size_t i = 0; i < size; i++) {
        msg.data[i] = src[i];
    }

    return enqueueMessage(target, msg);
}

VirtAddr IPCManager::createSharedMemory(size_t size) {
    Interrupt::InterruptGuard guard;

    if (sharedRegionCount_ >= MAX_SHARED_REGIONS) {
        return 0;
    }

    // Allocate physical pages
    size_t pages = Memory::bytesToPages(size);
    PhysAddr phys = Memory::PhysicalMemoryManager::instance().allocatePages(pages);
    if (phys == 0) {
        return 0;
    }

    // Map into creator's address space
    VirtAddr virt = Memory::VirtualMemoryManager::instance().allocate(
        size,
        Memory::PageFlags::Present | Memory::PageFlags::Writable | Memory::PageFlags::User);

    if (virt == 0) {
        Memory::PhysicalMemoryManager::instance().freePages(phys, pages);
        return 0;
    }

    SharedMemoryRegion& region = sharedRegions_[sharedRegionCount_++];
    region.address = virt;
    region.size = size;
    region.physicalPages = phys;
    region.creator = Process::sys_getpid();
    region.refCount = 1;

    return virt;
}

Status IPCManager::mapSharedMemory(VirtAddr sharedAddr, ProcessId targetProcess, VirtAddr* mappedAddr) {
    Interrupt::InterruptGuard guard;

    // Find shared region
    SharedMemoryRegion* region = nullptr;
    for (size_t i = 0; i < sharedRegionCount_; i++) {
        if (sharedRegions_[i].address == sharedAddr) {
            region = &sharedRegions_[i];
            break;
        }
    }

    if (!region) {
        return Status::NotFound;
    }

    // TODO: Map into target process address space
    // This requires switching to target process page tables
    (void)targetProcess;
    (void)mappedAddr;

    region->refCount++;

    return Status::NotImplemented;
}

Status IPCManager::unmapSharedMemory(VirtAddr addr) {
    Interrupt::InterruptGuard guard;

    SharedMemoryRegion* region = nullptr;
    for (size_t i = 0; i < sharedRegionCount_; i++) {
        if (sharedRegions_[i].address == addr) {
            region = &sharedRegions_[i];
            break;
        }
    }

    if (!region) {
        return Status::NotFound;
    }

    region->refCount--;

    if (region->refCount == 0) {
        return destroySharedMemory(addr);
    }

    return Status::Success;
}

Status IPCManager::destroySharedMemory(VirtAddr addr) {
    Interrupt::InterruptGuard guard;

    SharedMemoryRegion* region = nullptr;
    size_t regionIndex = 0;

    for (size_t i = 0; i < sharedRegionCount_; i++) {
        if (sharedRegions_[i].address == addr) {
            region = &sharedRegions_[i];
            regionIndex = i;
            break;
        }
    }

    if (!region) {
        return Status::NotFound;
    }

    // Free physical pages
    size_t pages = Memory::bytesToPages(region->size);
    Memory::PhysicalMemoryManager::instance().freePages(region->physicalPages, pages);

    // Free virtual mapping
    Memory::VirtualMemoryManager::instance().free(region->address, region->size);

    // Remove from list
    sharedRegions_[regionIndex] = sharedRegions_[sharedRegionCount_ - 1];
    sharedRegionCount_--;

    return Status::Success;
}

IPCManager::Endpoint* IPCManager::getEndpoint(EndpointId id) {
    for (size_t i = 0; i < endpointCount_; i++) {
        if (endpoints_[i].id == id) {
            return &endpoints_[i];
        }
    }
    return nullptr;
}

Status IPCManager::enqueueMessage(Endpoint* ep, const Message& msg) {
    if (ep->queueSize >= ep->queueCapacity) {
        return Status::Error;  // Queue full
    }

    ep->messageQueue[ep->queueSize++] = msg;

    // TODO: Wake up waiting thread if any

    return Status::Success;
}

Status IPCManager::dequeueMessage(Endpoint* ep, Message* msg) {
    if (ep->queueSize == 0) {
        return Status::Error;  // No messages
    }

    *msg = ep->messageQueue[0];

    // Shift queue
    for (size_t i = 1; i < ep->queueSize; i++) {
        ep->messageQueue[i - 1] = ep->messageQueue[i];
    }
    ep->queueSize--;

    return Status::Success;
}

// System calls
extern "C" {

EndpointId sys_endpoint_create(EndpointType type) {
    return IPCManager::instance().createEndpoint(type);
}

Status sys_endpoint_destroy(EndpointId endpoint) {
    return IPCManager::instance().destroyEndpoint(endpoint);
}

Status sys_endpoint_connect(EndpointId client, EndpointId server) {
    return IPCManager::instance().connectEndpoint(client, server);
}

Status sys_send(EndpointId endpoint, const void* data, size_t size) {
    return IPCManager::instance().send(endpoint, data, size);
}

Status sys_receive(EndpointId endpoint, void* buffer, size_t bufferSize, size_t* receivedSize) {
    return IPCManager::instance().receive(endpoint, buffer, bufferSize, receivedSize);
}

Status sys_call(EndpointId endpoint, const void* request, size_t requestSize,
                void* reply, size_t replyBufferSize, size_t* replySize) {
    return IPCManager::instance().call(endpoint, request, requestSize, reply, replyBufferSize, replySize);
}

Status sys_reply(EndpointId endpoint, const void* data, size_t size) {
    return IPCManager::instance().reply(endpoint, data, size);
}

} // extern "C"

} // namespace IPC
} // namespace Kernel
} // namespace OSTwo
