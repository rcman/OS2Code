#ifndef OSTWO_FILESYS_FAT32_HPP
#define OSTWO_FILESYS_FAT32_HPP

#include "kernel/types.hpp"
#include "kernel/memory.hpp"

namespace OSTwo {
namespace FileSys {
namespace FAT32 {

using namespace Kernel;

// FAT32 Boot Sector structure
struct __attribute__((packed)) BootSector {
    uint8 jumpBoot[3];
    uint8 oemName[8];
    uint16 bytesPerSector;
    uint8 sectorsPerCluster;
    uint16 reservedSectorCount;
    uint8 numFATs;
    uint16 rootEntryCount;
    uint16 totalSectors16;
    uint8 mediaType;
    uint16 fatSize16;
    uint16 sectorsPerTrack;
    uint16 numHeads;
    uint32 hiddenSectors;
    uint32 totalSectors32;

    // FAT32-specific fields
    uint32 fatSize32;
    uint16 extFlags;
    uint16 fsVersion;
    uint32 rootCluster;
    uint16 fsInfo;
    uint16 backupBootSector;
    uint8 reserved[12];
    uint8 driveNumber;
    uint8 reserved1;
    uint8 bootSignature;
    uint32 volumeID;
    uint8 volumeLabel[11];
    uint8 fileSystemType[8];
};

// FAT32 Directory Entry
struct __attribute__((packed)) DirectoryEntry {
    uint8 name[11];
    uint8 attributes;
    uint8 reserved;
    uint8 creationTimeTenth;
    uint16 creationTime;
    uint16 creationDate;
    uint16 lastAccessDate;
    uint16 firstClusterHigh;
    uint16 lastWriteTime;
    uint16 lastWriteDate;
    uint16 firstClusterLow;
    uint32 fileSize;
};

// File attributes
constexpr uint8 ATTR_READ_ONLY = 0x01;
constexpr uint8 ATTR_HIDDEN = 0x02;
constexpr uint8 ATTR_SYSTEM = 0x04;
constexpr uint8 ATTR_VOLUME_ID = 0x08;
constexpr uint8 ATTR_DIRECTORY = 0x10;
constexpr uint8 ATTR_ARCHIVE = 0x20;
constexpr uint8 ATTR_LONG_NAME = 0x0F;

// FAT entry values
constexpr uint32 FAT_FREE_CLUSTER = 0x00000000;
constexpr uint32 FAT_BAD_CLUSTER = 0x0FFFFFF7;
constexpr uint32 FAT_EOC_MIN = 0x0FFFFFF8;
constexpr uint32 FAT_EOC_MAX = 0x0FFFFFFF;

// File handle
struct FileHandle {
    uint32 firstCluster;
    uint32 currentCluster;
    uint32 fileSize;
    uint32 position;
    bool isDirectory;
};

// FAT32 Driver
class FAT32Driver {
public:
    FAT32Driver();
    ~FAT32Driver();

    // Initialize filesystem from boot sector
    Status mount(const void* bootSector, uint32 deviceId);
    Status unmount();

    // File operations
    Status open(const char* path, FileHandle* handle);
    Status close(FileHandle* handle);
    Status read(FileHandle* handle, void* buffer, size_t size, size_t* bytesRead);
    Status write(FileHandle* handle, const void* buffer, size_t size, size_t* bytesWritten);
    Status seek(FileHandle* handle, int32 offset, int whence);

    // Directory operations
    Status openDir(const char* path, FileHandle* handle);
    Status readDir(FileHandle* handle, DirectoryEntry* entry);
    Status closeDir(FileHandle* handle);

    // Filesystem operations
    Status createFile(const char* path);
    Status deleteFile(const char* path);
    Status createDirectory(const char* path);
    Status deleteDirectory(const char* path);

    // Get filesystem info
    uint32 getTotalClusters() const { return totalClusters_; }
    uint32 getFreeClusters() const;
    uint32 getClusterSize() const { return clusterSize_; }

private:
    // Mounted device ID
    uint32 deviceId_;
    bool mounted_;

    // FAT32 parameters
    uint32 bytesPerSector_;
    uint32 sectorsPerCluster_;
    uint32 clusterSize_;
    uint32 reservedSectors_;
    uint32 numFATs_;
    uint32 sectorsPerFAT_;
    uint32 rootCluster_;
    uint32 totalClusters_;
    uint32 firstDataSector_;
    uint32 firstFATSector_;

    // Helper methods
    uint32 getNextCluster(uint32 currentCluster);
    uint32 allocateCluster();
    Status freeCluster(uint32 cluster);
    uint32 clusterToSector(uint32 cluster);
    Status readCluster(uint32 cluster, void* buffer);
    Status writeCluster(uint32 cluster, const void* buffer);
    Status readSector(uint32 sector, void* buffer);
    Status writeSector(uint32 sector, const void* buffer);

    // Path parsing
    Status parsePath(const char* path, DirectoryEntry* entry, uint32* parentCluster);
    Status findEntry(uint32 dirCluster, const char* name, DirectoryEntry* entry);

    // Cluster chain management
    uint32 getClusterChainLength(uint32 startCluster);
    Status readClusterChain(uint32 startCluster, void* buffer, size_t size);
};

} // namespace FAT32
} // namespace FileSys
} // namespace OSTwo

#endif // OSTWO_FILESYS_FAT32_HPP
