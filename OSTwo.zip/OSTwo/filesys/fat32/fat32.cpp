#include "fat32.hpp"
#include <cstring>

namespace OSTwo {
namespace FileSys {
namespace FAT32 {

FAT32Driver::FAT32Driver()
    : deviceId_(0), mounted_(false), bytesPerSector_(0),
      sectorsPerCluster_(0), clusterSize_(0), reservedSectors_(0),
      numFATs_(0), sectorsPerFAT_(0), rootCluster_(0),
      totalClusters_(0), firstDataSector_(0), firstFATSector_(0) {
}

FAT32Driver::~FAT32Driver() {
    if (mounted_) {
        unmount();
    }
}

Status FAT32Driver::mount(const void* bootSector, uint32 deviceId) {
    if (mounted_) {
        return Status::Error;  // Already mounted
    }

    const BootSector* bs = static_cast<const BootSector*>(bootSector);

    // Validate boot sector signature
    if (bs->bytesPerSector == 0 || bs->sectorsPerCluster == 0) {
        return Status::InvalidParameter;
    }

    // Store device information
    deviceId_ = deviceId;
    bytesPerSector_ = bs->bytesPerSector;
    sectorsPerCluster_ = bs->sectorsPerCluster;
    clusterSize_ = bytesPerSector_ * sectorsPerCluster_;
    reservedSectors_ = bs->reservedSectorCount;
    numFATs_ = bs->numFATs;
    sectorsPerFAT_ = bs->fatSize32;
    rootCluster_ = bs->rootCluster;

    // Calculate important sectors
    firstFATSector_ = reservedSectors_;
    firstDataSector_ = reservedSectors_ + (numFATs_ * sectorsPerFAT_);

    // Calculate total clusters
    uint32 dataSectors = bs->totalSectors32 - firstDataSector_;
    totalClusters_ = dataSectors / sectorsPerCluster_;

    mounted_ = true;
    return Status::Success;
}

Status FAT32Driver::unmount() {
    if (!mounted_) {
        return Status::NotFound;
    }

    // Flush any pending writes
    // In a full implementation, this would sync caches

    mounted_ = false;
    return Status::Success;
}

Status FAT32Driver::open(const char* path, FileHandle* handle) {
    if (!mounted_ || !path || !handle) {
        return Status::InvalidParameter;
    }

    DirectoryEntry entry;
    uint32 parentCluster;

    Status status = parsePath(path, &entry, &parentCluster);
    if (status != Status::Success) {
        return status;
    }

    // Check if it's a directory
    if (entry.attributes & ATTR_DIRECTORY) {
        return Status::InvalidParameter;
    }

    // Initialize file handle
    handle->firstCluster = ((uint32)entry.firstClusterHigh << 16) | entry.firstClusterLow;
    handle->currentCluster = handle->firstCluster;
    handle->fileSize = entry.fileSize;
    handle->position = 0;
    handle->isDirectory = false;

    return Status::Success;
}

Status FAT32Driver::close(FileHandle* handle) {
    if (!handle) {
        return Status::InvalidParameter;
    }

    // In a full implementation, flush any pending writes
    return Status::Success;
}

Status FAT32Driver::read(FileHandle* handle, void* buffer, size_t size, size_t* bytesRead) {
    if (!mounted_ || !handle || !buffer) {
        return Status::InvalidParameter;
    }

    // Don't read past end of file
    if (handle->position >= handle->fileSize) {
        if (bytesRead) *bytesRead = 0;
        return Status::Success;
    }

    size_t toRead = size;
    if (handle->position + toRead > handle->fileSize) {
        toRead = handle->fileSize - handle->position;
    }

    // Read data cluster by cluster
    uint8* dest = static_cast<uint8*>(buffer);
    size_t totalRead = 0;

    while (totalRead < toRead) {
        // Calculate position within current cluster
        uint32 clusterOffset = handle->position % clusterSize_;
        uint32 bytesInCluster = clusterSize_ - clusterOffset;
        uint32 bytesToRead = (toRead - totalRead < bytesInCluster) ?
                            (toRead - totalRead) : bytesInCluster;

        // Read cluster (stub - in full implementation would use device driver)
        // For now, we return zeros
        for (uint32 i = 0; i < bytesToRead; i++) {
            dest[totalRead + i] = 0;
        }

        totalRead += bytesToRead;
        handle->position += bytesToRead;

        // Move to next cluster if needed
        if (handle->position % clusterSize_ == 0 && totalRead < toRead) {
            handle->currentCluster = getNextCluster(handle->currentCluster);
            if (handle->currentCluster >= FAT_EOC_MIN) {
                break;  // End of chain
            }
        }
    }

    if (bytesRead) {
        *bytesRead = totalRead;
    }

    return Status::Success;
}

Status FAT32Driver::write(FileHandle* handle, const void* buffer, size_t size, size_t* bytesWritten) {
    if (!mounted_ || !handle || !buffer) {
        return Status::InvalidParameter;
    }

    // Stub implementation
    // In a full implementation:
    // 1. Allocate new clusters as needed
    // 2. Write data to clusters
    // 3. Update FAT chain
    // 4. Update directory entry with new file size

    (void)size;  // Unused in stub

    if (bytesWritten) {
        *bytesWritten = 0;
    }

    return Status::NotImplemented;
}

Status FAT32Driver::seek(FileHandle* handle, int32 offset, int whence) {
    if (!handle) {
        return Status::InvalidParameter;
    }

    uint32 newPos;

    switch (whence) {
        case 0:  // SEEK_SET
            newPos = offset;
            break;
        case 1:  // SEEK_CUR
            newPos = handle->position + offset;
            break;
        case 2:  // SEEK_END
            newPos = handle->fileSize + offset;
            break;
        default:
            return Status::InvalidParameter;
    }

    if (newPos > handle->fileSize) {
        return Status::InvalidParameter;
    }

    // Update position and cluster
    handle->position = newPos;

    // Find correct cluster for new position
    uint32 clusterIndex = newPos / clusterSize_;
    handle->currentCluster = handle->firstCluster;

    for (uint32 i = 0; i < clusterIndex && handle->currentCluster < FAT_EOC_MIN; i++) {
        handle->currentCluster = getNextCluster(handle->currentCluster);
    }

    return Status::Success;
}

Status FAT32Driver::openDir(const char* path, FileHandle* handle) {
    if (!mounted_ || !path || !handle) {
        return Status::InvalidParameter;
    }

    DirectoryEntry entry;
    uint32 parentCluster;

    Status status = parsePath(path, &entry, &parentCluster);
    if (status != Status::Success) {
        return status;
    }

    // Must be a directory
    if (!(entry.attributes & ATTR_DIRECTORY)) {
        return Status::InvalidParameter;
    }

    handle->firstCluster = ((uint32)entry.firstClusterHigh << 16) | entry.firstClusterLow;
    handle->currentCluster = handle->firstCluster;
    handle->fileSize = 0;
    handle->position = 0;
    handle->isDirectory = true;

    return Status::Success;
}

Status FAT32Driver::readDir(FileHandle* handle, DirectoryEntry* entry) {
    if (!mounted_ || !handle || !entry || !handle->isDirectory) {
        return Status::InvalidParameter;
    }

    // Stub - would read directory entries from cluster chain
    return Status::NotImplemented;
}

Status FAT32Driver::closeDir(FileHandle* handle) {
    return close(handle);
}

Status FAT32Driver::createFile(const char* path) {
    if (!mounted_ || !path) {
        return Status::InvalidParameter;
    }

    // Stub - would create new directory entry
    return Status::NotImplemented;
}

Status FAT32Driver::deleteFile(const char* path) {
    if (!mounted_ || !path) {
        return Status::InvalidParameter;
    }

    // Stub - would mark directory entry as deleted
    return Status::NotImplemented;
}

Status FAT32Driver::createDirectory(const char* path) {
    if (!mounted_ || !path) {
        return Status::InvalidParameter;
    }

    // Stub - would create directory entry and allocate cluster
    return Status::NotImplemented;
}

Status FAT32Driver::deleteDirectory(const char* path) {
    if (!mounted_ || !path) {
        return Status::InvalidParameter;
    }

    // Stub - would verify directory is empty and delete
    return Status::NotImplemented;
}

uint32 FAT32Driver::getFreeClusters() const {
    // Stub - would scan FAT to count free clusters
    return 0;
}

// Private helper methods

uint32 FAT32Driver::getNextCluster(uint32 currentCluster) {
    // Read FAT entry for current cluster
    // Stub - in full implementation would read from FAT table
    (void)currentCluster;  // Unused in stub
    return FAT_EOC_MAX;  // End of chain
}

uint32 FAT32Driver::allocateCluster() {
    // Find free cluster in FAT and mark as used
    // Stub
    return 0;
}

Status FAT32Driver::freeCluster(uint32 cluster) {
    // Mark cluster as free in FAT
    // Stub
    (void)cluster;
    return Status::NotImplemented;
}

uint32 FAT32Driver::clusterToSector(uint32 cluster) {
    return firstDataSector_ + ((cluster - 2) * sectorsPerCluster_);
}

Status FAT32Driver::readCluster(uint32 cluster, void* buffer) {
    if (!buffer) {
        return Status::InvalidParameter;
    }

    uint32 sector = clusterToSector(cluster);

    // Read all sectors in cluster
    for (uint32 i = 0; i < sectorsPerCluster_; i++) {
        Status status = readSector(sector + i,
            static_cast<uint8*>(buffer) + (i * bytesPerSector_));
        if (status != Status::Success) {
            return status;
        }
    }

    return Status::Success;
}

Status FAT32Driver::writeCluster(uint32 cluster, const void* buffer) {
    if (!buffer) {
        return Status::InvalidParameter;
    }

    uint32 sector = clusterToSector(cluster);

    // Write all sectors in cluster
    for (uint32 i = 0; i < sectorsPerCluster_; i++) {
        Status status = writeSector(sector + i,
            static_cast<const uint8*>(buffer) + (i * bytesPerSector_));
        if (status != Status::Success) {
            return status;
        }
    }

    return Status::Success;
}

Status FAT32Driver::readSector(uint32 sector, void* buffer) {
    // Stub - would use device driver to read sector
    // For now, just zero out buffer
    if (buffer) {
        for (uint32 i = 0; i < bytesPerSector_; i++) {
            static_cast<uint8*>(buffer)[i] = 0;
        }
    }
    (void)sector;
    return Status::Success;
}

Status FAT32Driver::writeSector(uint32 sector, const void* buffer) {
    // Stub - would use device driver to write sector
    (void)sector;
    (void)buffer;
    return Status::NotImplemented;
}

Status FAT32Driver::parsePath(const char* path, DirectoryEntry* entry, uint32* parentCluster) {
    // Stub - would parse path and find directory entry
    // For now, return error
    (void)path;
    (void)entry;
    (void)parentCluster;
    return Status::NotFound;
}

Status FAT32Driver::findEntry(uint32 dirCluster, const char* name, DirectoryEntry* entry) {
    // Stub - would search directory cluster chain for entry
    (void)dirCluster;
    (void)name;
    (void)entry;
    return Status::NotFound;
}

uint32 FAT32Driver::getClusterChainLength(uint32 startCluster) {
    uint32 length = 0;
    uint32 cluster = startCluster;

    while (cluster < FAT_EOC_MIN && length < totalClusters_) {
        length++;
        cluster = getNextCluster(cluster);
    }

    return length;
}

Status FAT32Driver::readClusterChain(uint32 startCluster, void* buffer, size_t size) {
    if (!buffer) {
        return Status::InvalidParameter;
    }

    uint8* dest = static_cast<uint8*>(buffer);
    uint32 cluster = startCluster;
    size_t offset = 0;

    while (cluster < FAT_EOC_MIN && offset < size) {
        size_t toRead = (size - offset < clusterSize_) ? (size - offset) : clusterSize_;

        Status status = readCluster(cluster, dest + offset);
        if (status != Status::Success) {
            return status;
        }

        offset += toRead;
        cluster = getNextCluster(cluster);
    }

    return Status::Success;
}

} // namespace FAT32
} // namespace FileSys
} // namespace OSTwo
