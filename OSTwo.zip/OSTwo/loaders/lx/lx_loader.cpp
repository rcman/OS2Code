#include "lx_loader.hpp"
#include "kernel/memory.hpp"

namespace OSTwo {
namespace Loaders {
namespace LX {

// Bring kernel types into scope
using Kernel::uint8;
using Kernel::uint16;
using Kernel::uint32;
using Kernel::uint64;

LXLoader::LXLoader() {
}

Kernel::Status LXLoader::load(const void* fileData, size_t fileSize,
                              Kernel::VirtAddr* entryPoint,
                              Kernel::VirtAddr* stackPointer) {
    if (!fileData || fileSize < sizeof(LXHeader)) {
        return Kernel::Status::InvalidParameter;
    }

    const LXHeader* header = static_cast<const LXHeader*>(fileData);

    // Validate LX header
    Kernel::Status status = validateHeader(header);
    if (status != Kernel::Status::Success) {
        return status;
    }

    // Load module
    LoadedModule module;
    status = loadObjects(header, fileData, module);
    if (status != Kernel::Status::Success) {
        return status;
    }

    // Apply fixups
    status = applyFixups(header, fileData, module);
    if (status != Kernel::Status::Success) {
        return status;
    }

    // Calculate entry point
    if (header->eipObject > 0 && header->eipObject <= module.numObjects) {
        LXObjectEntry& obj = module.objects[header->eipObject - 1];
        *entryPoint = obj.relocationBaseAddress + header->eip;
    } else {
        return Kernel::Status::InvalidParameter;
    }

    // Calculate stack pointer
    if (header->espObject > 0 && header->espObject <= module.numObjects) {
        LXObjectEntry& obj = module.objects[header->espObject - 1];
        *stackPointer = obj.relocationBaseAddress + header->esp;
    } else {
        // Allocate default stack
        *stackPointer = 0;  // Will be allocated by process manager
    }

    return Kernel::Status::Success;
}

Kernel::Status LXLoader::loadDLL(const void* fileData, size_t fileSize,
                                Kernel::VirtAddr* baseAddress) {
    if (!fileData || fileSize < sizeof(LXHeader)) {
        return Kernel::Status::InvalidParameter;
    }

    const LXHeader* header = static_cast<const LXHeader*>(fileData);

    Kernel::Status status = validateHeader(header);
    if (status != Kernel::Status::Success) {
        return status;
    }

    LoadedModule module;
    status = loadObjects(header, fileData, module);
    if (status != Kernel::Status::Success) {
        return status;
    }

    status = applyFixups(header, fileData, module);
    if (status != Kernel::Status::Success) {
        return status;
    }

    *baseAddress = module.baseAddress;

    return Kernel::Status::Success;
}

Kernel::Status LXLoader::getProcAddress(Kernel::VirtAddr moduleBase,
                                       const char* procName,
                                       Kernel::VirtAddr* procAddr) {
    // TODO: Search resident and non-resident name tables
    (void)moduleBase;
    (void)procName;
    (void)procAddr;
    return Kernel::Status::NotImplemented;
}

Kernel::Status LXLoader::getProcAddress(Kernel::VirtAddr moduleBase,
                                       uint32 ordinal,
                                       Kernel::VirtAddr* procAddr) {
    // TODO: Look up entry point by ordinal
    (void)moduleBase;
    (void)ordinal;
    (void)procAddr;
    return Kernel::Status::NotImplemented;
}

Kernel::Status LXLoader::validateHeader(const LXHeader* header) {
    // Check signature
    if (header->signature != 0x584C && header->signature != 0x454C) {
        return Kernel::Status::InvalidParameter;  // Not LX or LE format
    }

    // Check CPU type (we support x86/x64)
    if (header->cpuType != 1 && header->cpuType != 2) {
        return Kernel::Status::InvalidParameter;  // Unsupported CPU
    }

    // Check OS type (OS/2)
    if (header->osType != 1) {
        return Kernel::Status::InvalidParameter;  // Not OS/2 executable
    }

    return Kernel::Status::Success;
}

Kernel::Status LXLoader::loadObjects(const LXHeader* header, const void* fileData,
                                    LoadedModule& module) {
    module.header = header;
    module.numObjects = header->objectCount;

    // Read object table
    const uint8* fileBytes = static_cast<const uint8*>(fileData);
    const LXObjectEntry* objectTable = reinterpret_cast<const LXObjectEntry*>(
        fileBytes + header->objectTableOffset);

    // Allocate memory for objects
    size_t objectsSize = sizeof(LXObjectEntry) * module.numObjects;
    module.objects = static_cast<LXObjectEntry*>(
        Kernel::Memory::KernelHeap::instance().allocate(objectsSize));

    if (!module.objects) {
        return Kernel::Status::OutOfMemory;
    }

    // Copy object entries and allocate virtual memory for each
    Kernel::VirtAddr currentAddr = 0x10000;  // Start at 64KB

    for (uint32 i = 0; i < module.numObjects; i++) {
        module.objects[i] = objectTable[i];

        // Allocate virtual memory for this object
        Kernel::Memory::PageFlags flags = Kernel::Memory::PageFlags::Present;

        if (objectTable[i].objectFlags & OBJWRITE) {
            flags = flags | Kernel::Memory::PageFlags::Writable;
        }

        if (objectTable[i].objectFlags & OBJEXEC) {
            // TODO: Add execute flag
            flags = flags | Kernel::Memory::PageFlags::Present;
        }

        size_t objectSize = objectTable[i].virtualSize;
        Kernel::VirtAddr objAddr = Kernel::Memory::VirtualMemoryManager::instance().allocate(
            objectSize, flags);

        if (objAddr == 0) {
            return Kernel::Status::OutOfMemory;
        }

        module.objects[i].relocationBaseAddress = objAddr;

        if (i == 0) {
            module.baseAddress = objAddr;
        }

        // Load object pages
        // TODO: Read page data from file and copy to allocated memory

        currentAddr = objAddr + objectSize;
    }

    return Kernel::Status::Success;
}

Kernel::Status LXLoader::applyFixups(const LXHeader* header, const void* fileData,
                                    LoadedModule& module) {
    // TODO: Process fixup records to relocate addresses
    // This is complex and involves:
    // 1. Reading fixup page table
    // 2. Reading fixup records
    // 3. Applying relocations based on fixup type
    // 4. Resolving imports from other DLLs

    (void)header;
    (void)fileData;
    (void)module;

    return Kernel::Status::Success;  // Stub for now
}

Kernel::Status LXLoader::processFixup(FixupType type, uint32 source, uint32 target,
                                     LoadedModule& module) {
    // TODO: Apply specific fixup
    (void)type;
    (void)source;
    (void)target;
    (void)module;

    return Kernel::Status::NotImplemented;
}

} // namespace LX
} // namespace Loaders
} // namespace OSTwo
