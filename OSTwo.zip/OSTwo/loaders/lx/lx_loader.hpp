#ifndef OSTWO_LOADERS_LX_LOADER_HPP
#define OSTWO_LOADERS_LX_LOADER_HPP

#include <cstdint>

namespace OSTwo {

// Forward declarations from kernel
namespace Kernel {
    using uint8 = std::uint8_t;
    using uint16 = std::uint16_t;
    using uint32 = std::uint32_t;
    using uint64 = std::uint64_t;
    using VirtAddr = uint64;

    enum class Status : uint32;
}

namespace Loaders {
namespace LX {

// LX (Linear Executable) format loader
// Used by OS/2 for executables and DLLs

// LX header structure
struct LXHeader {
    uint16 signature;           // 'LX' (0x584C) or 'LE' (0x454C)
    uint8 byteOrder;
    uint8 wordOrder;
    uint32 formatLevel;
    uint16 cpuType;
    uint16 osType;
    uint32 moduleVersion;
    uint32 moduleFlags;
    uint32 numPages;
    uint32 eipObject;
    uint32 eip;
    uint32 espObject;
    uint32 esp;
    uint32 pageSize;
    uint32 pageOffsetShift;
    uint32 fixupSectionSize;
    uint32 fixupSectionChecksum;
    uint32 loaderSectionSize;
    uint32 loaderSectionChecksum;
    uint32 objectTableOffset;
    uint32 objectCount;
    uint32 objectPageTableOffset;
    uint32 objectIterPagesOffset;
    uint32 resourceTableOffset;
    uint32 resourceCount;
    uint32 residentNameTableOffset;
    uint32 entryTableOffset;
    uint32 moduleDirectivesOffset;
    uint32 moduleDirectivesCount;
    uint32 fixupPageTableOffset;
    uint32 fixupRecordTableOffset;
    uint32 importModuleTableOffset;
    uint32 importModuleCount;
    uint32 importProcTableOffset;
    uint32 perPageChecksumOffset;
    uint32 dataPageOffset;
    uint32 preloadPageCount;
    uint32 nonResidentNameTableOffset;
    uint32 nonResidentNameTableSize;
    uint32 nonResidentNameChecksum;
    uint32 autoDataObject;
    uint32 debugInfoOffset;
    uint32 debugInfoSize;
    uint32 preloadInstancePages;
    uint32 demandInstancePages;
    uint32 heapSize;
} __attribute__((packed));

// Object table entry
struct LXObjectEntry {
    uint32 virtualSize;
    uint32 relocationBaseAddress;
    uint32 objectFlags;
    uint32 pageTableIndex;
    uint32 numPageTableEntries;
    uint32 reserved;
} __attribute__((packed));

// Object flags
constexpr uint32 OBJREAD = 0x0001;
constexpr uint32 OBJWRITE = 0x0002;
constexpr uint32 OBJEXEC = 0x0004;
constexpr uint32 OBJRSRC = 0x0008;
constexpr uint32 OBJDISCARD = 0x0010;
constexpr uint32 OBJSHARED = 0x0020;
constexpr uint32 OBJPRELOAD = 0x0040;
constexpr uint32 OBJINVALID = 0x0080;
constexpr uint32 OBJZEROFILL = 0x0100;
constexpr uint32 OBJRESIDENT = 0x0200;
constexpr uint32 OBJCONFORM = 0x0400;
constexpr uint32 OBJIOPL = 0x0800;

// Page table entry
struct LXPageEntry {
    uint32 offset : 24;
    uint8 size;
    uint16 flags;
} __attribute__((packed));

// Fixup types
enum class FixupType : uint8 {
    InternalReference = 0,
    ImportOrdinal = 1,
    ImportName = 2,
    EntryPoint = 3,
};

// LX Loader class
class LXLoader {
public:
    LXLoader();

    // Load LX executable from memory buffer
    Kernel::Status load(const void* fileData, size_t fileSize,
                       Kernel::VirtAddr* entryPoint,
                       Kernel::VirtAddr* stackPointer);

    // Load LX DLL
    Kernel::Status loadDLL(const void* fileData, size_t fileSize,
                          Kernel::VirtAddr* baseAddress);

    // Get procedure address from loaded module
    Kernel::Status getProcAddress(Kernel::VirtAddr moduleBase,
                                 const char* procName,
                                 Kernel::VirtAddr* procAddr);

    Kernel::Status getProcAddress(Kernel::VirtAddr moduleBase,
                                 uint32 ordinal,
                                 Kernel::VirtAddr* procAddr);

private:
    struct LoadedModule {
        Kernel::VirtAddr baseAddress;
        uint32 numObjects;
        LXObjectEntry* objects;
        const LXHeader* header;
    };

    Kernel::Status validateHeader(const LXHeader* header);
    Kernel::Status loadObjects(const LXHeader* header, const void* fileData,
                              LoadedModule& module);
    Kernel::Status applyFixups(const LXHeader* header, const void* fileData,
                              LoadedModule& module);
    Kernel::Status processFixup(FixupType type, uint32 source, uint32 target,
                               LoadedModule& module);
};

} // namespace LX
} // namespace Loaders
} // namespace OSTwo

#endif // OSTWO_LOADERS_LX_LOADER_HPP
