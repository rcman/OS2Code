#!/bin/bash
echo "Booting OSTwo with UEFI firmware (OVMF)..."
echo "Press Ctrl+Alt+Q to quit"
echo ""

# Check if OVMF is available
if [ ! -f /usr/share/edk2/ovmf/OVMF_CODE.fd ]; then
    echo "ERROR: OVMF firmware not found!"
    echo "Install it with: sudo dnf install edk2-ovmf"
    exit 1
fi

qemu-system-x86_64 \
    -cdrom ostwo_test.iso \
    -m 512M \
    -bios /usr/share/edk2/ovmf/OVMF_CODE.fd \
    -name "OSTwo v0.0.1 (UEFI)"
